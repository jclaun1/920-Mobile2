import {Alert} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {
  USER_IS_SET,
  NOTIFICATION_PUSH,
  NOTIFICATION_INC_DEC,
  INBOX_PUSH,
  INBOX_INC_DEC,
  USERS_ONLINE,
} from './actions/types';
import Echo from 'laravel-echo';
import Pusher from 'pusher-js/react-native';
import firebase from 'react-native-firebase';
import {PUSHER_APP_KEY, PUSHER_APP_CLUSTER, SOCKET_SERVER} from '../config/env';
import moment from 'moment';
import axios from 'axios';
import {NavigationActions} from 'react-navigation';

export const _pushTo = (store, type, data) => {
  let dispatch = store.dispatch;

  if (type == 1) {
    dispatch(
      NavigationActions.navigate({
        routeName: 'AllOffers',
        params: {slug: data.order_slug},
      }),
    );
  }

  if (type == 2 || type == 3) {
    dispatch(
      NavigationActions.navigate({
        routeName: 'Chat',
        params: {slug: data.order_slug, chatID: parseInt(data.chatRoomId)},
      }),
    );
  }

  if (type == 4) {
    dispatch(
      NavigationActions.navigate({
        routeName: 'OrderPost',
        params: {slug: data.order_slug},
      }),
    );
  }

  if (type == 5 || type == 6) {
    dispatch(
      NavigationActions.navigate({
        routeName: 'ConfirmOrderTraveller',
        params: {slug: data.order_slug},
      }),
    );
  }

  if (type == 7) {
    dispatch(NavigationActions.navigate({routeName: 'BalanceAndWithdrwal'}));
  }

  if (type == 8) {
    dispatch(
      NavigationActions.navigate({
        routeName: 'OrderConfirm',
        params: {slug: data.order_slug},
      }),
    );
  }

  if (type == 9) {
    if (data.tripId) {
      dispatch(
        NavigationActions.navigate({
          routeName: 'DeliveryOrders',
          params: {tripId: parseInt(data.tripId), notify: 'notify'},
        }),
      );
    } else {
      dispatch(
        NavigationActions.navigate({
          routeName: 'OrderPost',
          params: {slug: data.order_slug},
        }),
      );
    }
  }
};

export const registerDevice = async token => {
  try {
    console.log(token);

    await axios.post('user/subscriptions/mobile', {token});
  } catch (error) {
    console.log(error);
  }
};

export const checkPermission = async () => {
  const enabled = await firebase.messaging().hasPermission();

  if (enabled) {
    getToken();
  } else {
    requestPermission();
  }
};

//3
export const getToken = async () => {
  let fcmToken = await AsyncStorage.getItem('fcmToken');
  if (!fcmToken) {
    fcmToken = await firebase.messaging().getToken();
    if (fcmToken) {
      await registerDevice(fcmToken);
      await AsyncStorage.setItem('fcmToken', fcmToken);
    }
  } else {
    registerDevice(fcmToken);
  }
};

//2
export const requestPermission = async () => {
  try {
    await firebase.messaging().requestPermission();
    await firebase.messaging().registerForNotifications();
    // User has authorised
    getToken();
  } catch (error) {
    // User has rejected permissions
    console.log('permission rejected');
  }
};

export const createNotificationListeners = async store => {
  /*
   * Triggered when a particular notification has been received in foreground
   * */
  this.notificationListener = await firebase
    .notifications()
    .onNotification(notification => {
      let data = notificationOpen.notification.data;
      _pushTo(store, data.type, data);
      return;
    });

  /*
   * If your app is in background, you can listen for when a notification is clicked / tapped / opened as follows:
   * */
  this.notificationOpenedListener = firebase
    .notifications()
    .onNotificationOpened(notificationOpen => {
      let data = notificationOpen.notification.data;
      _pushTo(store, data.type, data);
    });

  /*
   * If your app is closed, you can check if it was opened by a notification being clicked / tapped / opened as follows:
   * */
  const notificationOpen = await firebase
    .notifications()
    .getInitialNotification();
  if (notificationOpen) {
    let data = notificationOpen.notification.data;
    _pushTo(store, data.type, data);
  }
  /*
   * Triggered for data only payload in foreground
   * */
  this.messageListener = firebase.messaging().onMessage(message => {
    //process data message
    console.log(JSON.stringify(message));
  });
};

showAlert = (title, body) => {
  Alert.alert(
    title,
    body,
    [{text: 'OK', onPress: () => console.log('OK Pressed')}],
    {cancelable: false},
  );
};

export const _userIsOnline = async store => {
  try {
    window.Echo.join(`live.1`)
      .here(users => {
        store.dispatch({
          type: USERS_ONLINE,
          payload: users,
        });
      })
      .joining(user => {
        var joinusers = store.getState().commonReducers.users;
        joinusers.push(user);
        store.dispatch({
          type: USERS_ONLINE,
          payload: joinusers,
        });
      })
      .leaving(user => {
        var leaveusers = store
          .getState()
          .commonReducers.users.filter(function(obj) {
            return obj.id !== user.id;
          });
        store.dispatch({
          type: USERS_ONLINE,
          payload: leaveusers,
        });
      });
  } catch (error) {
    console.log(error);
  }
};

export const _notificationsend = (userId, store) => {
  window.Echo.private('App.User.' + userId).notification(notification => {
    var notificationvar;
    if (notification.notification_type == 3) {
      notificationvar = {
        data: notification,
        id: notification.id,
        created_at: moment().format('YYYY-MM-DD H:mm:ss'),
      };

      store.dispatch({
        type: INBOX_PUSH,
        payload: notificationvar,
      });
      store.dispatch({
        type: INBOX_INC_DEC,
        payload: 1,
      });

      return;
    }

    notificationvar = {
      data: notification,
      id: notification.id,
    };

    store.dispatch({
      type: NOTIFICATION_PUSH,
      payload: notificationvar,
    });

    store.dispatch({
      type: NOTIFICATION_INC_DEC,
      payload: 1,
    });
  });
};

const _upDateAction = async (id, store) => {
  try {
    // window.io = require('socket.io-client')
    let accessToken = await AsyncStorage.getItem('token');
    // window.Pusher = Pusher
    // window.Echo = await new Echo({
    //   broadcaster: 'socket.io',
    //   host: SOCKET_SERVER,
    //   path: process.env.NODE_ENV === 'production' ? '/broadcasting/socket.io/' : '',
    //   auth: {
    //     headers: {
    //       Authorization: `Bearer ${accessToken}`
    //     }
    //   }
    // })

    window.Pusher = Pusher;
    window.Echo = await new Echo({
      broadcaster: 'pusher',
      key: PUSHER_APP_KEY,
      cluster: PUSHER_APP_CLUSTER,
      authEndpoint: SOCKET_SERVER + 'broadcasting/auth',
      host: SOCKET_SERVER,
      auth: {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
    });

    _notificationsend(id, store);
    _userIsOnline(store);
  } catch (error) {
    console.log('error');
    console.log(error);
  }
};

const UserMiddleware = store => next => action => {
  if (action.type === USER_IS_SET) {
    checkPermission(store);
    createNotificationListeners(store);
    var user = store.getState().auth.user;
    _upDateAction(user.id, store);
  }
  next(action);
};

export default UserMiddleware;
