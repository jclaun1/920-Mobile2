import { Drawer } from "../../routes"
// import { createNavigationReducer } from 'react-navigation-redux-helpers'


const navReducer = Drawer

export default navReducer