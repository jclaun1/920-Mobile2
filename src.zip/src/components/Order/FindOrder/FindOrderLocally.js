import React from 'react';
import {Text, View, TouchableOpacity, ScrollView, Alert} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../../assets/css/style';
import GooglePlaces from '../../Common/GooglePlaces';
import {DatePicker, Picker, Icon} from 'native-base';
import OrderItem from '../../Order/OrderItem';
import OrderSubmitting from '../../Common/OrderSubmitting';
import axios from 'axios';
import {connect} from 'react-redux';
import moment from 'moment';
import isEmpty from 'lodash/isEmpty';

class FindOrderLocally extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      orders: [],
      isLoading: true,
      visible: false,
      fromShow: false,
      toShow: false,
      isAdded: false,
      localCityShow: false,
      navigation: props.navigation,
      citydetails: {lang: '', lat: ''},
      selectedCountry: {code: '', name: ''},

      address_from: '',
      data_from: '',
      data_to: '',
      address_to: '',
      travel_date: '',
      lang_from: '',
      lang_to: '',
      lat_from: '',
      lat_to: '',
      city: '',
      hour: '03',
      minute: '15',
      convention: 'PM',
      id: '',
    };

    this._handleLocalCity = this._handleLocalCity.bind(this);
    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  async _handleLocalCity(data) {
    try {
      await this.setState({
        citydetails: {
          lang: data.geometry.location.lng,
          lat: data.geometry.location.lat,
        },
        selectedCountry: {
          name:
            data.address_components[data.address_components.length - 1]
              .long_name,
          code:
            data.address_components[data.address_components.length - 1]
              .short_name,
        },
        city: data.formatted_address,
        localCityShow: false,
      });
      // console.log(this.state.citydetails, this.state.selectedCountry)
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        address_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  _hourManage(value) {
    this.setState({
      hour: value,
    });
  }

  _minuteManage(value) {
    this.setState({
      minute: value,
    });
  }

  _conventionManage(value) {
    this.setState({
      convention: value,
    });
  }

  async _checkPhone(notify) {
    var data = await this._searchdata();
    if (notify) {
      data.notify = 1;
    } else {
      data.notify = 0;
    }

    var string = {
      items: data,
      isShop: 0,
      isOffer: 0,
      ShopType: 3,
      url: 'add/trip/locally',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await isEmpty(this.props.user)) {
      this.state.navigation.navigate('Login');
      return false;
    }

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this.state.navigation.navigate('EmailPhone');
        return false;
      }
    }

    return true;
  }

  _add_trip = async notify => {
    if (this.state.isAdded) {
      return;
    }

    var isAllow = await this._checkPhone(notify);

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = await this._searchdata();

      if (notify) {
        data.notify = 1;
      } else {
        data.notify = 0;
      }

      let response = await axios.post('add/trip/locally', data);
      await this.setState({
        isAdded: true,
        isLoading: false,
      });
      await Alert.alert('Success', 'Successfully trip added.');
    } catch (error) {
      // console.log(error)
      await this.setState({
        isLoading: false,
      });
      await Alert.alert('Oops!', 'somthing went wrong');
    }
  };

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Add Trip Option?',
      'Do you want notified about new orders',
      [
        {text: 'Yes', onPress: () => this._add_trip(1)},
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
        {text: 'No', onPress: () => this._add_trip(0)},
      ],
      {cancelable: false},
    );
  }

  _assign_data = async order => {
    await this.setState({
      address_from: order.travel_from,
      address_to: order.travel_to,
      travel_date: order.travel_date,
      state_from: order.state_from,
      state_to: order.state_to,
      lang_from: order.lang_from,
      lang_to: order.lang_to,
      lat_from: order.lat_from,
      lat_to: order.lat_to,
      selectedCountry: {code: order.country_code, name: order.country},
      city: order.city_name,
      citydetails: {lat: order.city_lat, lang: order.city_lang},
    });
    return;
  };

  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      travel_to: this.state.address_to,
      country: this.state.selectedCountry.name,
      country_code: this.state.selectedCountry.code,
      city: this.state.city,
      city_lat: this.state.citydetails.lat,
      city_lang: this.state.citydetails.lang,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      hour: this.state.hour,
      minute: this.state.minute,
      convention: this.state.convention,
      isMobile: true,
    };
    return data;
  }

  _search_offer = async () => {
    if (!this.state.address_from) {
      return;
    }

    if (!this.state.address_to) {
      return;
    }

    if (!this.state.selectedCountry.code) {
      return;
    }

    if (!this.state.citydetails.lat) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = await this._searchdata();
      let response = await axios.post('trip/search/locally', data);
      await this._assign_data(response.data[0]);
      await this.setState({
        orders: response.data[1],
        id: response.data[0].id,
        isAdded: false,
        isLoading: false,
      });
      this.props.navigation.navigate('FindOrderLocally', {
        id: response.data[0].id,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  };

  _search_trip = async id => {
    this.setState({
      isLoading: true,
    });

    try {
      let response = await axios.get('trip/search/data/locally/' + id);
      await this._assign_data(response.data[0]);
      await this.setState({
        orders: response.data[1],
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  };

  async componentDidMount() {
    await AsyncStorage.removeItem('submitdata');
    const id = await this.props.navigation.getParam('id');
    await this.setState({
      id: id,
    });
    this._search_trip(id);
  }

  render() {
    const navigate = this.props.navigate;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var addtrip = null;
      if (!this.state.isAdded) {
        var hours = [];
        var minutes = [];

        minutes.push(<Picker.Item key="00" label="00" value="00" />);

        for (let index = 1; index < 25; index++) {
          var hourel = index < 10 ? '0' + index : String(index);
          hours.push(<Picker.Item key={index} label={hourel} value={hourel} />);
        }

        for (let indexel = 1; indexel < 55; indexel++) {
          indexel = indexel + 4;
          var minuteel = indexel < 10 ? '0' + indexel : String(indexel);

          minutes.push(
            <Picker.Item key={indexel} label={minuteel} value={minuteel} />,
          );
        }

        addtrip = (
          <View style={[styles.card, styles.shadow]}>
            <Text
              style={{
                textAlign: 'center',
                fontSize: 22,
                fontFamily: 'Montserrat-semiBold',
                color: '#660165',
              }}>
              Add trip
            </Text>
            <Text
              style={{
                fontSize: 14,
                textAlign: 'center',
                fontFamily: 'Montserrat-Regular',
                marginVertical: 10,
              }}>
              With a trip added, you can make multiple offers and make more
              money.
            </Text>

            <View style={styles.fromgroup}>
              <View>
                <Text style={{fontSize: 16, fontWeight: '600', color: '#000'}}>
                  By What Time You Will Reach There
                </Text>
              </View>

              <Picker
                mode="dropdown"
                iosHeader="Select hour"
                iosIcon={<Icon name="ios-arrow-down-outline" />}
                style={{width: undefined}}
                selectedValue={this.state.hour}
                onValueChange={this._hourManage.bind(this)}>
                {hours}
              </Picker>

              <Picker
                mode="dropdown"
                iosHeader="Select minute"
                iosIcon={<Icon name="ios-arrow-down-outline" />}
                style={{width: undefined}}
                selectedValue={this.state.minute}
                onValueChange={this._minuteManage.bind(this)}>
                {minutes}
              </Picker>

              <Picker
                mode="dropdown"
                iosHeader="Select convention"
                iosIcon={<Icon name="ios-arrow-down-outline" />}
                style={{width: undefined}}
                selectedValue={this.state.convention}
                onValueChange={this._conventionManage.bind(this)}>
                <Picker.Item label="AM" value="AM" />
                <Picker.Item label="PM" value="PM" />
              </Picker>
            </View>
            <View style={styles.fromgroup}>
              <TouchableOpacity onPress={() => this._addTripCondition()}>
                <Text style={styles.Searchbtn}>Add Trip</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      }

      return (
        <View style={styles.containerbox}>
          <ScrollView>
            <View style={[styles.searchordercard, styles.shadow]}>
              <Text
                style={{
                  fontSize: 16,
                  color: '#660165',
                  marginVertical: 10,
                  fontWeight: '700',
                }}>
                YOU ARE SEARCHING ORDERS FOR TRIP:
              </Text>

              <View style={styles.fromgroup}>
                <View style={styles.googlefromGp}>
                  <GooglePlaces
                    defaultText={this.state.city}
                    listDisplayed={this.state.localCityShow}
                    onSelectAddress={this._handleLocalCity}
                    placeHolder="Choose domestic city"
                  />
                </View>
                <View style={styles.googlefromGp}>
                  <GooglePlaces
                    cityDetails={this.state.citydetails}
                    countryCode={this.state.selectedCountry.code}
                    defaultText={this.state.address_from}
                    isLocal={true}
                    listDisplayed={this.state.fromShow}
                    onSelectAddress={this._handleFrom}
                    placeHolder="From locally"
                  />
                </View>

                <View style={styles.googlefromGp}>
                  <GooglePlaces
                    cityDetails={this.state.citydetails}
                    countryCode={this.state.selectedCountry.code}
                    defaultText={this.state.address_to}
                    isLocal={true}
                    listDisplayed={this.state.toShow}
                    onSelectAddress={this._handleTo}
                    placeHolder="To locally"
                  />
                </View>
              </View>

              <View style={styles.fromgroup}>
                <View style={styles.datepiker}>
                  <DatePicker
                    defaultDate={moment(
                      this.state.travel_date,
                      'DD/MM/YYYY',
                    ).toDate()}
                    minimumDate={new Date()}
                    locale={'en'}
                    timeZoneOffsetInMinutes={undefined}
                    modalTransparent={false}
                    animationType={'fade'}
                    androidMode={'default'}
                    placeholder="DD/MM/YYY"
                    textStyle={{color: '#878787'}}
                    placeHolderTextStyle={{color: '#878787'}}
                    onDateChange={this._handleDatePicked}
                    style={{borderWidth: 1}}
                  />
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._search_offer()}>
                  <Text style={styles.Searchbtn}>Find Order</Text>
                </TouchableOpacity>
              </View>
            </View>

            {addtrip}

            <OrderItem
              currency={this.props.currency}
              orders={this.state.orders}
              navigate={navigate}
            />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(FindOrderLocally);
