import React from 'react';
import {Text, View, TouchableOpacity, ScrollView, Alert} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../../assets/css/style';
import GooglePlaces from '../../Common/GooglePlaces';
import {DatePicker} from 'native-base';
import ModalFilterPicker from 'react-native-modal-filter-picker';
import OrderItem from '../../Order/OrderItem';
import OrderSubmitting from '../../Common/OrderSubmitting';
import axios from 'axios';
import {connect} from 'react-redux';
import moment from 'moment';
import isEmpty from 'lodash/isEmpty';

class FindOrderDomestically extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      orders: [],
      isLoading: true,
      visible: false,
      fromShow: false,
      toShow: false,
      isAdded: false,
      selectedCountry: {code: '', name: ''},
      country_list: [],
      address_from: '',
      address_to: '',
      travel_date: '',
      state_to: '',
      state_from: '',
      lang_from: '',
      lang_to: '',
      lat_from: '',
      lat_to: '',
      id: null,
      navigation: props.navigation,
    };
    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  async _countryListCall() {
    try {
      let response = await axios.get('country/list');
      let responses = response.data;

      var countryList = [];
      await responses.forEach(element => {
        countryList.push({key: element.value, label: element.text});
      });

      await this.setState({
        country_list: countryList,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  _handleFrom = async data => {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        state_from: state,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  };

  _handleTo = async data => {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        state_to: state,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  };

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  _onSelect = async picked => {
    try {
      let result = await this._filterResult(picked);
      this.setState({
        selectedCountry: {code: picked, name: result.label},
        visible: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        visible: false,
      });
    }
  };

  async _checkPhone(notify) {
    var data = await this._searchdata();
    if (notify) {
      data.notify = 1;
    } else {
      data.notify = 0;
    }

    var string = {
      items: data,
      isShop: 0,
      isOffer: 0,
      ShopType: 3,
      url: 'add/trip/domestic',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await isEmpty(this.props.user)) {
      this.state.navigation.navigate('Login');
      return false;
    }

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this.state.navigation.navigate('EmailPhone');
        return false;
      }
    }

    return true;
  }

  _add_trip = async notify => {
    if (this.state.isAdded) {
      return;
    }

    var isAllow = await this._checkPhone(notify);

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = await this._searchdata();

      if (notify) {
        data.notify = 1;
      } else {
        data.notify = 0;
      }

      let response = await axios.post('add/trip/domestic', data);
      await this.setState({
        isAdded: true,
        isLoading: false,
      });
      await Alert.alert('Success', 'Successfully trip added.');
    } catch (error) {
      // console.log(error)
      await this.setState({
        isLoading: false,
      });
      await Alert.alert('Opps!', 'somthing went wrong');
    }
  };

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Add Trip Option?',
      'Do you want notified about new orders',
      [
        {text: 'Yes', onPress: () => this._add_trip(1)},
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
        {text: 'No', onPress: () => this._add_trip(0)},
      ],
      {cancelable: false},
    );
  }

  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      travel_to: this.state.address_to,
      country: this.state.selectedCountry.name,
      country_code: this.state.selectedCountry.code,
      state_from: this.state.state_from,
      state_to: this.state.state_to,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      isMobile: true,
    };
    return data;
  }

  _search_offer = async navigate => {
    if (!this.state.address_from) {
      return;
    }

    if (!this.state.address_to) {
      return;
    }

    if (!this.state.selectedCountry.code) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = await this._searchdata();
      let response = await axios.post('trip/search/domestic', data);
      await this._assign_data(response.data[0]);
      await this.setState({
        orders: response.data[1],
        id: response.data[0].id,
        isAdded: false,
        isLoading: false,
      });
      this.props.navigation.navigate('FindOrderDomestically', {
        id: response.data[0].id,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  };

  _assign_data = async order => {
    await this.setState({
      address_from: order.travel_from,
      address_to: order.travel_to,
      travel_date: order.travel_date,
      country: order.country,
      country_code: order.country_code,
      state_from: order.state_from,
      state_to: order.state_to,
      lang_from: order.lang_from,
      lang_to: order.lang_to,
      lat_from: order.lat_from,
      lat_to: order.lat_to,
      selectedCountry: {code: order.country_code, name: order.country},
    });
    return;
  };

  _search_trip = async id => {
    this.setState({
      isLoading: true,
    });
    try {
      let response = await axios.get('trip/search/data/domestic/' + id);
      await this._assign_data(response.data[0]);
      await this.setState({
        orders: response.data[1],
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  };

  async componentDidMount() {
    await AsyncStorage.removeItem('submitdata');
    const id = await this.props.navigation.getParam('id');
    await this.setState({
      id: id,
    });
    this._search_trip(id);
    this._countryListCall();
  }

  render() {
    const navigate = this.props.navigate;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var addtrip = null;
      if (!this.state.isAdded) {
        addtrip = (
          <View style={[styles.card, styles.shadow]}>
            <Text
              style={{
                textAlign: 'center',
                fontSize: 22,
                fontFamily: 'Montserrat-semiBold',
                color: '#660165',
              }}>
              Add trip
            </Text>
            <Text
              style={{
                fontSize: 14,
                textAlign: 'center',
                fontFamily: 'Montserrat-Regular',
                marginVertical: 10,
              }}>
              With a trip added, you can make multiple offers and make more
              money.
            </Text>

            <View style={styles.fromgroup}>
              <TouchableOpacity onPress={() => this._addTripCondition()}>
                <Text style={styles.Searchbtn}>Add Trip</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      }
      return (
        <View style={styles.containerbox}>
          <ScrollView>
            <View style={[styles.searchordercard, styles.shadow]}>
              <Text
                style={{
                  fontSize: 16,
                  color: '#660165',
                  marginVertical: 10,
                  fontWeight: '700',
                }}>
                YOU ARE SEARCHING ORDERS FOR TRIP:
              </Text>
              <View style={styles.fromgroup}>
                <TouchableOpacity
                  onPress={() => this.setState({visible: true})}
                  style={styles.gpcountery}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: '#5d5d5d',
                      textAlign: 'left',
                      width: '100%',
                      paddingLeft: 25,
                    }}>
                    {this.state.selectedCountry.name
                      ? this.state.selectedCountry.name
                      : 'Country'}
                  </Text>
                </TouchableOpacity>
                <ModalFilterPicker
                  visible={this.state.visible}
                  onSelect={this._onSelect}
                  onCancel={() => this.setState({visible: false})}
                  options={this.state.country_list}
                />
              </View>
              <View style={styles.fromgroup}>
                <View style={styles.googlefromGp}>
                  <GooglePlaces
                    countryCode={this.state.selectedCountry.code}
                    defaultText={this.state.address_from}
                    listDisplayed={this.state.fromShow}
                    onSelectAddress={this._handleFrom}
                    placeHolder="From city"
                  />
                </View>

                <View style={styles.googlefromGp}>
                  <GooglePlaces
                    countryCode={this.state.selectedCountry.code}
                    defaultText={this.state.address_to}
                    listDisplayed={this.state.toShow}
                    onSelectAddress={this._handleTo}
                    placeHolder="To city"
                  />
                </View>
              </View>

              <View style={styles.fromgroup}>
                <View style={styles.datepiker}>
                  <DatePicker
                    defaultDate={moment(
                      this.state.travel_date,
                      'DD/MM/YYYY',
                    ).toDate()}
                    minimumDate={new Date()}
                    locale={'en'}
                    timeZoneOffsetInMinutes={undefined}
                    modalTransparent={false}
                    animationType={'fade'}
                    androidMode={'default'}
                    placeholder="DD/MM/YYY"
                    textStyle={{color: '#878787'}}
                    placeHolderTextStyle={{color: '#878787'}}
                    onDateChange={this._handleDatePicked}
                    style={{borderWidth: 1}}
                  />
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._search_offer(navigate)}>
                  <Text style={styles.Searchbtn}>Find Order</Text>
                </TouchableOpacity>
              </View>
            </View>

            {addtrip}

            <OrderItem
              currency={this.props.currency}
              orders={this.state.orders}
              navigate={navigate}
            />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(FindOrderDomestically);
