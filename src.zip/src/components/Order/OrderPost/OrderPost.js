import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  BackHandler,
  Alert,
  TouchableHighlight,
  RefreshControl,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../assets/css/style';
import axios from 'axios';
import {STORAGE_URL} from '../../../config/env';
import OrderSubmitting from '../../Common/OrderSubmitting';
import NonScreenHeader from '../../Menu/NonScreenHeader';
import {connect} from 'react-redux';
import OfferedItem from '../Offer/OfferedItem';
import ImageComponent from '../../Account/Chat/ImageComponent';

class OrderPost extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      isLoading: true,
      refreshing: false,
      imageUri: null,
      offers: [],
      slug: null,
    };

    this.imageCdn = this.imageCdn.bind(this);
  }

  static navigationOptions = ({navigation}) => {
    return {
      title: null,
      header: <NonScreenHeader navigate={navigation} title="Order" />,
    };
  };

  imageCdn(url) {
    return STORAGE_URL + url;
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
    const slug = this.props.navigation.getParam('slug');
    this.order(slug, 0);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  async order(slug, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
        slug,
      });
    }
    try {
      let response = await axios.get('order/' + slug);

      this.setState({
        order: response.data.data,
        imageUri: response.data.data.images[0],
        offers: response.data.data.offers,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      if (type) {
        await this.setState({
          refreshing: false,
        });
      } else {
        await Alert.alert('Oops!', 'No order data found!');
        this.props.navigation.navigate('Home');
      }
    }
  }

  _handleSendMessageModal() {
    // console.log("dff");
  }

  auth_serv_fee_element(order) {
    if (order.isSameUser) {
      return (
        <View style={[styles.profilepricefinal, styles.borderBottom]}>
          <Text style={styles.priceall}>Service Fee & Taxes</Text>
          <Text style={[styles.priceall, styles.colorpurple]}>
            {' '}
            {this.props.currency} {order.ser_taxes_fee}
          </Text>
        </View>
      );
    }
    return null;
  }

  _sendMessageElement(order, navigate) {
    if (!order.isSameUser) {
      if (order.chatRoomId > 0) {
        return (
          <TouchableOpacity
            style={[styles.sendmassagebtn]}
            onPress={() => {
              navigate('Chat', {slug: order.slug, chatID: order.chatRoomId});
            }}>
            <Text
              style={{color: '#fff', paddingRight: 10, alignItems: 'center'}}>
              <FontAwesome name="envelope" size={22} />
            </Text>
            <Text
              style={{
                fontFamily: 'Montserrat-semiBold',
                fontSize: 15,
                color: '#fff',
                alignItems: 'center',
              }}>
              Send message
            </Text>
          </TouchableOpacity>
        );
      } else {
        return (
          <TouchableOpacity
            style={[styles.sendmassagebtn]}
            onPress={() => {
              // console.log('send message pressed');
              // this._handleSendMessageModal();
              navigate('Chat', {slug: order.slug, chatID: order.chatRoomId});
            }}>
            <Text
              style={{color: '#fff', paddingRight: 10, alignItems: 'center'}}>
              <FontAwesome name="envelope" size={22} />
            </Text>
            <Text
              style={{
                fontFamily: 'Montserrat-semiBold',
                fontSize: 15,
                color: '#fff',
                alignItems: 'center',
              }}>
              Send message
            </Text>
          </TouchableOpacity>
        );
      }
    } else {
      return null;
    }
  }

  render() {
    console.log('in order post.');
    if (this.state.isLoading && !this.state.imagePopUp) {
      return <OrderSubmitting />;
    } else if (!this.state.isLoading && this.state.imagePopUp) {
      return (
        <ImageComponent
          imageUrl={this.state.imageUri}
          OnlyImage={true}
          onClose={() => this.setState({imagePopUp: false, isLoading: false})}
        />
      );
    } else {
      const {navigate} = this.props.navigation;
      const order = this.state.order;
      if (!order) {
        return null;
      }
      var makeofferElement = null;
      if (!order.isSameUser && order.avlForOffer) {
        makeofferElement = (
          <TouchableOpacity
            style={[styles.sendmassagebtn]}
            onPress={() => navigate('MakeOffer', {slug: order.slug})}>
            <Text
              style={{
                color: '#fff',
                paddingRight: 10,
                alignItems: 'center',
                fontFamily: 'Montserrat-semiBold',
                fontSize: 15,
              }}>
              Make Offer
            </Text>
          </TouchableOpacity>
        );
      } else if (!order.isSameUser && !order.avlForOffer) {
        makeofferElement = (
          <TouchableOpacity style={[styles.sendmassagebtndisabel]}>
            <Text
              style={{
                color: '#fff',
                paddingRight: 10,
                alignItems: 'center',
                fontFamily: 'Montserrat-semiBold',
                fontSize: 15,
              }}>
              Make Offer Disable
            </Text>
          </TouchableOpacity>
        );
      } else {
        makeofferElement = null;
      }

      var useravatar = null;
      if (!order.user_avatar) {
        useravatar = this.imageCdn('static/assets/images/profile-up-img.png');
      } else {
        useravatar = order.user_avatar;
      }

      return (
        <View style={styles.container}>
          <ScrollView
            style={{width: '98%'}}
            refreshControl={
              <RefreshControl
                refreshing={this.state.refreshing}
                onRefresh={() => this.order(this.state.slug, 1)}
                style={{backgroundColor: 'transparent'}}
              />
            }>
            <View style={[styles.card, styles.shadow]}>
              <View style={styles.box}>
                <View style={styles.gridfitsmImage}>
                  <Image
                    source={{uri: useravatar}}
                    style={{height: 100, width: 100, borderRadius: 50}}
                  />
                </View>

                <Text style={styles.requestingname}>
                  <Text
                    style={[styles.strong, styles.isrequesting_order]}
                    onPress={() =>
                      navigate('UserProfile', {userName: order.userName})
                    }>
                    {' '}
                    {order.posted_by}
                  </Text>
                  <Text style={styles.isrequesting_order}> is requesting </Text>
                  <Text style={[styles.colorpurple, styles.isrequesting_order]}>
                    {' '}
                    {order.name_item}
                  </Text>
                </Text>

                <Text style={styles.requestingname}>
                  <Text> on </Text>
                  <Text style={[styles.colorpurple, styles.isrequesting_order]}>
                    {' '}
                    {order.delivery_date}
                  </Text>
                </Text>

                <Text
                  style={{
                    fontFamily: 'Montserrat-semiBold',
                    fontSize: 19,
                    color: '#000',
                    textAlign: 'center',
                    marginVertical: 10,
                  }}>
                  Delivery Reward
                  <Text style={styles.colorpurple}>
                    {' '}
                    {this.props.currency} {order.traveller_fee}
                  </Text>
                </Text>

                {makeofferElement}

                {this._sendMessageElement(order, navigate)}

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>From</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {' '}
                    {order.delivery_from_no_limit}
                  </Text>
                </View>

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>To</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {' '}
                    {order.delivery_to_no_limit}
                  </Text>
                </View>

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Item Price</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {' '}
                    {this.props.currency} {order.price_item}
                  </Text>
                </View>

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Quantity</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {' '}
                    {order.quantity}
                  </Text>
                </View>

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Delivery Fee</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {this.props.currency} {order.traveller_fee}
                  </Text>
                </View>

                {order.isPaylater ? null : this.auth_serv_fee_element(order)}

                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Total Amount</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {' '}
                    {this.props.currency}{' '}
                    {order.isSameUser
                      ? order.isPaylater
                        ? order.subTotal
                        : order.total_price
                      : order.subTotal}
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.card, styles.shadow]}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({imagePopUp: true, isLoading: false})
                }>
                <Image
                  style={styles.fitImage}
                  source={{
                    uri: this.state.imageUri,
                  }}
                  resizeMode="contain"
                  style={{height: 200}}
                />
              </TouchableOpacity>

              <View style={styles.imagegrid}>
                {order.images.map((image, index) => {
                  return (
                    <View key={index} style={styles.gridfitImage}>
                      <TouchableHighlight
                        onPress={() => this.setState({imageUri: image})}>
                        <Image
                          source={{
                            uri: image,
                          }}
                          resizeMode="contain"
                          style={{height: 80, width: 80}}
                        />
                      </TouchableHighlight>
                    </View>
                  );
                })}
              </View>

              <View style={styles.hrborder} />

              <View style={styles.box}>
                <Text style={styles.prodectname}>{order.name_item}</Text>
                <Text style={styles.allparegraph}>{order.description} </Text>
              </View>
            </View>

            <OfferedItem offers={this.state.offers} />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(OrderPost);
