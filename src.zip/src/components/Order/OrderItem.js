import React from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  Dimensions,
  Platform, ImageBackground
} from 'react-native';
import styles from '../../../assets/css/style';
import { STORAGE_URL } from '../../config/env';
import { connect } from 'react-redux';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import Entypo from 'react-native-vector-icons/Entypo';
import Share from 'react-native-share';
import { TouchableHighlight } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';

class OrderItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      navigation: this.props.navigation,
      orders: this.props.orders,
      activeSlide: 0,
      isShare: false,
      viewport: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
      },
    };

    this.imageCdn = this.imageCdn.bind(this);
  }

  async _handleShare(order) {
    try {
      let shareOptions = {
        title: order.name_item_lm,
        message: 'Bring now',
        url: 'https://flypur.com/order-post/' + order.slug,
        subject: 'Share Link',
      };
      let res = await Share.open(shareOptions);
    } catch (error) {
      console.log(error);
    }
  }

  get pagination() {
    const { orders, activeSlide } = this.state;
    return (
      <Pagination
        dotsLength={orders.length}
        activeDotIndex={activeSlide}
        containerStyle={{ backgroundColor: '#ffffff' }}
        dotStyle={{
          width: 10,
          height: 10,
          borderRadius: 5,
          marginHorizontal: 0,
          backgroundColor: '#660165',
        }}
        inactiveDotStyle={{
          // Define styles for inactive dots here
          backgroundColor: '#000',
        }}
        inactiveDotOpacity={0.3}
        inactiveDotScale={0.6}
      />
    );
  }

  imageCdn = url => {
    return STORAGE_URL + url;
  };

  _renderItem = (item, index) => {
    var order = item.item;
    var useravatar = null;
    var offerElement = null;
    if (!order.user_avatar) {
      useravatar = this.imageCdn('static/assets/images/profile-up-img.png');
    } else {
      useravatar = order.user_avatar;
    }

    if (!order.isSameUser && order.avlForOffer) {
      offerElement = (
        <TouchableOpacity
          style={[{ width: 120, borderRadius: 5, marginRight: 40, justifyContent: 'center' }]}

          onPress={() => this.props.push('MakeOffer', { slug: order.slug })}>

          <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#381337', '#610760', '#381337']} style={styles.linearGradient}>
            <Text style={[styles.offer,{ width: '100%', textAlign: 'center' }]}>Make offer</Text>

          </LinearGradient>

        </TouchableOpacity>
      );
    } else if (order.isSameUser && !order.avlForOffer) {
      offerElement = (
        <TouchableOpacity
          style={[{ width: 120, borderRadius: 5, marginRight: 40, justifyContent: 'center' }]}
        >
          <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#381337', '#57B793', '#381337']} style={styles.linearGradient}>

            <Text style={[styles.offer,{ width: '100%', textAlign: 'center' }]}>
              Make offer
          </Text>
          </LinearGradient>

        </TouchableOpacity>
      );
    } else {
      offerElement = null;
    }

    return (
      <View style={[]}>
        <View style={[styles.orderitemcard, styles.shadow, { borderRadius: 15,margin:5}]}>
          {/* <View style={styles.share_order}>
          {Platform.OS === 'ios' ? (
            <TouchableHighlight onPress={() => this._handleShare(order)}>
              <Entypo name="share" size={25} style={{color: '#660165'}} />
            </TouchableHighlight>
          ) : (
            <TouchableOpacity onPress={() => this._handleShare(order)}>
              <Entypo name="share" size={25} style={{color: '#660165'}} />
            </TouchableOpacity>
          )}
        </View> */}
          {/* <View style={styles.descrcontainer}>
          <Image source={{uri: useravatar}} style={styles.sm_user_fit} />
          <View style={styles.itemtitel}>
            <TouchableOpacity style={{flexDirection: 'row'}}>
              <Text
                style={[styles.itemname, styles.colorpurple]}
                onPress={() =>
                  this.props.push('UserProfile', {userName: order.userName})
                }>
                {order.posted_by}
              </Text>
              <Text style={styles.itemname}> Is Requesting </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.shoptab}
              onPress={() => this.props.push('OrderPost', {slug: order.slug})}>
              <Text style={[styles.itemname, styles.colorpurple]}>
                {' '}
                {order.name_item_lm}
              </Text>
            </TouchableOpacity>
          </View>
        </View> */}

          <Image
            style={styles.fitImage}
            source={{ uri: order.images[0] }}
            resizeMode="contain"
            style={{ height: 200, width: "100%",elevation:5,}}
          />
          {/* styles.adressbox */}
          <View style={{
            marginLeft: 20, marginRight: 20, justifyContent: 'center', backgroundColor: '#F2F2F4', borderBottomLeftRadius: 20
            , borderBottomRightRadius: 20, elevation: 5,
          }}>
            <View style={[styles.addresslistbox,]}>
              <Text style={styles.addresstitel}>Delivery From : </Text>
              <Text style={[styles.addressTitle,]}>
                {' '}
                {order.delivery_from}{' '}
              </Text>
            </View>
            <View style={[styles.addresslistbox,]}>
              <Text style={styles.addresstitel}>Deliver To : </Text>
              <Text style={[styles.addressTitle,]}>
                {' '}
                {order.delivery_to_lm}{' '}
              </Text>
            </View>
            <View style={[styles.addresslistbox,]}>
              <Text style={styles.addresstitel}>Delivery Date: </Text>
              <Text style={[styles.addressTitle,]}>
                {' '}
                {order.delivery_date}
              </Text>
            </View>
          </View>

          <View style={styles.pricebox}>
            <View style={[styles.pricemain, { marginLeft: 20 }]}>
              <Text style={styles.pricetitel}> Item Price</Text>
              <Text style={[styles.pricetitel, styles.colorpurple]}>
                {this.props.currency} {order.price_item}
              </Text>
            </View>
            <View style={[styles.pricemain,]}>
              <Text style={styles.pricetitel}> Traveller Price</Text>
              <Text style={[styles.pricetitel, styles.colorpurple]}>
                {this.props.currency} {order.traveller_fee}
              </Text>
            </View>
            <View style={[styles.pricemain, { marginRight: 20 }]}>
              <Text style={styles.pricetitel}> Quantity</Text>
              <Text style={[styles.pricetitel, styles.colorpurple]}>
                {' '}
                {order.quantity}
              </Text>
            </View>
          </View>


        </View>

        <View style={styles.offercontainer}>
          <TouchableOpacity
            style={[{  width: 100, borderRadius: 5, marginLeft: 40, justifyContent: 'center' }]}
            onPress={() =>
              order.isSameUser
                ? this.props.push('AllOffers', { slug: order.slug })
                : this.props.push('OrderPost', { slug: order.slug })
            }>
            <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#2E8A67', '#57B793', '#2E8A67']} style={styles.linearGradient}>

              <Text style={[styles.offer, { textAlign: 'center' }]}>
                {' '}
                {/* {order.countOffer}  */}
                Offer
            </Text>
            </LinearGradient>
          </TouchableOpacity>
          {/* {order.isPaylater ? <Text style={[styles.offer, styles.pay_later]} >Pay Later</Text> : null} */}
          {/* <TouchableOpacity>
            <Text>Chat Now</Text>
          </TouchableOpacity> */}

          {offerElement}
        </View>
      </View>


    );
  };

  render() {
    let orders = this.props.orders;
    if (orders.length > 0) {
      return (
        <View
          style={styles.container}
          onLayout={() => {
            this.setState({
              viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height,
              },
            });
          }}>
          <Text style={styles.allheading}>Recent Orders</Text>
          <Carousel
            ref={c => {
              this._carousel = c;
            }}
            data={orders}
            renderItem={this._renderItem}
            sliderWidth={this.state.viewport.width}
            itemWidth={this.state.viewport.width}
            onSnapToItem={index => this.setState({ activeSlide: index })}
          />
          {this.pagination}
        </View>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(OrderItem);
