import React from 'react';
import {Text, View, Image, TouchableOpacity} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../assets/css/style';
import {STORAGE_URL} from '../../../config/env';
import {connect} from 'react-redux';
import moment from 'moment';

class OfferedItem extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        {this.props.offers.length > 0 ? (
          <Text style={styles.allheading}> DELIVERY OFFERS </Text>
        ) : null}

        {this.props.offers.map((offer, index) => {
          var ratings = [];
          for (let i = 1; i < 6; i++) {
            var ratingname = offer.userRating >= i ? 'star' : 'star-o';
            ratings.push(
              <FontAwesome
                key={i}
                name={ratingname}
                size={16}
                style={{color: '#660165'}}
              />,
            );
          }

          return (
            <View key={index} style={[styles.shadow, styles.deloffer]}>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    justifyContent: 'flex-start',
                  }}>
                  <Image
                    source={{
                      uri: offer.avatar
                        ? offer.avatar
                        : STORAGE_URL +
                          'static/assets/images/profile-up-img.png',
                    }}
                    resizeMode="cover"
                    style={styles.sm_user_fit}
                  />
                  <View
                    style={{
                      flexDirection: 'column',
                      justifyContent: 'flex-start',
                      marginLeft: 7,
                      marginTop: 5,
                    }}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'flex-start',
                        width: '100%',
                      }}>
                      <TouchableOpacity>
                        <Text
                          style={{
                            color: '#660165',
                            fontSize: 16,
                            fontFamily: 'Montserrat-semiBold',
                          }}>
                          {offer.offer_by}
                        </Text>
                      </TouchableOpacity>
                      <Text>
                        {' '}
                        {moment(offer.created_at)
                          .utcOffset('+0000')
                          .fromNow()}{' '}
                      </Text>
                    </View>
                    <View>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          width: 100,
                          marginTop: 5,
                        }}>
                        {ratings}
                      </View>
                    </View>
                    <View style={{width: '100%', marginTop: 5}}>
                      <Text
                        style={{
                          fontSize: 20,
                          color: '#660165',
                          fontFamily: 'Montserrat-semiBold',
                        }}>
                        Offer Price {this.props.currency} {offer.total}
                      </Text>
                    </View>

                    <View style={{marginVertical: 5, flex: 1}}>
                      <Text
                        style={{
                          fontSize: 16,
                          color: '#000',
                          fontFamily: 'Montserrat-semiBold',
                        }}>
                        Delivery From
                        <Text
                          style={{
                            fontSize: 16,
                            color: '#660165',
                            fontFamily: 'Montserrat-semiBold',
                          }}>
                          {' '}
                          {offer.travel_from}
                        </Text>
                      </Text>
                      <Text
                        style={{
                          fontFamily: 'Montserrat-Regular',
                          fontSize: 14,
                        }}>
                        On{' '}
                        {moment(offer.delivery_date)
                          .utcOffset('+0530')
                          .format('DD/MM/YYYY')}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          );
        })}
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(OfferedItem);
