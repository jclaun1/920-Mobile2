import React from 'react'
import { Text, View, TouchableOpacity, TextInput, ScrollView, Image, Modal, ImageBackground } from 'react-native'
import styles from '../../../../assets/css/style'
import { TextInputLayout } from 'rn-textinputlayout';
import FlyButton from '../../Common/FlyButton';
import { LinearGradient } from 'react-native-linear-gradient';


export default class OfferDeliveredModel extends React.Component {

    constructor(props) {
        super(props)
       
    }
    state = {

        isLoading: true
    }
    async _handleSubmit() {
        this.props.onClose(true);

    }

    render() {

        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.isLoading}
                onRequestClose={() => {
                    this.props.onClose(false)
                }}
            >
                <View style={[{ width: "100%", height: "100%" }]}>

                    <ImageBackground style={{ flex: 1.5, width: '100%', paddingTop:-100,
                    justifyContent:'center',alignItems:'center',resizeMode: 'stretch',
                     borderBottomLeftRadius: 50, borderBottomRightRadius: 50, }}
                        source={require('../../../../assets/images/bg_order_success.png')}
                    >
                        <View style={{
                            flex:1, resizeMode: 'stretch', alignSelf: 'center',
                             justifyContent:'center',alignItems:'center',marginTop:50,
                        }}>
                            <Image
                                style={{
                                    height: 200, width: 200, resizeMode: 'stretch', alignSelf: 'center'
                                }}
                                source={require('../../../../assets/images/ic_order_submittd.png')}
                            />
                        </View>
                    </ImageBackground>

                    

                    <View style={{ flex: 1,alignItems:'center',justifyContent:'space-around' }}>
                    <Image
                                style={{
                                    height: 100, width:140, resizeMode: 'stretch', alignSelf: 'center'
                                }}
                                source={require('../../../../assets/images/ic_tick.png')}
                            />

                            <Text style={{color:'#000000',fontSize:20, fontFamily: 'OpenSans-semiBold',}}>
                            Thanks for the Offer</Text>

                            <Text style={{color:'#707070',fontSize:14, fontFamily: 'OpenSans-regular',}}>
                            Your Offer was successful</Text>
                        <View style={{ flexDirection: 'column', width: "90%", justifyContent: "center", marginTop: 20, alignSelf: 'center' }}>
                            <FlyButton style={{ width: 200,alignSelf:'center' }} onPress={() =>this.setState({
                                isLoading:false
                            })} title="Continue" />
                        </View>


                    </View>


                </View>

            </Modal>
        );

    }
}
