import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  StatusBar,
  Platform, ImageBackground, Dimensions
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import Ionicons from 'react-native-vector-icons/Ionicons';
import styles from '../../../../assets/css/style';
import axios from 'axios';
import { STORAGE_URL } from '../../../config/env';
import OrderSubmitting from '../../Common/OrderSubmitting';
import GooglePlaces from '../../Common/GooglePlaces';
import { connect } from 'react-redux';
import { DatePicker } from 'native-base';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';
import isEmpty from 'lodash/isEmpty';
import errorMessage from '../../../lib/errors';
import { TouchableHighlight } from 'react-native-gesture-handler';
import FlyButton from '../../Common/FlyButton';
import Steps from '../../Common/Steps';
import NewHeader from '../../Menu/NewHeader';
import InputFieldWithIcon from '../../Common/InputFieldWithIcon';
import OfferDeliveredModel from '../Offer/OfferDeliveredModel';
const fontsizerHeight = Dimensions.get('window').height;

class MakeOffer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      isLoading: true,
      address_to: '',
      address_from: '',
      traveller_fee: '',
      message: '',
      traveldate: moment().format('DD/MM/YYYY'),
      citydetails: {},
      delivery_date: null,
      navigation: props.navigation,
      subTotal: 0,
      step: 1,
      fromShow: false,

      travellerPicker: false,
      travellerPicked: Date.now(),
      deliveryPicker: false,
      deliveryPicked: Date.now(),
    };

    this.imageCdn = this.imageCdn.bind(this);
    this._next = this._next.bind(this);
    this._handleFrom = this._handleFrom.bind(this);
  }

  // static navigationOptions = {
  //   headerStyle: {
  //     backgroundColor: '#660165',
  //   },
  //   headerTintColor: '#fff',
  //   headerTitleStyle: {
  //     fontWeight: 'bold',
  //   },
  // };


  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Messages',
      header: <NewHeader type="2" title="Offer Now" navigate={navigation} />,
    };
  };


  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      lang_from: this.state.lang_from,
      lat_from: this.state.lat_from,
      state_from: this.state.state_from,
      travel_date: moment(this.state.traveldate, 'DD/MM/YYYY').format(
        'YYYY-MM-DD',
      ),
      delivery_date: moment(this.state.delivery_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD',
      ),
      delivery_fee: this.state.traveller_fee,
      msg: this.state.message,
      isMobile: true,
    };
    return data;
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        {
          text: 'Okay',
          onPress: () => this.state.navigation.navigate('EmailPhone'),
        },
        { text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel' },
      ],
      { cancelable: false },
    );
  }

  async _checkPhone() {
    var data = this._searchdata();

    var string = {
      items: data,
      isShop: 0,
      ShopType: 3,
      isOffer: 1,
      url: 'add/offer/' + this.state.order.slug,
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (isEmpty(this.props.user)) {
      this.state.navigation.navigate('Login');
      return false;
    }

    if (!isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition();
        return false;
      }
    }

    return true;
  }

  async _make_offer() {
    var isAllow = await this._checkPhone();

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = this._searchdata();
      await axios.post('add/offer/' + this.state.order.slug, data);
      this.setState({
        isLoading: false,
      });
      // Alert.alert('Success', 'Offer Successfully added');
      this.setState({ step: 4 })
      this.props.navigation.navigate('Home');
    } catch (error) {
      console.log(error);
      this.setState({
        isLoading: false,
      });
      let msg = errorMessage(error.response);
      Alert.alert('Oops!', msg);
    }
  }

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  async _handleFrom(data) {
    try {
      var state = null;
      if (this.state.order.order_type == 2) {
        state = await this._findStates(data.address_components);
      }
      this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        state_from: state,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  }

  _handleDatePicked = (event, date) => {
    this.setState({
      traveldate: moment(date).format('DD/MM/YYYY'),
      travellerPicked: new Date(date),
      travellerPicker: false,
    });
  };

  //travel date end

  _handleDatePickedDelivery = (event, date) => {
    this.setState({
      delivery_date: moment(date).format('DD/MM/YYYY'),
      deliveryPicked: new Date(date),
      deliveryPicker: false,
    });
  };

  //delivery date end

  imageCdn(url) {
    return STORAGE_URL + url;
  }

  _next = key => {
    if (
      !this.state.address_to ||
      !this.state.address_from ||
      !this.state.traveller_fee ||
      !this.state.traveldate
    ) {
      return;
    }

    if (this.state.step) {
      this.setState({
        step: key,
      });
    }
  };

  _numberFormate(fee) {
    // return new Intl.NumberFormat().format(fee)
    return fee.toLocaleString('en-IN', { maximumSignificantDigits: 3 });
  }

  _totalnumberFormate(subTotal, travellerFee) {
    return this._numberFormate(subTotal + parseFloat(travellerFee));
  }

  async order(slug) {
    try {
      let response = await axios.get('order/' + slug);
      let orderData = response.data.data;

      let subtotal = parseFloat(orderData.price_item_nor) * orderData.quantity;
      this.setState({
        order: orderData,
        subtotal,
        citydetails: { lat: orderData.city_lat, lang: orderData.city_lang },
        lang_from: orderData.lang_from,
        lat_from: orderData.lat_from,
        address_from: orderData.delivery_from_no_limit,
        address_to: orderData.delivery_to_no_limit,
        traveller_fee: orderData.traveller_fee_nor,
        delivery_date: moment(orderData.delivery_date, 'DD MMMM, YYYY').format(
          'DD/MM/YYYY',
        ),
        deliveryPicked: new Date(orderData.delivery_date),
        message: `Hi, ${orderData.posted_by} I will be traveling to ${
          orderData.delivery_to
          } and I can make the purchase for your item and can bring along with me on my trip ${
          response.data.data.delivery_date
          }. I wait for you to accept my offer, Cheers :) If you need anything else from ${
          response.data.data.delivery_from
          } or have a question in mind don’t hesitate to contact me :)`,
        isLoading: false,
      });
    } catch (error) {
      Alert.alert('Oops!', 'No order data found!');
      this.props.navigation.navigate('Home');
    }
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
  }

  componentDidMount() {
    const slug = this.props.navigation.getParam('slug');
    this.order(slug);
  }

  _googleElement(order) {
    if (order.order_type == 1) {
      return (
        <View>
          <Text style={styles.inputlabel}>From</Text>
          <View>
            <GooglePlaces
              listDisplayed={this.state.fromShow}
              countryCode={order.country_code}
              defaultText={this.state.address_from}
              onSelectAddress={this._handleFrom}
              placeHolder="From city/country"
            />
          </View>
        </View>
      );
    } else if (order.order_type == 2) {
      return (
        <View>
          <Text style={styles.inputlabel}>From Country:</Text>
          <TextInput
            editable={false}
            style={styles.inputbox}
            value={order.country}
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
          />
          <Text style={styles.inputlabel}>From</Text>
          <GooglePlaces
            listDisplayed={this.state.fromShow}
            countryCode={order.country_code}
            defaultText={this.state.address_from}
            onSelectAddress={this._handleFrom}
            placeHolder="From city/country"
          />
        </View>
      );
    } else {
      return (
        <View>
          <Text style={styles.inputlabel}>From Local City:</Text>
          <TextInput
            editable={false}
            style={styles.inputbox}
            value={order.city_name}
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
          />
          <Text style={styles.inputlabel}>From</Text>
          <GooglePlaces
            cityDetails={this.state.citydetails}
            countryCode={order.country_code}
            defaultText={this.state.address_from}
            isLocal={true}
            listDisplayed={this.state.fromShow}
            onSelectAddress={this._handleFrom}
            placeHolder="From locally"
          />
        </View>
      );
    }
  }

  elementOrder(order) {
    if (this.state.step == 1) {
      return (
        <View>
          <View style={[styles.card, { marginHorizontal: 10, width: '95%' }]}>
            <View style={styles.pricefinalVertical}>
              <Text style={styles.priceall}>Item Price</Text>
              <Text style={[styles.priceall, styles.price]}>
                {this.props.currency} {order.price_item}
              </Text>
            </View>
            <View style={[styles.productnamedec, styles.shadow]}>


              <ImageBackground

                source={{ uri: order.images[0] }}
                resizeMode="contain"
                style={{ width: '100%', marginTop: 10, height: '90%', alignSelf: 'center', flexGrow: 1, justifyContent: 'flex-end' }}
              >
                <View style={[styles.productNameOnCard, {}]} >
                  <Text
                    style={{
                      fontSize: 14,
                      color: '#2C2B2B',
                      fontFamily: 'OpenSans-semiBold',
                      marginHorizontal: 10,
                    }}>
                    {order.name_item}
                  </Text>

                </View>
              </ImageBackground>
            </View>
            <View style={[styles.fromgroup, styles.borderBottom]}>
              <Text
                style={{
                  fontSize: 14,
                  color: '#2C2B2B',
                  fontFamily: 'OpenSans-regular',
                }}>
                {order.description}
              </Text>
              {/* <View style={styles.showdetails}>
            <Text
              style={{
                fontSize: 17,
                fontFamily: 'OpenSans-semiBold',
                color: '#660165',
              }}>
              Show order details
            </Text>
            <Ionicons
              name="ios-arrow-down"
              size={22}
              style={{ color: '#660165' }}
            />
          </View>
*/}

              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Delivery Fee</Text>
                <Text style={[styles.priceall,]}>
                  {this.props.currency} {this.state.traveller_fee}
                </Text>
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Item Quantity</Text>
                <Text style={[styles.priceall,]}>
                  {order.quantity}
                </Text>
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Total Amount</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency}{' '}
                  {this._totalnumberFormate(
                    parseFloat(order.price_item_nor) * order.quantity,
                    this.state.traveller_fee,
                  )}
                </Text>
              </View>
            </View>

            {/* <Text style={{ fontSize: 13, fontFamily: 'OpenSans-regular' }}>
          (Actual rate may vary at time of payout due to dollar index and
          conversion charges.)<Text style={{ color: 'red' }}> *</Text>
        </Text> */}
          </View>
          <View style={[styles.card,]}>
            {/* <View style={styles.fromgroup}>
            <Text
              style={{
                fontSize: 18,
                color: '#660165',
                fontFamily: 'OpenSans-semiBold',
                marginBottom: 5,
              }}>
              Add Your trip details to make offer
            </Text>
            <Text
              style={{
                marginBottom: 10,
                fontSize: 14,
                fontFamily: 'OpenSans-regular',
              }}>
              Please tell us from where you are travelling and to where ? on
              what date.
            </Text>
          </View> */}
            <View style={styles.fromgroup}>{this._googleElement(order)}</View>

            <View style={styles.fromgroup}>
              <View>
                <Text style={styles.inputlabel}>To</Text>
              </View>
              <TextInput
                editable={false}
                style={{ color: '#242134' }}
                onChangeText={address_to => this.setState({ address_to })}
                value={this.state.address_to}
                placeholderTextColor="#878787"
                underlineColorAndroid="rgba(0, 0, 0,0)"
              />
            </View>
            {/* <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                Item Price({this.props.currency})
              </Text>
            </View>
            <TextInput
              editable={false}
              style={styles.inputbox}
              value={order.price_item}
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
            />
          </View> */}
            <View style={styles.fromgroup}>
              <View>
                <Text style={styles.inputlabel}>Travelling Date</Text>
              </View>
              <View style={styles.datepikerradius}>
                {/* <DatePicker
                            defaultDate={new Date()}
                            minimumDate={new Date()}
                            maximumDate={new Date(order.delivery_date_format)}
                            locale={"en"}
                            timeZoneOffsetInMinutes={undefined}
                            modalTransparent={false}
                            animationType={"fade"}
                            androidMode={"default"}
                            placeholder="DD/MM/YYY"
                            textStyle={{ color: "#878787" }}
                            placeHolderTextStyle={{ color: "#878787" }}
                            onDateChange={this._handleDatePicked}
                            style={{borderWidth:1,}}
                        /> */}

                {this.state.travellerPicker && (
                  <DateTimePicker
                    value={this.state.travellerPicked}
                    mode="date"
                    display="default"
                    onChange={this._handleDatePicked}
                    maximumDate={new Date(order.delivery_date)}
                    minimumDate={Date.now()}
                  />
                )}

                {Platform.OS === 'ios' ? (
                  <TouchableHighlight
                    onPress={() => this.setState({ travellerPicker: true })}
                    rejectResponderTermination>
                    <TextInput
                      editable={false}
                      style={styles.inputbox}
                      value={this.state.traveldate}
                      placeholderTextColor="#878787"
                      underlineColorAndroid="rgba(0, 0, 0,0)"
                    />
                  </TouchableHighlight>
                ) : (
                    <TouchableOpacity
                      onPress={() => this.setState({ travellerPicker: true })}>
                      <TextInput
                        editable={false}
                        style={styles.inputbox}
                        value={this.state.traveldate}
                        placeholderTextColor="#878787"
                        underlineColorAndroid="rgba(0, 0, 0,0)"
                      />
                    </TouchableOpacity>
                  )}
              </View>
            </View>

            <View style={[styles.fromgroup, { justifyContent: 'center', alignItem: 'center', width: '100%' }]}>

              <FlyButton style={{ width: 200, alignSelf: 'center' }} onPress={() => this._next(2)} color='#4A0B49' title="Next" />

            </View>
          </View>

        </View>
      );
    } else if (this.state.step == 2) {
      return (
        <View style={[styles.card, styles.shadow]}>
          <View style={styles.fromgroup}>
            <Text
              style={{
                fontSize: 18,
                color: '#660165',
                textAlign: 'center',
                marginHorizontal: 10,
                fontFamily: 'OpenSans-semiBold',
              }}>
              Please tell the buyer about how much traveller fee & delivery date
            </Text>
            <Text
              style={{
                marginBottom: 10,
                fontSize: 14,
                textAlign: 'center',
                marginHorizontal: 10,
                fontFamily: 'OpenSans-regular',
              }}>
              Please input the delivery fee you are willing to take and the date
              when you can deliver
            </Text>
          </View>
          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                Your Delivery Fee({this.props.currency})
              </Text>
            </View>
            <TextInput
              style={{ fontSize: 32, color: '#000' }}
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              keyboardType={'numeric'}
              onChangeText={traveller_fee => this.setState({ traveller_fee })}
              value={this.state.traveller_fee}
            />
          </View>
          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Delivery Date:</Text>
            </View>

            {/* <View style={styles.datepikerradius}>
                        <DatePicker
                            defaultDate={new Date(order.deliveryPicker)}
                            minimumDate={new Date()}
                            maximumDate={new Date(order.delivery_date_format)}
                            locale={"en"}
                            timeZoneOffsetInMinutes={undefined}
                            modalTransparent={false}
                            animationType={"fade"}
                            androidMode={"default"}
                            placeholder="DD/MM/YYY"
                            textStyle={{ color: "#878787" }}
                            placeHolderTextStyle={{ color: "#878787" }}
                            onDateChange={this._handleDatePickedDelivery}
                            style={{borderWidth:1,}}
                        />
                    </View> */}

            {this.state.deliveryPicker && (
              <DateTimePicker
                value={this.state.deliveryPicked}
                mode="date"
                display="default"
                onChange={this._handleDatePickedDelivery}
                maximumDate={new Date(order.delivery_date)}
                minimumDate={Date.now()}
              />
            )}

            {Platform.OS === 'ios' ? (
              <TouchableHighlight
                onPress={() => this.setState({ deliveryPicker: true })}>
                <TextInput
                  editable={false}
                  style={styles.inputbox}
                  value={this.state.delivery_date}
                  placeholderTextColor="#878787"
                  underlineColorAndroid="rgba(0, 0, 0,0)"
                />
              </TouchableHighlight>
            ) : (
                <TouchableOpacity
                  onPress={() => this.setState({ deliveryPicker: true })}>
                  <TextInput
                    editable={false}
                    style={styles.inputbox}
                    value={this.state.delivery_date}
                    placeholderTextColor="#878787"
                    underlineColorAndroid="rgba(0, 0, 0,0)"
                  />
                </TouchableOpacity>
              )}
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Message Shoper</Text>
            </View>
            <TextInput
              style={styles.inputdescription}
              placeholder="Type you massage"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              multiline={true}
              value={this.state.message}
            />
          </View>

          <View style={styles.fromgroup}>
            {/* <FlyButton style={{ width: 200, alignSelf: 'center' }} onPress={() => this._make_offer()} title="Make Delivery Offer" color ='#4A0B49' /> */}
            <FlyButton style={{ width: 200, alignSelf: 'center' }} onPress={() => this._next(3)} title="Next" color='#4A0B49' />
            <FlyButton style={{ marginTop: 10, width: 200, alignSelf: 'center' }} onPress={() => this._next(1)} title="Back" color='#4A0B49' />

            {/* <TouchableOpacity onPress={() => this._make_offer()}>
              <Text style={styles.Searchbtn}>Make Delivery Offer</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(1)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity> */}
          </View>
        </View>
      );
    } else if (this.state.step == 3) {
      return (

        <View style={{ marginHorizontal: 15, height: Dimensions.get('window').height - 250,marginTop:30, }}>
          <InputFieldWithIcon imageSource={require('../../../../assets/images/ic_call.png')} label="Mobile Number" />
          <InputFieldWithIcon imageSource={require('../../../../assets/images/ic_msg.png')} label="Email" />


          <FlyButton style={{
            width: 200, alignSelf: 'center', position: 'absolute',
            bottom: 0
          }} onPress={() => this._make_offer()} title="Make Delivery Offer" color='#4A0B49' />


        </View>
      );
    } else if (this.state.step == 4) {
      return (

        <View style={{ marginHorizontal: 15,justifyContent:'space-around',alignItem:'center' }}>
          <Image
            style={{
              height: 100, width: 140, resizeMode: 'stretch', alignSelf: 'center'
            }}
            source={require('../../../../assets/images/ic_tick.png')}
          />
          <OfferDeliveredModel onPress={() => {
            // this.props.navigation.navigation('Home');
            //   this.setState({
            //   step:4
            // }) 
          }} />
        </View>
      );
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      const order = this.state.order;
      return (
        <View style={[styles.containerbox, { height: '100%' }]}>
          <StatusBar backgroundColor="#660165" barStyle="light-content" />
          <Steps step={this.state.step} />

          <ScrollView style={{ height: '100%' }}>


            {this.elementOrder(order)}
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(MakeOffer);
