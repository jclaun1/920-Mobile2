import React from 'react';
import {
  BackHandler,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  ScrollView,
  Linking, Image
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import styles from '../../../assets/css/style';
import { CheckBox } from 'native-base';
import OrderSubmitting from '../Common/OrderSubmitting';
import { onLoginRequest, onUserRequest } from '../../redux/actions/authAction';
import { connect } from 'react-redux';
import axios from 'axios';
import { apiDomain } from '../../config/env';
import { TextInputLayout } from 'rn-textinputlayout';
import FlyButton from '../Common/FlyButton';

class SignUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      erromsg: '',
      email: '',
      password: '',
      first_name: '',
      last_name: '',
      iserror: true,
      isAccepted: false,
      storageData: null,
      isLoading: false,
      privacyurl: apiDomain + 'privacy',
    };

    this._componentWillLoad();
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  async _fbServerLogin(data) {
    // this.setState({
    //     isLoading: true
    // })
    // try {
    //     var postData = {
    //         fbId: data.id,
    //         email: data.email,
    //         avatar: data.picture.data.url,
    //         fbname: data.name
    //     }
    //     let response = await axios.post('mobile/fblogin', postData)
    //     var accesstoken = response.data.accessToken
    //     await AsyncStorage.setItem('token', accesstoken)
    //     axios.defaults.headers.common.Authorization = `Bearer ${accesstoken}`
    //     await this.props.onUserRequest(accesstoken)
    //     var userData = this.props.user
    //     if (this.state.storageData) {
    //         if (userData.isPhoneVerified) {
    //             this.props.navigation.navigate('OrderSubmittingData')
    //         }else{
    //             await Alert.alert("Verify your phone number!",
    //                 'In order to access the full features of flypur, please verify your phone number.'
    //             )
    //             this.props.navigation.navigate('EmailPhone')
    //         }
    //     }else{
    //         this.props.navigation.navigate('Authenticated')
    //     }
    // } catch (error) {
    //     // if (error.request) {
    //     //     console.log(JSON.parse(error.request.response))
    //     // }
    //     // console.log(error)
    //     this.setState({
    //         isLoading: false
    //     })
    // }
  }

  async _facebookLogin() {
    // try {
    //     LoginManager.logOut()
    //     let resposne = await LoginManager.logInWithReadPermissions(['public_profile'])
    //     if (await resposne.isCancelled) {
    //         return
    //     }
    //     let data = await AccessToken.getCurrentAccessToken()
    //     const response = await fetch(`https://graph.facebook.com/me?fields=email,name,id,picture.type(large)&access_token=${data.accessToken.toString()}`);
    //     this._fbServerLogin(await response.json())
    // } catch (error) {
    //     // console.log(error)
    //     await Alert.alert("Oops!",'Signup Faild!')
    // }
  }

  isValid(data) {
    var isValidData = true;
    for (let i = 0; i < Object.keys(data).length; i++) {
      if (!data[Object.keys(data)[i]]) {
        this[Object.keys(data)[i]].focus();
        isValidData = false;
        break;
      }
    }
    return isValidData;
  }

  async _onSubmitForm() {
    let checkdata = {
      email: this.state.email,
      password: this.state.password,
      first_name: this.state.first_name,
      last_name: this.state.last_name,
    };

    if (!this.isValid(checkdata)) {
      return false;
    }

    if (!this.state.isAccepted) {
      Alert.alert('Opps!', 'First Accept Terms of Service.');
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      var data = {
        email: this.state.email.toLowerCase(),
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        password: this.state.password,
        isMobile: true,
        accept: 1,
      };
      let response = await axios.post('registration', data);
      await AsyncStorage.setItem('token', response.data.data.accessToken);
      axios.defaults.headers.common.Authorization = `Bearer ${
        response.data.data.accessToken
        }`;
      await this.props.onUserRequest(response.data.data.accessToken);
      var userData = this.props.user;
      this.setState({
        isLoading: false,
      });
      if (this.state.storageData) {
        if (userData.isPhoneVerified) {
          this.props.navigation.navigate('OrderSubmittingData');
        } else {
          await Alert.alert(
            'Verify your phone number!',
            'In order to access the full features of flypur, please verify your phone number.',
          );
          this.props.navigation.navigate('EmailPhone');
        }
      } else {
        this.props.navigation.navigate('Authenticated');
      }
    } catch (error) {
      this.setState({
        isLoading: false,
      });
      // console.log(JSON.parse(error.request.response))
      if (await JSON.parse(error.request.response)) {
        var responseError = await JSON.parse(error.request.response);
        if (responseError.errors) {
          if (responseError.errors.email) {
            await Alert.alert('Opps!', responseError.errors.email[0]);
            return;
          }
          if (responseError.errors.password) {
            await Alert.alert('Opps!', responseError.errors.password[0]);
            return;
          }
        }
      }
      Alert.alert('Opps!', 'Some internal server error.');
    }
  }

  async _componentWillLoad() {
    let storageData = await AsyncStorage.getItem('submitdata');
    this.setState({ storageData });
  }

  componentWillUnmount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  handleClick = () => {
    Linking.canOpenURL('https://flypur.com/privacy').then(supported => {
      if (supported) {
        Linking.openURL('https://flypur.com/privacy');
      } else {
        console.log("Don't know how to open URI: ");
      }
    });
  };

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <KeyboardAvoidingView behavior="" enabled style={styles.containerbox}>
          <View style={styles.containerbox}>
            <ScrollView
              contentContainerStyle={{ flexGrow: 1 }}
              style={{ flex: 1 }}
              style={{ width: '100%', height: '100%' }}>

              <View style={styles.SignUpwraper}>
                <View style={{ width: "100%", }} >
                  {/* <TouchableOpacity onPress={() => this.props.navigation.navigate("Login")}>
                    <Image
                      source={require('../../../assets/images/ic_back.png')}
                      style={{
                        height: 20, width: 20, resizeMode: 'cover',
                      }}
                    />
                  </TouchableOpacity> */}
                </View>
                <Text
                  style={{
                    color: '#000',
                    fontSize: 20,
                    marginTop: 40,
                    fontFamily: 'OpenSans-Semibold',
                  }}>
                  Signup to{' '}
                  <Text
                    style={{
                      color: '#831C82',
                      fontSize: 20,
                    }}
                  >
                    FLYPUR{' '}
                  </Text>
                </Text>
                <View style={styles.fromgprow}>

                  <TextInputLayout
                    style={{
                      width: "100%",
                      focusColor: "#650764"
                    }}
                  >
                    <TextInput
                      style={styles.inputboxsingup}
                      placeholder="Email"
                      placeholderTextColor="#878787"
                      underlineColorAndroid="rgba(0, 0, 0,0)"
                      value={this.state.email}
                      ref={input => {
                        this.email = input;
                      }}
                      onChangeText={email => this.setState({ email })}
                    />


                  </TextInputLayout>
                </View>
                <View style={styles.fromgprow}>

                  <TextInputLayout
                    style={{
                      width: "100%",
                      focusColor: "#650764"
                    }}
                  >
                    <TextInput
                      style={styles.inputboxsingup}
                      placeholder="Password"
                      placeholderTextColor="#878787"
                      underlineColorAndroid="rgba(0, 0, 0,0)"
                      value={this.state.password}
                      ref={input => {
                        this.password = input;
                      }}
                      onChangeText={password => this.setState({ password })}
                      secureTextEntry={true}
                    />
                  </TextInputLayout>
                </View>
                <View style={styles.fromgprow}>


                  <TextInputLayout
                    style={{
                      width: "100%",
                      focusColor: "#650764"
                    }}
                  >
                    <TextInput
                      style={styles.inputboxsingup}
                      placeholder="First Name"
                      placeholderTextColor="#878787"
                      underlineColorAndroid="rgba(0, 0, 0,0)"
                      value={this.state.first_name}
                      ref={input => {
                        this.first_name = input;
                      }}
                      onChangeText={first_name => this.setState({ first_name })}
                    />
                  </TextInputLayout>
                </View>
                <View style={styles.fromgprow}>

                  <TextInputLayout
                    style={{
                      width: "100%",
                      focusColor: "#650764"
                    }}
                  >
                    <TextInput
                      style={styles.inputboxsingup}
                      placeholder="Last Name"
                      placeholderTextColor="#878787"
                      underlineColorAndroid="rgba(0, 0, 0,0)"
                      value={this.state.last_name}
                      ref={input => {
                        this.last_name = input;
                      }}
                      onChangeText={last_name => this.setState({ last_name })}
                    />
                  </TextInputLayout>
                </View>
                <View
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>

                  
                </View>
                <View style={[styles.termsconditison,{position:'absolute',bottom:30, alignSelf: 'center',
                  }]}>

                  <View>
                  <FlyButton style={{marginTop:20}} onPress={() => this._onSubmitForm()} title="Sign Up" />

                    <Text
                      style={{ fontFamily: 'OpenSans-Regular', color: '##ABB4BD',textAlign:'center' }}>
                      {' '}
                      By using Flypur, I agree to Flypur's Terms of Service and
                        <Text
                        style={{ color: '#831C82' }}
                        onPress={() => this.handleClick()}>
                        {' '}
                        Privacy Policy.
                      </Text>
                    </Text>
                  </View>
                </View>

                {/* <Text
                  style={{
                    textAlign: 'center',
                    marginTop: 10,
                    color: '#000',
                    fontFamily: 'OpenSans-Regular',
                  }}>
                  Already have an account?
                  <Text
                    style={{ color: '#336699' }}
                    onPress={() => this.props.navigation.navigate('Login')}>
                    {' '}
                    Login here{' '}
                  </Text>
                </Text> */}
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  { onLoginRequest, onUserRequest },
)(SignUp);
