import React from 'react'
import { Text, View, TouchableOpacity, TextInput, ScrollView, Image, Modal, Alert } from 'react-native'
import styles from '../../../assets/css/style'
import axios from 'axios'
import { TextInputLayout } from 'rn-textinputlayout';
import FlyButton from '../Common/FlyButton';


export default class ForgetPassword extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            email: '',
            isLoading: false
        }
    }

    async _handleSubmit() {
        this.props.onClose(true);

    }

    render() {

        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={true}
                // onRequestClose={() => {
                //     this.props.onClose(false)
                // }}
                >
                    <View style={[{ margin: 20, width: "100%",height:"100%" }]}>
                        <View style={{ margin: 20, width: "100%", flexDirection: 'row-reverse' }} >
                            <TouchableOpacity onPress={() => this.props.onClose(false)}>
                                <Image
                                    source={require('../../../assets/images/ic_close.png')}
                                    style={{
                                        height: 20, width: 20, resizeMode: 'cover',
                                    }}
                                />
                            </TouchableOpacity>
                        </View>

                        <View style={[{ width: "90%", justifyContent:'center', flexDirection: 'row'}]}>
                            <Image
                                source={require('../../../assets/images/ic_logo.png')}
                                style={{
                                    height: 80, width: 80, resizeMode: 'cover'
                                }}
                            />
                        </View>
                        <View style={[{ width: "90%",marginTop:40, justifyContent:'center', flexDirection: 'row'}]}>
                            <Image
                                source={require('../../../assets/images/ic_check_mail.png')}
                                style={{
                                    height: 200, width: 200, resizeMode: 'cover',justifyContent:'center'
                                }}
                            />
                        </View>

                        {/* <View style={{ margin: 20, width: "100%", }}>
                            <Text style={{ fontSize: 25, textAlign: 'left', color: "#000000", fontFamily: 'Montserrat-bold', }}>Forget Password</Text>
                        </View> */}
                        <Text style={{  fontSize: 14,marginTop:20,textAlign:'center',  color: '#555',width: "90%", fontFamily: 'Montserrat-Regular', }}>We have sent you a reset password link on your registered email address.</Text>



                        <View style={{ flexDirection: 'column', width: "90%", justifyContent: "center", marginTop:20}}>
                            <FlyButton onPress={() => this._handleSubmit()} title="Go to Email" />
                        </View>



                    </View>

            </Modal>
        )

    }
}
