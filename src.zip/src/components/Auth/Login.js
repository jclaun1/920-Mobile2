import React from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
  KeyboardAvoidingView,
  ScrollView,
  BackHandler, Dimensions
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../assets/css/style';
import OrderSubmitting from '../Common/OrderSubmitting';
import { onLoginRequest, onUserRequest } from '../../redux/actions/authAction';
import { connect } from 'react-redux';
import {
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRECT,
  LOGIN_URL,
} from '../../config/env';
import axios from 'axios';
import ForgetPassword from './ForgetPassword';
import EmailSentModel from './EmailSentModel';
// import {LoginManager, AccessToken} from 'react-native-fbsdk';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FlyButton from '../Common/FlyButton';
import InputFields from '../Common/InputFields';
import { Input } from 'react-native-elements';
import { TextInputLayout } from 'rn-textinputlayout';

const EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
class Login extends React.Component {


  constructor(props) {
    super(props);
    this.state = {
      username:
        process.env.NODE_ENV === 'production'
          ? ''
          : 'vipinkumar021193@gmail.com',
      password: process.env.NODE_ENV === 'production' ? '' : 'vipin93',
      isLoading: false,
      isForgetPass: false,
      isSentEmail: false,
      storageData: null,
      isOrderSubmitting: false,
    };

    this._componentWillLoad();
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  async _fbServerLogin(data) {
    // this.setState({
    //     isLoading: true
    // })
    // try {
    //     var postData = {
    //         fbId: data.id,
    //         email: data.email,
    //         avatar: data.picture.data.url,
    //         fbname: data.name
    //     }
    //     let response = await axios.post('mobile/fblogin', postData)
    //     var accesstoken = response.data.accessToken
    //     await AsyncStorage.setItem('token', accesstoken)
    //     axios.defaults.headers.common.Authorization = `Bearer ${accesstoken}`
    //     await this.props.onUserRequest(accesstoken)
    //     var userData = this.props.user
    //     if (this.state.storageData) {
    //         if (userData.isPhoneVerified) {
    //             this.props.navigation.navigate('OrderSubmittingData')
    //         }else{
    //             await Alert.alert("Verify your phone number!",
    //                 'In order to access the full features of flypur, please verify your phone number.'
    //             )
    //             this.props.navigation.navigate('EmailPhone')
    //         }
    //     }else{
    //         this.props.navigation.navigate('Authenticated')
    //     }
    // } catch (error) {
    //     // if (error.request) {
    //     //     console.log(JSON.parse(error.request.response))
    //     // }else{
    //     //     console.log(error)
    //     // }
    //     await Alert.alert("Oops!",'Login Faild!')
    //     this.setState({
    //         isLoading: false
    //     })
    // }
  }

  // async _facebookLogin() {
  //   // console.log(LoginManager)
  //
  //   try {
  //     await LoginManager.logOut();
  //     let resposne = await LoginManager.logInWithReadPermissions([
  //       'email',
  //       'public_profile',
  //     ]);
  //
  //     if (await resposne.isCancelled) {
  //       return;
  //     }
  //
  //     let data = await AccessToken.getCurrentAccessToken();
  //
  //     const response = await fetch(
  //       `https://graph.facebook.com/me?fields=email,name,id,picture.type(large)&access_token=${data.accessToken.toString()}`,
  //     );
  //     this._fbServerLogin(await response.json());
  //   } catch (error) {
  //     console.log(error.request);
  //
  //     if (error.request) {
  //       console.log(error.request);
  //     } else {
  //       console.log(error);
  //     }
  //     Alert.alert('Oops!', 'Login Faild!');
  //   }
  // }

  async onSubmitForm() {
    if (!this.state.username) {
      this.username.focus();
      return;
    }

    if (!this.state.password) {
      this.password.focus();
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = {
        grant_type: 'password',
        client_id: OAUTH_CLIENT_ID,
        client_secret: OAUTH_CLIENT_SECRECT,
        username: this.state.username,
        password: this.state.password,
      };

      let response = await axios.post(LOGIN_URL, data);
      await AsyncStorage.setItem('token', response.data.access_token);
      axios.defaults.headers.common.Authorization = `Bearer ${
        response.data.access_token
        }`;
      await this.props.onUserRequest(response.data.access_token);

      var userData = this.props.user;

      if (this.state.storageData) {
        if (userData.isPhoneVerified) {
          this.props.navigation.navigate('OrderSubmittingData');
          // this.setState({isOrderSubmitting:true,  isLoading: false, isForgetPass:false})
          return;
        } else {
          Alert.alert(
            'Verify your phone number!',
            'In order to access the full features of flypur, please verify your phone number.',
          );
          this.props.navigation.navigate('EmailPhone');
          return;
        }
      } else {
        this.props.navigation.navigate('Authenticated');
      }
    } catch (error) {
      this.setState({
        isLoading: false,
      });
      if (await error.request) {
        if (await error.request.response) {
          var errosData = await JSON.parse(error.request.response);
          if (await errosData.message) {
            Alert.alert('Opps!', errosData.message);
            return;
          }
        }
      } else {
      }
      console.log(error);

      Alert.alert('Opps!', 'Somthing went wrong');
    }
  }

  componentWillUnmount() {
    this.setState({ isLoading: false, isOrderSubmitting: false });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  async _componentWillLoad() {
    let storageData = await AsyncStorage.getItem('submitdata');

    this.setState({ storageData });
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  render() {
    if (this.state.isLoading && !this.state.isForgetPass) {
      return <OrderSubmitting />;
    } else if (this.state.isForgetPass && !this.state.isLoading) {
      return (
        <ForgetPassword
          onClose={() => this.setState({ isForgetPass: false, isSentEmail: false })}
          onSentEmail={() => this.setState({ isForgetPass: false, isSentEmail: true })}
        />
      );

    } else if (this.state.isSentEmail && !this.state.isLoading) {
      return (
        <EmailSentModel onClose={() => this.setState({ isSentEmail: false })} />
      );
    } else {
      return (
        <KeyboardAvoidingView behavior="" enabled style={styles.containerbox}>
          <View style={[styles.containerbox, {
            justifyContent: 'center',
            width: '100%',
          }]}>
            <ScrollView contentContainerStyle={{
              flexGrow: 1, justifyContent: 'center',
              width: '100%',
            }} style={{ flex: 1, }}>
              <View style={[styles.SignUpwraper, { justifyContent: 'center', alignItems: 'center', }]}>
                <View
                  style={{
                    justifyContent: 'center',
                    width: '100%',
                    flex: 1.5,
                    alignItems: 'center',
                    marginBottom: 60,
                  }}>
                  <Image
                    source={require('../../../assets/images/logo.png')}
                    style={{ height: 100, width: 100, resizeMode: 'cover' }}
                  />
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                  }}>

                  <View
                    style={{
                      backgroundColor: '#ffffff',
                      borderRadius: 5,
                      elevation: 5,
                      height: 40,
                      marginRight: 10,
                      flexDirection: 'row',
                      justifyContent: 'center',
                      flex: 1
                    }}>
                    <Image
                      source={require('../../../assets/images/ic_facebook.png')}
                      style={{
                        height: 20, width: 20, resizeMode: 'cover',
                        alignSelf: 'center'
                      }}
                    />

                    <Text style={{
                      marginLeft: 10,
                      fontFamily: 'OpenSans-Regular',
                      alignSelf: 'center',
                      color: "#000000"
                    }}>
                      Facebook
                      </Text>

                  </View>
                  <View
                    style={{
                      backgroundColor: '#ffffff',
                      borderRadius: 5,
                      elevation: 5,
                      height: 40,
                      marginLeft: 10,
                      flexDirection: 'row',
                      justifyContent: 'center',
                      flex: 1
                    }}>
                    <Image
                      source={require('../../../assets/images/Google.png')}
                      style={{
                        height: 20, width: 20, resizeMode: 'cover',
                        alignSelf: 'center'
                      }}
                    />

                    <Text style={{
                      marginLeft: 10,
                      fontFamily: 'OpenSans-Regular',
                      alignSelf: 'center',
                      color: "#000000"

                    }}>
                      Google
                      </Text>

                  </View>


                </View>

                <View style={[{ flex: 2, justifyContent: 'center', alignItems: 'center' }]}>
                  <View style={[styles.fromgprow]}>

                    <InputFields
                      placeholder="Email ID"
                      value={this.state.username}
                      returnKeyType={'next'}
                      ref={input => {
                        this.username = input;
                      }}
                      onChangeText={username => this.setState({ username })}
                    />

                  </View>
                  <View style={styles.fromgprow}>

                    <InputFields
                      placeholder="Password"
                      value={this.state.password}
                      returnKeyType={'done'}
                      ref={input => {
                        this.password = input;
                      }}
                      onChangeText={password => this.setState({ password })}
                      secureTextEntry={true}
                    />

                  </View>
                  <View style={{ marginBottom: 5 }}>
                    <TouchableOpacity
                      onPress={() => this.setState({ isForgetPass: true })}>
                      <Text
                        style={{
                          fontFamily: 'OpenSans-Regular',
                          marginTop: 10,
                          color: '#650764',
                          textAlign: 'right',
                        }}>
                        Forgot Password?{' '}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View
                    style={{
                      width: Dimensions.get('window').width - 40,
                      alignSelf: 'stretch',
                      marginTop: 40
                    }}>

                    <FlyButton style={{ width: '100%' }} onPress={e => {
                      this.onSubmitForm(e)
                    }} title="Login" />

                    {/* <TouchableOpacity onPress={ () => this._facebookLogin() } style={styles.loginfb}>
                                        <Text style={{paddingRight:25, color:'#fff', alignItems:'center',}} >
                                            <FontAwesome name='facebook' size={22} />
                                        </Text>
                                        <Text style={{fontSize:16, color:'#fff', alignItems:'center',fontFamily:'Montserrat-semiBold',}}>
                                            Login With Facbook
                                        </Text>
                                    </TouchableOpacity> */}
                  </View>
                  <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                    <Text
                      style={{
                        fontFamily: 'OpenSans-Regular',
                        marginTop: 40,
                        color: '#ABB4BD',
                      }}>
                      Don't have a account?
                    <Text
                        style={{
                          fontFamily: 'OpenSans-Bold',
                          color: '#650764',
                        }}
                        onPress={() => this.props.navigation.navigate('SignUp')}>
                        {' '}
                        Register Now {' '}
                      </Text>
                    </Text>
                  </View>
                </View>
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  { onLoginRequest, onUserRequest },
)(Login);
