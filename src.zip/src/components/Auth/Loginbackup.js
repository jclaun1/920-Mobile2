import React from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
  KeyboardAvoidingView,
  AsyncStorage,
  ScrollView,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../assets/css/style';
import OrderSubmitting from '../Common/OrderSubmitting';
import {onLoginRequest, onUserRequest} from '../../redux/actions/authAction';
import {connect} from 'react-redux';
import {
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRECT,
  LOGIN_URL,
} from '../../config/env';
import axios from 'axios';
import {AccessToken, LoginManager} from 'react-native-fbsdk';
import ForgetPassword from './ForgetPassword';
import OrderSubmittingData from '../Common/OrderSubmittingData';

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username:
        process.env.NODE_ENV === 'production'
          ? ''
          : 'vipinkumar021193@gmail.com',
      password: process.env.NODE_ENV === 'production' ? '' : 'vipin94',
      isLoading: false,
      isForgetPass: false,
      storageData: null,
      isOrderSubmitting: false,
    };
  }

  async _submitTheForm(Formdata) {
    try {
      let response = await axios.post(Formdata.url, Formdata.items);
      var tripMsg;
      if (Formdata.isShop) {
        this.props.navigation.navigate('OrderPost', {
          slug: response.data.data.slug,
        });
        return;
      } else {
        if (Formdata.isOffer) {
          tripMsg = 'Successfully offer created.';
        } else {
          tripMsg = 'Successfully trip added.';
        }
        await Alert.alert('Success', tripMsg);
        this.props.navigation.navigate('Authenticated');
      }
    } catch (error) {
      var textshow;
      if (Formdata.isShop) {
        textshow = 'Your order could not be submitted';
      } else {
        if (Formdata.isOffer) {
          textshow = 'Your offer could not be submitted';
        } else {
          textshow = 'Your trip could not be added';
        }
      }

      await Alert.alert('Faild', textshow);
      this.props.navigation.navigate('Authenticated');
    }
  }

  async _fbServerLogin(data) {
    this.setState({
      isLoading: true,
    });
    try {
      var postData = {
        fbId: data.id,
        email: data.email,
        avatar: data.picture.data.url,
        fbname: data.name,
      };

      let response = await axios.post('mobile/fblogin', postData);
      var accesstoken = response.data.accessToken;
      await AsyncStorage.setItem('token', accesstoken);
      axios.defaults.headers.common.Authorization = `Bearer ${accesstoken}`;
      await this.props.onUserRequest(accesstoken);

      var userData = this.props.user;

      if (this.state.storageData) {
        if (userData.isPhoneVerified) {
          await AsyncStorage.removeItem('submitdata');
          var storageData = await JSON.parse(this.state.storageData);
          this._submitTheForm(storageData);
          // this.props.navigation.navigate('OrderSubmittingData')
        } else {
          await Alert.alert(
            'Verify your phone number!',
            'In order to access the full features of flypur, please verify your phone number.',
          );
          this.props.navigation.navigate('EmailPhone');
        }
      } else {
        this.props.navigation.navigate('Authenticated');
      }
    } catch (error) {
      // if (error.request) {
      //     console.log(JSON.parse(error.request.response))
      // }else{
      //     console.log(error)
      // }

      await Alert.alert('Oops!', 'Login Faild!');

      this.setState({
        isLoading: false,
      });
    }
  }

  async _facebookLogin() {
    try {
      await LoginManager.logOut();
      let resposne = await LoginManager.logInWithReadPermissions([
        'email',
        'public_profile',
      ]);

      if (await resposne.isCancelled) {
        return;
      }

      let data = await AccessToken.getCurrentAccessToken();

      const response = await fetch(
        `https://graph.facebook.com/me?fields=email,name,id,picture.type(large)&access_token=${data.accessToken.toString()}`,
      );
      this._fbServerLogin(await response.json());
    } catch (error) {
      // if (error.request) {
      //     console.log(error.request)
      // }else{
      //     console.log(error)
      // }
      Alert.alert('Oops!', 'Login Faild!');
    }
  }

  async onSubmitForm() {
    if (!this.state.username || !this.state.password) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = {
        grant_type: 'password',
        client_id: OAUTH_CLIENT_ID,
        client_secret: OAUTH_CLIENT_SECRECT,
        username: this.state.username,
        password: this.state.password,
      };

      let response = await axios.post(LOGIN_URL, data);
      await AsyncStorage.setItem('token', response.data.access_token);
      axios.defaults.headers.common.Authorization = `Bearer ${
        response.data.access_token
      }`;
      await this.props.onUserRequest(response.data.access_token);

      var userData = this.props.user;

      if (this.state.storageData) {
        if (userData.isPhoneVerified) {
          await AsyncStorage.removeItem('submitdata');
          var storageData = await JSON.parse(this.state.storageData);
          this._submitTheForm(storageData);
          // this.props.navigation.push('OrderSubmittingData')
          // this.setState({isOrderSubmitting:true,  isLoading: false, isForgetPass:false})
          return;
        } else {
          await Alert.alert(
            'Verify your phone number!',
            'In order to access the full features of flypur, please verify your phone number.',
          );
          this.props.navigation.navigate('EmailPhone');
          return;
        }
      } else {
        this.props.navigation.navigate('Authenticated');
      }
    } catch (error) {
      if (error.request) {
        var errosData = JSON.parse(error.request.response);
        if (errosData.message) {
          Alert.alert('Opps!', errosData.message);
        }
      } else {
      }
      this.setState({
        isLoading: false,
      });
    }
  }

  componentWillUnmount() {
    this.setState({isLoading: false, isOrderSubmitting: false});
  }

  async componentWillMount() {
    var storageData = await AsyncStorage.getItem('submitdata');
    this.setState({storageData});
  }

  render() {
    if (
      !this.state.isForgetPass &&
      !this.state.isLoading &&
      this.state.isOrderSubmitting
    ) {
      return <OrderSubmittingData navigation={this.props.navigation} />;
    } else if (
      this.state.isLoading &&
      !this.state.isForgetPass &&
      !this.state.isOrderSubmitting
    ) {
      return <OrderSubmitting />;
    } else if (
      this.state.isForgetPass &&
      !this.state.isLoading &&
      !this.state.isOrderSubmitting
    ) {
      return (
        <ForgetPassword onClose={() => this.setState({isForgetPass: false})} />
      );
    } else {
      return (
        <KeyboardAvoidingView behavior="" enabled style={styles.containerbox}>
          <View style={styles.containerbox}>
            <ScrollView contentContainerStyle={{flexGrow: 1}} style={{flex: 1}}>
              <View style={styles.SignUpwraper}>
                <View
                  style={{
                    justifyContent: 'center',
                    width: '100%',
                    alignItems: 'center',
                    marginBottom: 30,
                  }}>
                  <Image
                    source={require('../../../assets/images/logo.png')}
                    style={{height: 200, width: 200, resizeMode: 'cover'}}
                  />
                </View>
                <View style={styles.fromgprow}>
                  <TextInput
                    style={styles.inputboxLogin}
                    placeholder="Email"
                    placeholderTextColor="#878787"
                    underlineColorAndroid="rgba(0, 0, 0,0)"
                    value={this.state.username}
                    returnKeyType={'next'}
                    onChangeText={username => this.setState({username})}
                  />
                </View>
                <View style={styles.fromgprow}>
                  <TextInput
                    style={styles.inputboxLogin}
                    placeholder="Password"
                    placeholderTextColor="#878787"
                    underlineColorAndroid="rgba(0, 0, 0,0)"
                    value={this.state.password}
                    returnKeyType={'done'}
                    onChangeText={password => this.setState({password})}
                    secureTextEntry={true}
                  />
                </View>
                <View style={{marginBottom: 5}}>
                  <TouchableOpacity
                    onPress={() => this.setState({isForgetPass: true})}>
                    <Text
                      style={{
                        fontFamily: 'Montserrat-Regular',
                        marginTop: 10,
                        color: '#336699',
                        textAlign: 'center',
                      }}>
                      Forget Password{' '}
                    </Text>
                  </TouchableOpacity>
                </View>

                <View
                  style={{
                    width: '100%',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <TouchableOpacity
                    onPress={e => {
                      this.onSubmitForm(e);
                    }}
                    style={styles.loginbtn}>
                    <Text
                      style={{
                        textAlign: 'center',
                        fontFamily: 'Montserrat-semiBold',
                        fontSize: 16,
                        color: '#fff',
                      }}>
                      Login
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => this._facebookLogin()}
                    style={styles.loginfb}>
                    <Text
                      style={{
                        paddingRight: 25,
                        color: '#fff',
                        alignItems: 'center',
                      }}>
                      <FontAwesome name="facebook" size={22} />
                    </Text>
                    <Text
                      style={{
                        fontSize: 16,
                        color: '#fff',
                        alignItems: 'center',
                        fontFamily: 'Montserrat-semiBold',
                      }}>
                      Login With Facbook
                    </Text>
                  </TouchableOpacity>
                </View>
                <View style={{alignItems: 'center', justifyContent: 'center'}}>
                  <Text
                    style={{
                      fontFamily: 'Montserrat-Regular',
                      marginTop: 10,
                      color: '#000',
                    }}>
                    Don't have a account
                    <Text
                      style={{color: '#336699'}}
                      onPress={() => this.props.navigation.navigate('SignUp')}>
                      {' '}
                      Sing Up here{' '}
                    </Text>
                  </Text>
                </View>
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  {onLoginRequest, onUserRequest},
)(Login);
