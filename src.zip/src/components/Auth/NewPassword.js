import React from 'react'
import {Text, View, TouchableOpacity, TextInput, Alert, Image, KeyboardAvoidingView, ScrollView} from 'react-native'
import styles from '../../../assets/css/style'
import OrderSubmitting from '../Common/OrderSubmitting'
import {connect}  from 'react-redux'
import axios from 'axios'
import FlyButton from '../Common/FlyButton';

class NewPassword extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            token: '',
            password: '',
            password_confirmation: '',
            isLoading: false
        }

        this._componentWillLoad()
    }

    async _handleSubmit() {

        if (!this.state.token || !this.state.password || !this.state.password_confirmation) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {

            var data = {
				token: this.state.token,
				password: this.state.password,
				password_confirmation: this.state.password_confirmation
            }  

            await axios.post('create/new-password', data)

            Alert.alert(
                    "Successfully new password created!",
                    "Successfully new password created, please login with new password."
                )
            this.props.navigation.push('Login')
            
        } catch (error) {
            console.log(error)
            Alert.alert("Oops!", "password changed!")
            this.setState({
                isLoading: false
            })
        }
    }

    _componentWillLoad() {
        let token = this.props.navigation.getParam('token')
        this.setState({
            token
        })
    }

    componentWillUnmount() {
        this.setState({
            isLoading:false
        })
    }

    render() {

        if (this.state.isLoading) {
            return (
                <OrderSubmitting/>
            )
        } else {
    
            return (
            
                <KeyboardAvoidingView behavior="" enabled style={styles.containerbox}>
                    <View style={styles.containerbox}>
                    <ScrollView contentContainerStyle={{flexGrow: 1}} style={{flex:1}}>
                    <View style={[styles.card, styles.shadow,styles.change_pass_container]}>
                        <View style={{justifyContent:"center",width:"100%",alignItems:'center',marginBottom:30}}>
                                    <Image source={require('../../../assets/images/logo.png')} style = {{height: 200, width: 200, resizeMode : 'cover',}} />
                        </View> 
                        <View style={styles.changepasswordfromgroup}>
                            <TextInput style={styles.inputbox}
                                secureTextEntry={true}
                                placeholder="New Password"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                value={this.state.password}
                                onChangeText={(password) => this.setState({password})}
                            />
                        </View>

                        <View style={styles.changepasswordfromgroup}>
                            <TextInput style={styles.inputbox}
                                secureTextEntry={true}
                                placeholder="Confirm New Password"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                value={this.state.password_confirmation}
                                onChangeText={(password_confirmation) => this.setState({password_confirmation})}
                            />
                        </View>

                        <View style={styles.changepasswordfromgroup}>
                            <TouchableOpacity onPress={() => this._handleSubmit()}>
                                <Text style={styles.Searchbtn}>Create Password</Text>
                            </TouchableOpacity>
                        </View>

                    </View>
                </ScrollView>
                    </View>
                </KeyboardAvoidingView>
            ) 
        }
    }
}



export default connect(null, null)(NewPassword)
