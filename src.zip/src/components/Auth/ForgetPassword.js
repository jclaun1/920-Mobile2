import React from 'react'
import { Text, View, TouchableOpacity, TextInput, ScrollView, Image, Modal, Alert } from 'react-native'
import styles from '../../../assets/css/style'
import axios from 'axios'
import { TextInputLayout } from 'rn-textinputlayout';
import FlyButton from '../Common/FlyButton';
import InputFields from '../Common/InputFields';


export default class ForgetPassword extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            email: '',
            isLoading: false
        }
    }

    async _handleSubmit() {

        if (!this.state.email || this.state.isLoading) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {
            await axios.post('password/create/mail', { email: this.state.email, isMobile: true })
            this.setState({
                isLoading: false
            })
            // Alert.alert('Email sent!', 'We have send email creating new password.')
            this.props.onSentEmail(true)
        } catch (error) {
            this.setState({
                isLoading: false
            })
            Alert.alert('Oops!', ' somthing went wrong')
        }
    }

    render() {

        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={true}
                onRequestClose={() => {
                    this.props.onClose(false)
                }}>
                <ScrollView style={{ margin: 20, }} contentContainerStyle={{ flexGrow: 1 }}>
                    <View style={[styles.container, { margin: 20, width: "100%", }]}>
                        <View style={{ margin: 20, width: "100%", }} >
                            <TouchableOpacity  onPress={() => this.props.onClose(false)}>
                                <Image
                                    source={require('../../../assets/images/ic_back.png')}
                                    style={{
                                        height: 20, width: 20, resizeMode: 'cover',
                                    }}
                                />
                            </TouchableOpacity>
                        </View>

                        <View style={{ margin: 20, width: "100%", }}>
                            <Text style={{ fontSize: 25, textAlign: 'left', color: "#000000", fontFamily: 'Montserrat-bold', }}>Forget Password</Text>
                        </View>
                        <Text style={{ marginTop: 20, fontSize: 14, color: '#555', fontFamily: 'Montserrat-Regular', }}>Please enter your email address below. An email with a link to reset Your Password Will be sent.</Text>

                        <InputFields 
                                placeholder="example@example.com"
                                onChangeText={(email) => this.setState({ email })}
                        />

                        {/* <TextInputLayout
                            style={{
                                marginTop: 16,
                                width: "100%",
                                focusColor: "#650764",

                            }} >
                            <TextInput
                                style={styles.inputboxLogin}

                                placeholder="example@example.com"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                onChangeText={(email) => this.setState({ email })}
                            />

                        </TextInputLayout> */}


                        <View style={{ flexDirection: 'column', width: "100%", justifyContent: "center", margin: 20, }}>
                            <FlyButton onPress={() => this._handleSubmit()} title={this.state.isLoading ? 'Sending..' : 'Reset Password'} />
                        </View>



                    </View>

                </ScrollView>
            </Modal>
        )

    }
}
