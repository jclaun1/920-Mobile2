import React from 'react'
import {Text, View, StatusBar} from 'react-native'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import Entypo from 'react-native-vector-icons/Entypo'
import Foundation  from 'react-native-vector-icons/Foundation'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import styles from '../../../assets/css/style'

export default class ProfileMenu extends React.Component {
  render() {
    return (
    <View style={styles.container}>
      <StatusBar
          backgroundColor="#660165"
          barStyle="light-content"
      />
      <View style ={[styles.card, styles.shadow]}>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Profile</Text>
          <FontAwesome name="user" size={24} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Change Password</Text>
          <Entypo name="key" size={22} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Email & Phone</Text>
          <FontAwesome name="envelope" size={22} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Payments History</Text>
          <Foundation name="dollar-bill" size={27} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Balance Widrawal</Text>
          <FontAwesome name="bank" size={22} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Notification</Text>
          <MaterialIcons name="notifications-active" size={25} style={{color:'#660165'}} />
        </View>
        <View style={styles.profilemenu}>
          <Text style={styles.editprofile}>Other Setting</Text>
          <MaterialIcons name="settings" size={24} style={{color:'#660165'}} />
        </View>
       
    
      </View>      
    </View>
    );
  } 
}


