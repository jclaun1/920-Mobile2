import React from 'react';
import {View,Text,TouchableOpacity, StatusBar} from 'react-native'
import Ionicons from 'react-native-vector-icons/Ionicons'
import Entypo from 'react-native-vector-icons/Entypo'
import styles from '../../../assets/css/style';
import {connect}  from 'react-redux'

class NonScreenHeader extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isActiveInbox: false,
            isActiveNotification: false,
            isActiveHome: false,
            navigation:props.navigate
        }
    }

    _pushHome() {
        this.state.navigation.navigate('Home')
    }

    _handlEGoBack() {

        this.state.navigation.goBack(this.state.navigation.state.key)
    }


    render() {

        return (
            <View style={styles.containerHeader}>
                <StatusBar
                    backgroundColor="#660165"
                    barStyle="light-content"
                />
                <TouchableOpacity style={styles.topmenubtn} onPress={() => this._handlEGoBack()}>
                    <Ionicons name="md-arrow-round-back" size={27} style={styles.tbmenuiconactive}/>
                </TouchableOpacity>

                <TouchableOpacity style={styles.topmenubtn} >
                    <Text style={{fontSize:16,color:'#fff',fontWeight:'600'}}>{this.props.title}</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.topmenubtn} onPress={() => this._pushHome()}>
                    {this.props.notHome ? null : <Entypo name="home" size={25} style={[styles.tbmenuicon,this.state.isActiveHome ? styles.tbmenuiconactive : null]}/> }
                </TouchableOpacity>
                

            </View>
        )
    }
}

const mapStateToProps = state => {
    return {
        inboxCount:state.auth.inbox_count,
        notificationCount:state.auth.notification_count
    }
}

export default connect(mapStateToProps, null)(NonScreenHeader)
