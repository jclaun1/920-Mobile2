import React from 'react';
import {View, Text, TouchableOpacity, Image, StatusBar} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import styles from '../../../assets/css/style';
import {connect} from 'react-redux';
import {STORAGE_URL} from '../../config/env';

class ChatHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isActiveInbox: false,
      isActiveNotification: false,
      isActiveHome: false,
      navigation: props.navigate,
    };
  }

  _pushHome() {
    this.state.navigation.navigate('Home');
  }

  _handlEGoBack() {
    this.state.navigation.goBack(this.state.navigation.state.key);
  }

  render() {
    var headerData = {};
    if (this.props.navigate.state.params.headerData) {
      headerData = this.props.navigate.state.params.headerData;
    }
    return (
      <View style={styles.containerHeader}>
        <StatusBar backgroundColor="#660165" barStyle="light-content" />
        <TouchableOpacity
          style={styles.topmenubtn}
          onPress={() => this._handlEGoBack()}>
          <Ionicons
            name="md-arrow-round-back"
            size={27}
            style={styles.tbmenuiconactive}
          />
        </TouchableOpacity>

        <View
          style={{width: '80%', alignItems: 'center', flexDirection: 'row'}}>
          <TouchableOpacity style={{marginRight: 5}}>
            <Image
              source={{
                uri: headerData.user_avatar
                  ? headerData.user_avatar
                  : STORAGE_URL + 'static/assets/images/profile-up-img.png',
              }}
              resizeMode="cover"
              style={styles.sm_user_fit_40}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.topmenubtn}>
            <Text
              style={{
                fontSize: 16,
                color: '#fff',
                fontFamily: 'Montserrat-semiBold',
              }}
              onPress={() =>
                this.props.navigate.navigate('UserProfile', {
                  userName: headerData.username_slug,
                })
              }>
              {headerData.username ? headerData.username : ''}
            </Text>
            <Text
              style={{
                fontSize: 12,
                color: '#fff',
                fontFamily: 'Montserrat-regular',
              }}
              onPress={() =>
                this.props.navigate.navigate('OrderPost', {
                  slug: this.props.navigate.state.slug,
                })
              }>
              {headerData.order_name ? headerData.order_name : ''}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.topmenubtn}
          onPress={() => this._pushHome()}>
          <Entypo
            name="home"
            size={25}
            style={[
              styles.tbmenuicon,
              this.state.isActiveHome ? styles.tbmenuiconactive : null,
            ]}
          />
        </TouchableOpacity>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    inboxCount: state.auth.inbox_count,
    notificationCount: state.auth.notification_count,
  };
};

export default connect(
  mapStateToProps,
  null,
)(ChatHeader);
