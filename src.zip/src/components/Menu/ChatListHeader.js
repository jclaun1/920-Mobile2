import React from 'react'
import {View,Text,TextInput,TouchableOpacity, StatusBar} from 'react-native'
import  Ionicons from 'react-native-vector-icons/Ionicons'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import styles from '../../../assets/css/style'
import {connect}  from 'react-redux'

class ChatListHeader extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            navigation:props.navigate,
            isSearch:false,
            searchText: ''
        }
    }


    _handlEGoBack() {
        this.state.navigation.navigate('MessageNotification')
    }

    _handleChange(searchText) {
        this.setState({
            searchText
        })
        this.props.onChangeSearchText(searchText)
    }

    render() {
       
        return (
            <View style={styles.containerHeader}>
                <StatusBar
                    backgroundColor="#660165"
                    barStyle="light-content"
                />

                <TouchableOpacity style={styles.topmenubtn} onPress={() => this.state.isSearch ? this.setState({isSearch:false}): this._handlEGoBack()}>
                    <Ionicons name="md-arrow-round-back" size={27} style={styles.tbmenuiconactive}/>
                </TouchableOpacity>

                {
                    this.state.isSearch ? <View style={{width:'95%',alignItems:'center',flexDirection:'row',marginLeft:10,}}> 
                        <TextInput
                            style={{height: 45,width:'100%', borderColor: '#ccc', borderWidth: 1,backgroundColor:'#fff',color:'#000',fontSize:14,}}
                            placeholder = "search"
                            onChangeText={(searchText) => this._handleChange(searchText)}
                            value={this.state.searchText}
                            autoFocus={true}
                        />  
                    </View> :

                    <TouchableOpacity style={styles.topmenubtn} >
                        <Text style={{fontSize:18,color:'#fff',fontFamily:'Aero'}}>
                            {this.props.title ? this.props.title : this.props.password == 1 ? title :''}
                        </Text>
                    </TouchableOpacity>
                }

                {
                    this.state.isSearch ? null : <TouchableOpacity style={styles.topmenubtn} onPress={() => this.setState({isSearch:true})}>
                        <EvilIcons name="search" size={35}   style={{color:'#fff',}}/>
                    </TouchableOpacity>
                }
                

            </View>
        )
    }
}



export default connect(null, null)(ChatListHeader)
