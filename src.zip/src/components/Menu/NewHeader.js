import React from 'react'
import {View,Text,TouchableOpacity, StatusBar} from 'react-native'
import AsyncStorage from '@react-native-community/async-storage'
import Entypo from 'react-native-vector-icons/Entypo'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import { StackActions, NavigationActions } from 'react-navigation'
import styles from '../../../assets/css/style'
import {connect}  from 'react-redux'
import isEmpty from 'lodash/isEmpty'

class NewHeader extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isActiveInbox: false,
            isActiveNotification: false,
            isActiveHome: false,
            navigation:props.navigate,
            isAuth: false
        }

        this._isLogedIn()
    }

    _pushNotification() {
        this.state.navigation.navigate('Notifacation')
    }

    _pushMessage() {
        this.state.navigation.navigate('MessageNotification')
    }

    _pushHome() {

        if (!this.props.isHome ) {
            return
        }

        if (this.props.isChat) {
            routeName = "ChatList"
            this.state.navigation.navigate('ChatList')
            return
        }
      
        if (this.props.routeName) {
            const resetAction = StackActions.reset({
                index: 0,
                key:null,
                actions: [NavigationActions.navigate({ routeName: this.props.routeName })]
            })
    
            const home_page =  NavigationActions.navigate({
                routeName: "Home",
            })
    
            this.state.navigation.dispatch(resetAction)
    
            this.state.navigation.dispatch(home_page)
        }else{
            this.state.navigation.navigate('HomeScreen')
        }
       
    }

    async _isLogedIn(){
        let accessToken = await AsyncStorage.getItem('token')
        if (accessToken) {
            this.setState({
                isAuth:true
            })
        }
    }

    _headerElement(isAuth, title) {
        if (isAuth) {
            console.log('header auth')
            return  <View style={styles.containerHeader}>
                    <StatusBar
                        backgroundColor="#660165"
                        barStyle="light-content"
                    />
                <TouchableOpacity style={styles.topmenubtn} onPress={() => this.state.navigation.openDrawer()}>
                    <Entypo name="menu" size={30} style={styles.tbmenuiconactive}/>
                </TouchableOpacity>

                <TouchableOpacity style={styles.topmenubtn} >
                    <Text style={{fontSize:18,color:'#262525',fontFamily:'OpenSans-bold',marginRight:30}}>
                        {this.props.title ? this.props.title : this.props.password == 1 ? title :''}
                    </Text>
                </TouchableOpacity>

                <View style={{flexDirection:'row',justifyContent:"space-around"}}>
                    <TouchableOpacity style={{marginRight:this.props.isAddtrip ? 20 : 0}} onPress={() => this._pushHome()}>
                        {this.props.isHome ? <Entypo name={this.props.isChat ? "chat" : "home"} size={25} style={[styles.tbmenuicon,this.state.isActiveHome ? styles.tbmenuiconactive : null]}/> : null }
                    </TouchableOpacity>

                    {this.props.isAddtrip ? <TouchableOpacity style={styles.topmenubtn} onPress={() => this.state.navigation.navigate('AddTripList')}>
                        {this.props.isAddtrip ? <MaterialIcons  name="add" size={25} style={[styles.tbmenuicon]}/> : null }
                    </TouchableOpacity> : null}

                </View>
            </View>
        } else {
            return  <View style={styles.containerHeader}>

                    <StatusBar
                        backgroundColor="#660165"
                        barStyle="light-content"
                    />

                <TouchableOpacity style={styles.topmenubtn}>

                </TouchableOpacity>

                <TouchableOpacity style={styles.topmenubtn} >
                <Text style={{fontSize:18,color:'#262525',fontFamily:'OpenSans-bold'}}>
                        {this.props.title ? this.props.title :   ''}
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.topmenubtn}>

                </TouchableOpacity>

            </View>
        }
    }

    render() {
        var isAuth = this.state.isAuth
        var title = null
        if (isEmpty(this.props.user)) {
            
        }else{
            title = this.props.user.isCurrentPass ? 'Change password' : 'Create password'
        }

        return (
            <View>
                { this._headerElement(isAuth, title)}
            </View>
        )
    }
}

const mapStateToProps = state => {
    return {
        inboxCount:state.auth.inbox_count,
        notificationCount:state.auth.notification_count,
        user: state.auth.user
    }
  }

export default connect(mapStateToProps, null)(NewHeader)
