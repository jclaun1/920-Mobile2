import React from 'react';
import {Header} from 'react-native-elements'
import {connect}  from 'react-redux'

class MenuHeader extends React.Component {
  render() {
    // console.log(this.props)
    return (
      <Header
          backgroundColor={'#660165'}
          leftComponent={{ icon: 'menu', color: '#fff' }}
          centerComponent={{ text: String(this.props.inboxCount), style: { color: '#fff' } }}
          rightComponent={{ icon: 'home', color: '#fff' }}
          />
    );
  }
}

const mapStateToProps = state => {
  return {
      inboxCount:state.auth.inbox_count
  }
}

export default connect(mapStateToProps, null)(MenuHeader)