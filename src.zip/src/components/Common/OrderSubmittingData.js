import React from 'react'
import { View, Text,StyleSheet, Alert, Dimensions, ActivityIndicator } from 'react-native'
import AsyncStorage from '@react-native-community/async-storage'
import styles from '../../../assets/css/style'
import axios from  'axios'
const windowHeight = Dimensions.get('window').height * 0.4
import { NavigationActions } from 'react-navigation'
const navigateAction = NavigationActions.navigate({
    routeName: 'Tabs',
    params: {},
    action: NavigationActions.navigate({ routeName: 'Home' }),
})

export default class OrderSubmittingData extends React.Component {

    static navigationOptions = {
        header: null,
    }
    async _submitTheForm(Formdata) {
        try {
            let response = await axios.post(Formdata.url, Formdata.items)
            let tripMsg
            if (Formdata.isShop) {
                this.props.navigation.navigate('OrderPost', {slug: response.data.data.slug})
                return
            }else{
                if (Formdata.isOffer) {
                    tripMsg = "Successfully offer created."
                }else{
                    tripMsg =  "Successfully trip added."
                }
                Alert.alert('Success', tripMsg)
                // this.props.navigation.navigate('Authenticated')
                this.props.navigation.dispatch(navigateAction)                             
            }
        } catch (error) {
           
            let textshow
            if (Formdata.isShop) {
                textshow = 'Your order could not be submitted'
            }else{
                if (Formdata.isOffer) {
                    textshow = 'Your offer could not be submitted'
                }else{
                    textshow = 'Your trip could not be added'
                }
            }
            
            Alert.alert('Faild', textshow)
            this.props.navigation.dispatch(navigateAction)                             
            // this.props.navigation.navigate('Authenticated')
        }
    }

    ActivityIndicatorLoadingView() {
        return (
        <ActivityIndicator
            color='#009688'
            size='large'
            style={stylesLoading.ActivityIndicatorStyle}
            />
        )
    }

    async componentDidMount() {
        var storageData = await AsyncStorage.getItem('submitdata')
        if (JSON.parse(storageData)) {
            this._submitTheForm(JSON.parse(storageData))
            await AsyncStorage.removeItem('submitdata')
        }else{
            this.props.navigation.navigate('MyOrders')
        }
    }

    render() {
        return (
            <View style={styles.splash_cont}>
                <View style={{marginTop:40 }}>
                    <Text style={{color: '#660165', fontSize: 16, marginBottom:10, fontWeight: '600', textAlign: 'center', }}>
                        Please wait while we are submiting your request...
                    </Text>
                </View>
                {/* <Image style={styles.fitImage} source={{
                    uri: STORAGE_URL + 'static/assets/images/plane_nomatt.gif'
                }}
                    style={{ height: 100, width: 100, }}
                /> */}
                {this.ActivityIndicatorLoadingView()}
            </View>
        )
    }
}

const stylesLoading = StyleSheet.create({
    ActivityIndicatorStyle:{
      position: 'absolute',
      left: 0,
      right: 0,
      top: windowHeight,
      bottom: 0,
      alignItems: 'center',
      justifyContent: 'center'
    }
})
