import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Text, Image, ImageBackground
} from 'react-native';
import { connect } from 'react-redux'


class UnAuthorizedBottomBar extends Component {

    state = {
        selected: 0,

    };

    render() {

        enableColor = '#610760';
        disableColor = '#C3C3D0';
        tab0 = disableColor;
        tab1 = disableColor;
        tab2 = disableColor;
        tab3 = disableColor;
        tab4 = disableColor;
        imageSource = require('../../../assets/images/ic_home.png');
        if (this.state.selected == 0) {
            tab0 = enableColor;
            imageSource = require('../../../assets/images/ic_home.png');
        } else if (this.state.selected == 1) {
            tab1 = enableColor;
            imageSource = require('../../../assets/images/ic_my_trips.png');

        } else if (this.state.selected == 2) {
            tab2 = enableColor;
            imageSource = require('../../../assets/images/ic_my_offers.png');

        } else if (this.state.selected == 3) {
            tab3 = enableColor;
            imageSource = require('../../../assets/images/ic_logout.png');

        } else if (this.state.selected == 4) {
            tab4 = enableColor;
            imageSource = require('../../../assets/images/ic_profile.png');

        }

        return (

            <View
            style={[{
                width: '100%',
                height: 50,backgroundColor:'transparent',justifyContent:'center',

            }]}>

             <ImageBackground
                source={require('../../../assets/images/ic_background_selection_menu.png')}
                style={[{
                    height: 50, width: 50, resizeMode: 'stretch',
                   alignSelf: 'center', 
                    alignItems: 'center',
                }]}>
            <Image
                style={{
                    height: 25, width: 20, tintColor: enableColor,
                     resizeMode: 'stretch',alignSelf:'center',alignItems:'center',marginTop:13
                }}
                source={imageSource}
            />
            </ImageBackground>

            <ImageBackground
                source={require('../../../assets/images/bg_tab_bar.png')}
                style={[{
                    width: '105%', resizeMode: 'stretch',
                    height: 80, alignSelf: 'center', marginBottom:40,
                    justifyContent: 'space-around',marginLeft:0,marginRight:0,
                    flexDirection: 'row', alignItems: 'center',
                }]}>

                    <TouchableOpacity
                        onPress={() => {
                            this.props.navigation.navigate('Home')
                            this.setState({ selected: 0 })
                        }}
                        style={{ flex: 1 }} >

                        <Image
                            style={{
                                height: 25, width: 20, tintColor: tab0, resizeMode: 'stretch',alignSelf:'center'
                            }}
                            source={require('../../../assets/images/ic_home.png')}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => {
                            this.props.navigation.navigate('TravelOption')
                            this.setState({ selected: 1 })
                        }}

                        style={{ flex: 1 }} >

                        <Image
                            style={{
                                height: 25, width: 25, tintColor: tab1, resizeMode: 'stretch',alignSelf:'center'
                            }}
                            source={require('../../../assets/images/ic_my_trips.png')}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => {
                            this.props.navigation.navigate('ShopOption')
                            this.setState({ selected: 2 })
                        }}

                        style={{ flex: 1 }} >

                        <Image
                            style={{
                                height: 25, width: 20, tintColor: tab2, resizeMode: 'stretch',alignSelf:'center'
                            }}
                            source={require('../../../assets/images/ic_my_offers.png')}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => {
                            this.props.navigation.navigate('Login')
                            this.setState({ selected: 3 })
                        }}

                        style={{ flex: 1 }} >

                        <Image
                            style={{
                                height: 25, width: 25, tintColor: tab3, resizeMode: 'stretch',alignSelf:'center'
                            }}
                            source={require('../../../assets/images/ic_logout.png')}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity
                        onPress={() => {
                            this.props.navigation.navigate('SignUp')
                            this.setState({ selected: 4 })
                        }}

                        style={{ flex: 1 }} >

                        <Image
                            style={{
                                height: 30, width: 25, tintColor: tab4, resizeMode: 'stretch',alignSelf:'center'
                            }}
                            source={require('../../../assets/images/ic_profile.png')}
                        />
                    </TouchableOpacity>


                </ImageBackground>
            </View>

        );
    }
}


const mapStateToProps = state => {
    return {

    }
}

export default connect(mapStateToProps, null)(UnAuthorizedBottomBar)