import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Text, TextInput
} from 'react-native';
import { connect } from 'react-redux'
import { TextInputLayout } from 'rn-textinputlayout';
import styles from '../../../assets/css/style';


class InputFields extends Component {


    render() {

        return (
            <View style={{width:'100%'}}>

                <TextInputLayout
                    style={{
                        marginTop: 16,
                        width: "100%",
                        focusColor: "#650764",
                        fontFamily: 'OpenSans-Regular',

                    }}
                    // checkValid={t => ture}
                >
                    <TextInput
                        style={styles.inputboxLogin}

                        placeholder={this.props.placeholder}
                        placeholderTextColor="#878787"
                        underlineColorAndroid="rgba(0, 0, 0,0)"
                        value={this.props.value}
                        returnKeyType={'next'}
                        ref={this.props.ref}
                    
                        onChangeText={this.props.onChangeText}
                        secureTextEntry={this.props.secureTextEntry}

                    />
                </TextInputLayout>


            </View>);

    }
}


export default InputFields;