import React from 'react'
import {Text, View, TouchableOpacity, TextInput } from 'react-native'
import styles from '../../../assets/css/style'
export default class PromoCode extends React.Component {

    constructor(props) {
      super(props)
      this.state = {
        isWarning: false,
        isPaylater: false,
        isHavePromo: false,
        pcode: "",
        promoData: {}
      }
    }

    render() {
      return (
        <View style={{width:'100%',marginVertical:10,}}>
            {this.state.isHavePromo ? null : <TouchableOpacity style={styles.promo_code_btn} onPress={() => this.setState({isHavePromo:true})}>
              <Text style={{color:'#fff',fontSize:16,}}>Have a Promo Code</Text>
            </TouchableOpacity>}
          {this.state.isHavePromo ? <View style={styles.prmo_code_inp_box}>
            <TextInput style={styles.prmocode_inp}
                      placeholder=""
                      placeholderTextColor="#000"
                      onChangeText={(pcode) => this.setState({pcode})}
                      value={this.state.pcode}
                  />
            <TouchableOpacity style={styles.prmo_code_vilid}>
                <Text style={{color:'#fff',fontSize:16,}}>Apply</Text>
            </TouchableOpacity>
          </View> : null}
        </View>
      )
    }
}
