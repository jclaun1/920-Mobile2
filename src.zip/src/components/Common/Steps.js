import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Text, Image
} from 'react-native';


class Steps extends Component {


    render() {
        step = this.props.step;

        enableColor = '#610760';
        enableTextColor = '#fff';
        diableColor = '#ABB0B7';
        diableBackGroundColor = '#fff';

        backGround1Color = diableBackGroundColor;
        backGround2Color = diableBackGroundColor;
        backGround3Color = diableBackGroundColor;
        backGround4Color = diableBackGroundColor;
       
        border1Color = diableColor;
        border2Color = diableColor;
        border3Color = diableColor;
        border4Color = diableColor;

        t1Color = diableColor;
        t2Color = diableColor;
        t3Color = diableColor;
        t4Color = diableColor;

        if(step < 1){
           

        }else if(step < 2){
            backGround1Color = enableColor;
            border1Color = enableColor;
            t1Color = enableTextColor;
        }
        else if(step < 3){
            backGround1Color = backGround2Color = enableColor;
            border1Color = border2Color = enableColor;
            t1Color = t2Color = enableTextColor;
        }
        else if(step < 4){
            backGround1Color = enableColor;
            backGround2Color = enableColor;
            backGround3Color = enableColor;
            border1Color = border2Color =border3Color = enableColor;
            t1Color = t2Color = t3Color = enableTextColor;

        }
        else if(step < 5){
            backGround1Color = enableColor;
            backGround2Color = enableColor;
            backGround3Color = enableColor;
            backGround4Color = enableColor;
            border1Color = border2Color = border3Color = border4Color =enableColor;
            t1Color = t2Color = t3Color = t4Color = enableTextColor;

        }
    

        

        

        return (

            <View style={[{
                width: '90%',
                height: 40,alignSelf:'center',
                justifyContent: 'space-between',marginLeft:10,marginRight:10,
                flexDirection: 'row'
            }]}>


                <Text
                    style={{
                        height: 30, width: 30, borderRadius: 15,textAlign:'center',
                        textAlignVertical: "center",color:t1Color,paddingRight:3,
                        alignSelf: 'center', backgroundColor: backGround1Color,borderWidth:1,
                        borderColor:border1Color
                    }}
                > 1</Text>

                <View style={{
                    height: 2, width: 30,flex:1,
                    alignSelf: 'center', backgroundColor: border2Color
                }} />


                <Text
                    style={{
                        height: 30, width: 30, borderRadius: 15,textAlign:'center',
                        textAlignVertical: "center",color:t2Color,paddingRight:3,
                        alignSelf: 'center', backgroundColor: backGround2Color,borderWidth:1,
                        borderColor:border2Color
                    }}
                > 2</Text>

                <View style={{
                    height: 2, width: 30,flex:1,
                    alignSelf: 'center', backgroundColor: border3Color
                }} />


                <Text
                    style={{
                        height: 30, width: 30, borderRadius: 15,textAlign:'center',
                        textAlignVertical: "center",color:t3Color,paddingRight:3,
                        alignSelf: 'center', backgroundColor: backGround3Color,borderWidth:1,
                        borderColor:border3Color
                    }}
                > 3</Text>

                <View style={{
                    height: 2, width: 30,flex:1,
                    alignSelf: 'center', backgroundColor: border4Color
                }} />


                <Text
                    style={{
                        height: 30, width: 30, borderRadius: 15,textAlign:'center',
                        textAlignVertical: "center",color:t4Color,paddingRight:3,
                        alignSelf: 'center', backgroundColor: backGround4Color,borderWidth:1,
                        borderColor:border4Color
                    }}
                > 4</Text>
            </View>


        );
    }
}


export default Steps;