import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Text
} from 'react-native';
import { connect } from 'react-redux'


class FlyButton extends Component {

    
    render() {
        color = (!this.props.color)?'#650764':this.props.color;
        onPress = this.props.onPress;

        if(this.props.isInActive){
            color = '#D9DDE2';
            onPress = null;
        }

        return (
        <TouchableOpacity  style={[{
            backgroundColor: color,
            width: "100%",
            height:40,
            borderRadius:5,
            justifyContent: 'center',
        },this.props.style]}
            onPress={onPress}>
            <Text
                style={{
                    fontFamily: 'OpenSans-SemiBold',
                    color: '#ffffff',
                    width: "100%",
                    textAlign: 'center',
                    fontSize:14,
                }}>
                {this.props.title}
            </Text>
        </TouchableOpacity>
        );
    }
}


export default FlyButton;