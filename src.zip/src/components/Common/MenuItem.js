import React, { Component } from 'react';

import {
    View,
    TouchableOpacity,
    Text, Image
} from 'react-native';


class MenuItem extends Component {


    render() {
        onPress = this.props.onPress;

        return (
            <TouchableOpacity style={[{
                width: 200,
                height: 40,
                marginLeft:50,
                borderRadius: 5,
                justifyContent: 'center',
                flexDirection: 'row'
            }, this.props.style]}
                onPress={onPress}>

                <View style={[{
                    width: '100%',
                    height: 40,
                    justifyContent: 'center',
                    flexDirection: 'row'
                }]}>

                    <Image
                        source={this.props.imagePath}
                        style={{
                            height: 20, width: 20, resizeMode: 'cover',
                            alignSelf: 'center'
                        }}
                    />
                    <Text
                        style={{
                            fontFamily: 'OpenSans-SemiBold',
                            color: '#3C3C3C',
                            width: "100%",
                            fontSize: 14,
                            alignSelf:'center',
                            marginLeft:30
                        }}>
                        {this.props.title}
                    </Text>
                </View>

            </TouchableOpacity>
        );
    }
}


export default MenuItem;