import React from 'react'
import {StyleSheet,  View, ActivityIndicator, Dimensions } from 'react-native'
const windowHeight = Dimensions.get('window').height * 0.4


export default class OrderSubmitting extends React.Component {


    static navigationOptions = ({ navigation }) => {
        return {
            headerLeft: null
        }
    }


    ActivityIndicatorLoadingView() {
        return (
        <ActivityIndicator
            color='#009688'
            size='large'
            style={stylesLoading.ActivityIndicatorStyle}
            />
        )
    }
    render() {
        return (
            <View >
                {/* <Image style={styles.fitImage} source={{
                    uri: STORAGE_URL + 'static/assets/images/plane_nomatt.gif'
                }}
                    style={{ height: 100, width: 100, }}
                /> */}
                {this.ActivityIndicatorLoadingView()}
            </View>
        )
    }
}

const stylesLoading = StyleSheet.create({
    ActivityIndicatorStyle:{
      position: 'absolute',
      left: 0,
      right: 0,
      top: windowHeight,
      bottom: 0,
      alignItems: 'center',
      justifyContent: 'center'
    }
})
