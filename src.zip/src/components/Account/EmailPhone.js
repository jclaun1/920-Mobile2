import React from 'react'
import {Text, View, TextInput, TouchableOpacity, Alert } from 'react-native'
import AsyncStorage from '@react-native-community/async-storage'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import styles from '../../../assets/css/style'
import OrderSubmitting from '../Common/OrderSubmitting'
import ConfirmPhone from './ConfirmPhone'
import ModalFilterPicker from 'react-native-modal-filter-picker'
import {connect}  from 'react-redux'
import axios from 'axios'
import NewHeader from '../Menu/NewHeader'
import moment from 'moment'

class EmailPhone extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            phone: '',
            email: '',
            isPhone: false,
            send_otp: true,
            isEmail: false,
            countryCode: 101,
            country_list: [],
            countryCodes: [],
            selectedCountry: 'India(+91)',
            phoneCode: '+91',
            isLoading: true,
            visible: false,
            isModal: false,
            storageData:null
        }
    }

    static navigationOptions = ({ navigation }) => {
        return {
          header: <NewHeader title="Email & Phone Settings" isHome={false}  navigate={navigation}/>
        }
    }

    async _countryListCall() {
        await this.setState({
            isLoading: true
        })
        try {
            let response = await axios.get('country/code')
            let responses = response.data

            var countryList = []
            await responses.forEach(element => {
                countryList.push({ key: element.id, label: element.name + '(' + element.dial_code + ')' })
            })

            this.setState({
                country_list:countryList,
                countryCodes: responses,
                isLoading: false
            })

        } catch (error) {
            // console.log(error)
            await this.setState({
                isLoading: false
            })
        }
    }

    async _filterResult(indexkey) {
        const resultcode = await this.state.countryCodes.find( element => element.id === indexkey)
        return resultcode
    }

    _onSelect = async (picked) => {
        try {
            let result = await this._filterResult(picked)
            this.setState({
                selectedCountry:  result.name + '(' + result.dial_code + ')',
                countryCode: picked,
                phoneCode: result.dial_code,
                visible: false
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                visible: false
            })
        }
    }

    async _sendmail () {

        if (!this.state.email) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {
            const data = {
                email: this.state.email
            }

            let response = await axios.post('update/email', data)
           
            Alert.alert('success!','Check your email inbox.')

            if (response.data.isMailSend) {
                this.setState({
                    isLoading: false,
                    isEmail: false
                })
                var userDatas = this.props.user
                userDatas.isEmailVerified = false
                userDatas.email_update =  this.state.email
                this.props.updateUserData(userDatas)
            }else{
                this.setState({
                    isLoading: false
                })
            }

        } catch (error) {
            // console.log(error.request.response)

            this.setState({
                isLoading: false
            })
            Alert.alert('opps!','Somthing went wrong!')
        }

    }

    async _sendOTP () {

        if (!this.state.phone || !this.state.countryCode) {
            return
        }

        this.setState({
            send_otp: false,
            isLoading: true,
            isModal: false
        })

        try {
            var otp_session  = await AsyncStorage.getItem('otp_session')
            if (otp_session) {
                var otp_send_at  = await AsyncStorage.getItem('otp_send_at')
                if (moment().diff(moment(JSON.parse(otp_send_at)).utc(), 'seconds') < 30) {
                    Alert.alert('Oops!', 'Code can be resent only once per 30 seconds')
                    this.setState({
                        send_otp: true,
                        isLoading: false
                    })
                    return
                }
            }

            const dataP = {
                phone: this.state.phone,
                code: this.state.countryCode
            }

            let response = await axios.post('update/phone', dataP)
            var otpsession = response.data.data.Details
            await AsyncStorage.setItem('otp_send_at', JSON.stringify(moment().utc()))
            await AsyncStorage.setItem('otp_session', otpsession)

            this.setState({
                send_otp: true,
                isLoading: false,
                isModal: true,
                isPhone: false
            })

            var userDatas = this.props.user
            userDatas.isPhoneVerified = false
            userDatas.phone =  this.state.phone
            userDatas.country_code = this.state.countryCode
            this.props.updateUserData(userDatas)

        } catch (error) {
            this.setState({
                send_otp: true,
                isLoading: false,
                isModal: false
            })
            if (error.request) {
                var errorData = JSON.parse(error.request.response)
                // console.log(errorData)
                if (errorData.errors) {
                    if (errorData.errors.phone) {
                        Alert.alert('Oops!', errorData.errors.phone[0])
                        return
                    }
                }
                Alert.alert('Oops!', "Somthing went wrong")
            }else{
                // console.log(error)
                Alert.alert('Oops!', "Somthing went wrong")
            }
        }
    }

    _handleSuccess() {
        this.setState({
            send_otp: true,
            isLoading: false,
            isModal: false,
            isPhone: true
        })
        var userData = this.props.user
        userData.isPhoneVerified = true
        this.props.updateUserData(userData)

        if (this.state.storageData) {
            this.props.navigation.navigate('OrderSubmittingData')
        }
    }

    componentDidMount(){
        this._componentWillLoad()
    }

    async _componentWillLoad(){
        let user = this.props.user
        let storageData = await AsyncStorage.getItem('submitdata')
        this.setState({
            storageData,
            phone: user.phone,
            email: user.email_update ? user.email_update : user.email,
            isPhone: user.isPhoneVerified ? true : false,
            isEmail: user.isEmailVerified ? true : false,
            countryCode: user.country_code ? user.country_code.id : 101,
            selectedCountry: user.country_code ? user.country_code.name + '(' + user.country_code.dial_code +  ')' : 'India(+91)',
            phoneCode: user.country_code ? user.country_code.dial_code : '+91',
        })
        this._countryListCall()
    }

    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting/>
            )
        } else {
            var sendotp_button = <TouchableOpacity  onPress={() => this._sendOTP()}>
                                    <Text style={styles.Searchbtn}>{this.state.isPhone ? 'Update Phone' : 'Send OTP'} </Text>
                                </TouchableOpacity>

            return (
                <View style={styles.container}>

                    {this.state.isModal ? <ConfirmPhone phone={this.state.phoneCode + '' + this.state.phone} onSuccess={() => this._handleSuccess()} onResend={() => this._sendOTP()} onClose={() => this.setState({isModal: false})}/> : null}

                    <View style={[styles.card, styles.shadow]}>
                        <Text style={styles.profilemenuheading}>
                            Phone <FontAwesome name={this.state.isPhone ? 'check' : 'exclamation-circle'} size={25} style={{ color: this.state.isPhone ? "#1e821f" : 'red' }} />
                        </Text>

                        <View style={styles.changepasswordfromgroup}>
                            <View style={styles.country_phone}>
                                <View style={{width:'35%'}}>
                                    <TouchableOpacity onPress={() => this.setState({visible: true})} >
                                        <Text style={{fontSize:16,color:'#5d5d5d',textAlign:'left',width:'100%',paddingLeft:25,}} >{this.state.selectedCountry}</Text>
                                    </TouchableOpacity >
                                    <ModalFilterPicker
                                        visible={this.state.visible}
                                        onSelect={this._onSelect}
                                        onCancel={() => this.setState({visible: false})}
                                        options={this.state.country_list}
                                    />
                                </View>
                                <View style={{width:'65%'}}>
                                    <TextInput style={[styles.inputbox,styles.borderWidth0]}
                                        placeholder="1234567890"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        value={this.state.phone}
                                        onChangeText={(phone) => this.setState({phone})}
                                    />
                                </View>
                            </View>
                        </View>

                        <View style={styles.changepasswordfromgroup}>
                            {this.state.send_otp ? sendotp_button : null}
                        </View>


                        <Text style={styles.profilemenuheading}>
                            Email    <FontAwesome name={this.state.isEmail ? 'check' : 'exclamation-circle'} size={25} style={{ color: this.state.isEmail ? "#1e821f" : 'red' }} />
                        </Text>

                        <View style={styles.changepasswordfromgroup}>
                            <TextInput style={styles.inputbox}
                                placeholder="example@example.com"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                value={this.state.email}
                                onChangeText={(email) => this.setState({email})}
                            />
                        </View>

                        <View style={styles.changepasswordfromgroup} >
                            <TouchableOpacity onPress={() => this._sendmail()}>
                                <Text style={styles.Searchbtn}>Update Email</Text>
                            </TouchableOpacity>
                        </View>

                    </View>
                </View>
            )
        }
    }
}

const mapDispatchToProps = dispatch => ({
    updateUserData: user => {
        dispatch({
            type: 'USER_SUCCESS',
            payload: user
        })
    }
});

const mapStateToProps = state => {
    return {
        user: state.auth.user
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(EmailPhone)
