import React from 'react';
import { StyleSheet, Text, View,TouchableOpacity } from 'react-native'
import styles from '../../../assets/css/style';
import {connect}  from 'react-redux'
import OrderSubmitting from '../Common/OrderSubmitting'
import { Item, Picker, Icon } from 'native-base'
import axios from 'axios'
import NewHeader from '../Menu/NewHeader'
import FlyButton from '../Common/FlyButton';

class MoreSetting extends React.Component {

    constructor() {
        super();
        this.state = {
            isEmail: true,
            isSms: false,
            isUsd: false,
            currency : 1,
            isLoading: true
        }
    }

    static navigationOptions = ({ navigation }) => {
        return {
          header: <NewHeader title="Toggle Notification" isHome={false} navigate={navigation}/>
        }
    }

    async updateSettings () {
        this.setState({
            isLoading: true
        })
        try {
            const data = {
                isSms: this.state.isSms ? 1: 0,
				isEmail: this.state.isEmail ? 1: 0,
				currency: this.state.isUsd ? 'USD' : 'INR'
            }

            var userData = this.props.user

            await axios.put('user/save/settings', data)

            userData['currency'] = this.state.isUsd ? 'USD' : 'INR'
            userData['isSms'] = this.state.isSms ? 1 : 0
            userData['isEmail'] = this.state.isEmail ? 1 : 0

            this.props.updateUserData(userData);
            this.setState({
                isLoading: false
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
        }
    }

    componentDidMount () {
        this.setState({
            isUsd: this.props.user.currency == 'INR' ? false : true,
            isSms: this.props.user.isSms ? true : false,
            isEmail: this.props.user.isEmail ? true : false,
            currency: this.props.user.currency == 'INR' ? "1" : "2",
            isLoading:false
        })
    }
    handlerSwitchToggle = () => {
        this.setState({
            isEmail: !this.state.isEmail
        });
    }
    handlerPhoneToggle = () => {
        this.setState({
            isSms: !this.state.isSms
        });
    }
    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting/>
            )
        } else {

            const pagestyle = StyleSheet.create({
                toggel: {
                    height: 28,
                    width: 28,
                    borderRadius: 60,
                    backgroundColor: '#fff',
                    marginTop:1,
                },
                toggelemail: {
                    left: this.state.isEmail ? 30 : 0,

                },

                toggelephone: {
                    left: this.state.isSms ? 30 : 0,
                },

                switch: {
                    height: 30,
                    width: 60,
                    borderRadius: 57,
                },
                switchemail: {
                    backgroundColor: this.state.isEmail ? '#660165' : '#ccc',
                },
                switchphone: {
                    backgroundColor: this.state.isSms ? '#660165' : '#ccc',
                },
            })

            return (
                <View style={[styles.container,{height:'100%',}]}>
                    <View style={[styles.card,{height:'100%',width:'90%'}]}>
                        {/* <Text style={styles.profilemenuheading}>Toggle Notifications</Text> */}
                        <View style={styles.toggelswitchmain}>
                            <Text style={styles.fontFamilyregular}>Email</Text>
                            <View style={[pagestyle.switch, pagestyle.switchemail]}>
                                <TouchableOpacity
                                    onPress={this.handlerSwitchToggle}
                                    style={[pagestyle.toggel, pagestyle.toggelemail]}>
                                    <Text>
                                        {this.state.isEmail ? '' : ''}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        </View>

                        <View style={styles.toggelswitchmain}>
                            <Text style={styles.fontFamilyregular}>SMS</Text>
                            <View style={[pagestyle.switch, pagestyle.switchphone]}>
                                <TouchableOpacity
                                    onPress={this.handlerPhoneToggle}
                                    style={[pagestyle.toggel, pagestyle.toggelephone]}>
                                    <Text>
                                        {this.state.isSms ? '' : ''}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        </View>

                        <View style={{width:'100%',flexDirection:'row',justifyContent:'space-between'}}>
                            <Text style={[styles.fontFamilyregular,{textAlign:'center',marginTop:10}]}>Currency {this.state.isUsd ? 'USD' : 'INR'}</Text>
                            <View style={{width:150,borderWidth:1,borderColor:'#ccc'}}>
                                <Item picker>
                                    <Picker
                                        mode="dropdown"
                                        iosIcon={<Icon name="md-arrow-down" />}
                                        style={{ width: undefined }}
                                        placeholder="Select your currency"
                                        placeholderStyle={{ color: "#bfc6ea" }}
                                        placeholderIconColor="#007aff"
                                        selectedValue={this.state.currency}
                                        onValueChange={(itemValue, itemIndex) => this.setState({currency: itemValue, isUsd: itemValue == 2 ? true : false})}
                                    >
                                        <Picker.Item label="₹  Rupee" value="1" />
                                        <Picker.Item label="$  Dollar" value="2" />
                                    </Picker>
                                </Item>

                            </View>
                        </View>

                        <View style={[{position:'absolute',bottom:10,width:'100%',alignItems:'center'}]}>

                        <FlyButton onPress={() => this.updateSettings()} title='Save Changes' />
                            {/* <TouchableOpacity onPress={() => this.updateSettings()}>
                                <Text style={styles.Searchbtn}>Save Changes</Text>
                            </TouchableOpacity> */}
                        </View>

                    </View>
                </View>
            )
        }
    }
}

const mapDispatchToProps = dispatch => ({
    updateUserData: user => {
        dispatch({
            type: 'USER_SUCCESS',
            payload: user
        })
    }
});

const mapStateToProps = state => {
    return {
        user: state.auth.user
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(MoreSetting)
