import React from 'react'
import { StyleSheet, ActivityIndicator} from 'react-native'
import AsyncStorage from '@react-native-community/async-storage'

import {connect}  from 'react-redux'
import axios from 'axios'
class LogOut extends React.Component {

  constructor(props) {
    super(props)
    this._logOut = this._logOut.bind(this)
  }

  static navigationOptions = {
    header: null
  }

  _ActivityIndicatorLoadingView(navigate) {
    return (
      <ActivityIndicator
        color='#009688'
        size='large'
        style={stylesLoading.ActivityIndicatorStyle}
      />
    )
  }


  async _logOut(navigate) {
    try {
      await AsyncStorage.removeItem('token')
      await AsyncStorage.removeItem('submitdata')
      await axios.patch('logout')
      await this.props.updateLogOut()
      navigate('UnAuthenticated')
    } catch (error) {
      console.log(error)
      navigate('UnAuthenticated')
    }
  }

  componentDidMount(){
    const { navigate } = this.props.navigation
    this._logOut(navigate)
  }

  render() {
    const { navigate } = this.props.navigation
    return this._ActivityIndicatorLoadingView(navigate)
  }
}

const mapDispatchToProps = dispatch => ({
  updateLogOut: () => {
    dispatch({
      type: 'USER_LOGOUT'
    })
  }
})

const mapStateToProps = state => {
  return {
    user: state.auth.user
  }
}

const stylesLoading = StyleSheet.create({
  ActivityIndicatorStyle:{
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center'
  }
})

export default connect(mapStateToProps, mapDispatchToProps)(LogOut)
