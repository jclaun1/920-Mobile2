import React from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  ScrollView,
  SafeAreaView,
  RefreshControl,
  BackHandler,
} from 'react-native';
import styles from '../../../../assets/css/style';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {STORAGE_URL} from '../../../config/env';
import ChatListHeader from '../../Menu/ChatListHeader';
import axios from 'axios';
import moment from 'moment';
import includes from 'lodash/includes';
var _this = null;
export default class ChatList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      messageinput: '',
      conversations: [],
      filtersConvs: [],
      isLoading: false,
      refreshing: false,
    };
  }

  static navigationOptions = ({navigation}) => {
    return {
      title: 'Chat List',
      header: (
        <ChatListHeader
          onChangeSearchText={text => _this._handleSearch(text)}
          navigate={navigation}
          title="Chat List"
        />
      ),
    };
  };

  async _handleSearch(text) {
    let filtersConvs = this.state.conversations;

    filtersConvs = await filtersConvs.filter(conversation => {
      return includes(conversation.username.toLowerCase(), text.toLowerCase());
    });

    this.setState({
      filtersConvs,
    });
  }

  formatdel(datetime) {
    return moment(datetime)
      .utcOffset('+0000')
      .format('DD MMM, YYYY');
  }

  sendat(datetime) {
    return moment(datetime)
      .utcOffset('+0000')
      .fromNow();
  }

  async _allConversion(type) {
    if (type) {
      await this.setState({
        refreshing: true,
      });
    } else {
      await this.setState({
        isLoading: true,
      });
    }
    try {
      let response = await axios.get('my/conversations');
      this.setState({
        conversations: response.data.data,
        filtersConvs: response.data.data,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      this.setState({
        isLoading: false,
        refreshing: false,
      });
    }
  }

  componentWillMount() {
    this._allConversion(0);
  }

  componentDidMount() {
    _this = this;
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
      refreshing: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={styles.container}>
          <ScrollView
            style={{width: '100%'}}
            refreshControl={
              <RefreshControl
                refreshing={this.state.refreshing}
                onRefresh={() => this._allConversion(1)}
                style={{backgroundColor: 'transparent'}}
              />
            }>
            <View>
              {this.state.filtersConvs.length > 0 ? (
                this.state.filtersConvs.map((conversation, index) => {
                  return (
                    <TouchableOpacity
                      key={index}
                      style={[styles.msg_find_user,{margin:10,width:'90%'}]}
                      onPress={() =>
                        this.props.navigation.push('Chat', {
                          slug: conversation.order_slug,
                          chatID: conversation.chat_room_Id,
                        })
                      }>
                      <Image
                        style={styles.sm_user_fit}
                        source={{
                          uri: conversation.avatar
                            ? conversation.avatar
                            : STORAGE_URL +
                              'static/assets/images/profile-up-img.png',
                        }}
                      />
                      <View style={styles.notifacationtextmain}>
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                          }}>
                          <Text
                            style={{
                              fontSize: 14,
                              color: '#610760',
                              marginTop:5,
                              fontFamily: 'OpenSans-semiBold',
                            }}>
                            {conversation.username}
                          </Text>
                          <Text
                            style={{
                              fontSize: 14,
                              color: '#000',
                              fontFamily: 'OpenSans-Regular',
                            }}>
                            {this.formatdel(conversation.created_at.date)}
                          </Text>
                        </View>
                        {/* <Text
                          style={{
                            fontSize: 15,
                            color: '#660165',
                            marginTop: 2,
                            marginBottom: 2,
                            fontFamily: 'OpenSans-regular',
                          }}>
                          {conversation.order_name_lm}
                        </Text> */}
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                          }}>
                        <Text
                          style={{
                            fontSize: 12,
                            color: '#484545',
                            marginTop:5,
                            fontFamily: 'OpenSans-Regular',
                          }}>
                          {conversation.message_lm}
                        </Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  );
                })
              ) : (
                <Text>No users found</Text>
              )}
            </View>
          </ScrollView>
        </View>
      );
    }
  }
}
