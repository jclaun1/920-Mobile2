import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TextInput,
  TouchableOpacity,
  BackHandler,
  Alert,
  RefreshControl,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import styles from '../../../../assets/css/style';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {connect} from 'react-redux';
import axios from 'axios';
import {STORAGE_URL} from '../../../config/env';
import moment from 'moment';
import {
  inboxes,
  inboxIncDec,
} from '../../../redux/actions/notificationInboxAction';
import debounce from 'lodash/debounce';
import ChatHeader from '../../Menu/ChatHeader';
import ImageComponent from './ImageComponent';

import ImagePicker from 'react-native-image-picker';

class Chat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      refreshing: false,
      allmessages: [],
      channel: null,
      order: {},
      messageinput: '',
      sendNotification: true,
      image: null,
      imagePopUp: false,
      typing: false,
      isMeTyping: false,
      uri: null,
      isScrolled: false,
      headerData: {},
      indexSubmit: null,
      isOnlyImage: false,

      slug: '',
      chatID: null,
      extraDataHeight: 0,
    };

    this.scrollView = null;

    this.typinguser = this.typinguser.bind(this);
  }

  componentWillMount() {
    this.keyboardWillShowSub = Keyboard.addListener(
      'keyboardWillShow',
      this.keyboardWillShow,
    );
    this.keyboardWillHideSub = Keyboard.addListener(
      'keyboardWillHide',
      this.keyboardWillHide,
    );
  }

  componentWillUnmount() {
    this.keyboardWillShowSub.remove();
    this.keyboardWillHideSub.remove();
  }

  static navigationOptions = ({navigation}) => {
    return {
      title: 'Order Post',
      header: <ChatHeader navigate={navigation} title="Chat" />,
    };
  };

  keyboardWillShow = () => {
    this.setState({extraDataHeight: 80});
    this.scrollView.scrollToEnd();
  };

  keyboardWillHide = () => {
    this.setState({extraDataHeight: 0});
    this.scrollView.scrollToEnd();
  };

  _messageRead() {
    this.state.allmessages.forEach((element, key) => {
      if (element.status != 3 && element.sender_id != this.props.user.id) {
        var index = this.props.inboxes.findIndex(
          noti => noti.data.msgid == element.id,
        );
        this._updateMessageRecived(element.id, 3, 1, index);
      }
    });
  }

  _userJoined(roomId) {
    window.Echo.join(`chatRoom.${roomId}`)
      .here(users => {
        this.setState({
          sendNotification: users.length == 2 ? false : true,
        });
      })
      .joining(user => {
        this.setState({
          sendNotification: false,
        });
      })
      .leaving(user => {
        this.setState({
          sendNotification: true,
        });
      });
  }

  _messageRecived(index) {
    Echo.private(`chat.${this.state.channel.id}`).whisper('messageSent', {
      index: index,
    });
  }

  async _updateMessageRecived(id, stat, seen, indexpo) {
    try {
      var data;
      if (seen) {
        var notiId;
        if (indexpo > -1) {
          notiId = this.props.inboxes[indexpo].id;
        } else {
          notiId = 77777777;
        }
        data = {status: stat, seen: seen, notificationId: notiId};
      } else {
        data = {status: stat, seen: seen, notificationId: 77777777};
      }

      await axios.post('recived/message/' + id, data);

      if (seen) {
        var inboxesData = this.props.inboxes;
        inboxesData[indexpo]['read_at'] = moment().format('YYYY-MM-DD H:mm:ss');
        this.props.updatedInbox(inboxesData);
        this.props.updatedInboxCount(0);
      }

      if (!this.state.sendNotification && seen) {
        var index = this.state.allmessages.findIndex(
          message => message.id == id,
        );
        window.Echo.private(`chat.${this.state.channel.id}`).whisper(
          'messageSeen',
          {
            index: index,
          },
        );
      }
    } catch (error) {
      // console.log(error)
    }
  }

  _livechat(channelId) {
    window.Echo.private(`chat.${channelId}`)
      .listen('MessageSend', e => {
        if (this.props.user.id != e.data.sender_id) {
          var messages = this.state.allmessages;
          messages.push(e.data);
          this.setState({
            allmessages: messages,
          });
          this._messageRecived(this.state.allmessages.length - 1);
        } else {
          const userisOnlinedd = this.props.users.filter(obj => {
            return obj.id == this.state.channel.usrID;
          });
          if (userisOnlinedd.length > 0) {
            var messages = this.state.allmessages;
            messages[messages.length - 1]['status'] = 2;
            this.setState({
              allmessages: messages,
            });
            this._updateMessageRecived(
              this.state.allmessages[this.state.allmessages.length - 1].id,
              2,
              0,
            );
          }
        }
      })
      .listenForWhisper('typing', e => {
        if (e.name != '') {
          this.setState({
            typing: true,
          });
        } else {
          this.setState({
            typing: false,
          });
        }
      })
      .listenForWhisper('messageSent', e => {
        if (this.props.user.id == this.state.allmessages[e.index].sender_id) {
          if (!this.state.sendNotification) {
            var messages = this.state.allmessages;
            messages[e.index]['status'] = 3;
            this.setState({
              allmessages: messages,
            });
            this._updateMessageRecived(
              this.state.allmessages[e.index].id,
              3,
              0,
            );
          }
        }
      })
      .listenForWhisper('messageSeen', e => {
        var messages = this.state.allmessages;
        messages[e.index]['status'] = 3;
        this.setState({
          allmessages: messages,
        });
        this._updateMessageRecived(this.state.allmessages[e.index].id, 3, 0);
      });
  }

  _formatDeliveryDate(time, date) {
    if (date) {
      return moment(time).format('h:mm A');
    }
    let createdAt = time.date ? time.date : time; //moment(time, 'DD/MM/YYYY')
    let now = moment();
    let days = moment.duration(now.diff(createdAt)).asDays();

    if (days < 1) {
      return 'Today';
    } else if (days < 2) {
      return 'Yesterday';
    } else {
      return moment(createdAt).format('DD MMM, YYYY');
    }
  }

  typinguser = debounce(typing => {
    if (typing) {
      this.setState({
        isMeTyping: true,
      });
      window.Echo.private(`chat.${this.state.channel.id}`).whisper('typing', {
        name: 'typing',
      });
    } else {
      if (this.state.isMeTyping) {
        this.setState({
          isMeTyping: false,
        });
        window.Echo.private(`chat.${this.state.channel.id}`).whisper('typing', {
          name: '',
        });
      }
    }

    setTimeout(() => {
      this.typinguser(0);
    }, 500);
  }, 500);

  async allmessages(slug, chatID, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    }

    console.log('slug => ' + slug, 'chatID => ' + chatID, 'type => ' + type);

    try {
      let response = await axios.get('messages/' + slug + '/' + chatID);

      let headerData = {
        username_slug: response.data[2].username,
        username: response.data[2].name,
        user_avatar: response.data[2].user_avatar,
        order_name: response.data[1].name_item_lm,
        order_slug: response.data[1].slug,
      };
      await this.setState({
        allmessages: response.data[0],
        channel: response.data[2],
        order: response.data[1],
        refreshing: false,
        isLoading: false,
      });

      this.props.navigation.setParams({headerData});
      // this._livechat(response.data[2].id)
      // this._userJoined(response.data[2].id)
    } catch (error) {
      console.log('Chat load error: ', error);

      // if (error.request.response) {
      //     console.log(error.request.response)
      // }else{
      //     console.log(error)
      // }
      this.setState({
        isLoading: false,
        refreshing: false,
      });
      await Alert.alert('Oops!', 'server error!');
      // this.props.navigation.navigate('MyOrders')
    }
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack();
      return true;
    });

    const slug = this.props.navigation.getParam('slug');
    const chatID = this.props.navigation.getParam('chatID');
    this.setState({
      slug,
      chatID,
    });
    this.allmessages(slug, chatID, 0);
    console.log('in chat now.');
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  _updatevalue() {
    let data = {
      avatar: this.props.user.avatar,
      created_at: {date: moment()},
      date: moment().format('DD/MM/YYYY'),
      iSMe: true,
      message: this.state.messageinput,
      read_at: null,
      status: 5,
      images: this.state.uri ? [this.state.uri] : [],
      sender_id: this.props.user.id,
      sendBy: this.props.user.first_name + ' ' + this.props.user.last_name,
    };

    let messages = [...this.state.allmessages];
    messages.push(data);
    this.setState({
      messageinput: '',
      image: null,
      uri: null,
      allmessages: messages,
    });
    return;
  }

  _pickImage = async index => {
    let options = {
      storageOptions: {
        skipBackup: true,
      },
    };

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        this.setState({
          image: response.data,
          uri: response.uri,
          indexSubmit: index,
          imagePopUp: true,
          isOnlyImage: false,
        });
      }
    });
  };

  async _onSubmitImage(text) {
    this.setState({
      messageinput: text,
      imagePopUp: false,
      isOnlyImage: false,
    });
    this._send(this.state.indexSubmit);
  }

  async _send(index) {
    try {
      if (!this.state.messageinput && !this.state.image) {
        return;
      }

      const datasend = {
        message: this.state.messageinput,
        images: this.state.image ? [this.state.image] : [],
        isMobile: 1,
        sendNotification: this.state.sendNotification ? 1 : 0,
        userID: this.state.channel.usrID,
        chatRoomId: this.state.channel.id,
        create: 0,
      };

      this._updatevalue();

      let response = await axios.post(
        '/send/message/' + this.state.order.slug,
        datasend,
      );
      let newAllMessages = [...this.state.allmessages];
      newAllMessages[index]['status'] = 1;
      newAllMessages[index]['id'] = response.data.data.id;
      this.setState({
        allmessages: newAllMessages,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _messageImagesElement(images) {
    if (images.length > 0) {
      var imagescomp = [];

      images.forEach((image, index) => {
        var compo = (
          <View style={styles.chatuserpicsecond} key={index}>
            <TouchableOpacity
              onPress={() =>
                this.setState({uri: image, isOnlyImage: true, imagePopUp: true})
              }>
              <Image
                source={{uri: image}}
                resizeMode="contain"
                style={{height: 200, width: 220}}
              />
            </TouchableOpacity>
          </View>
        );
        imagescomp.push(compo);
      });

      return imagescomp;
    } else {
      return null;
    }
  }

  render() {
    if (this.state.isLoading && !this.state.imagePopUp) {
      return <OrderSubmitting />;
    } else if (!this.state.isLoading && this.state.imagePopUp) {
      return (
        <ImageComponent
          imageUrl={this.state.uri}
          OnlyImage={this.state.isOnlyImage}
          onClose={() => this.setState({imagePopUp: false, isOnlyImage: false})}
          onSubmitImage={text => this._onSubmitImage(text)}
        />
      );
    } else {
      return (
        <KeyboardAvoidingView
          style={{flex: 1}}
          behavior={Platform.OS === 'ios' ? 'padding' : null}>
          <View style={styles.container}>
            <View style={[styles.scrollviewchat]}>
              <ScrollView
                ref={ref => (this.scrollView = ref)}
                onContentSizeChange={() =>
                  this.scrollView.scrollToEnd({animated: true})
                }
                refreshControl={
                  <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={() =>
                      this.allmessages(this.state.slug, this.state.chatID, 1)
                    }
                    style={{backgroundColor: 'transparent'}}
                  />
                }>
                {this.state.allmessages.map((message, index) => {
                  var imageAvatar = (
                    <View style={styles.chatuserpic}>
                      <Image
                        source={{
                          uri: message.avatar
                            ? message.avatar
                            : STORAGE_URL +
                              'static/assets/images/profile-up-img.png',
                        }}
                        resizeMode="cover"
                        style={styles.chat_user_sm}
                      />
                    </View>
                  );
                  var messageComponent = null;
                  if (message.message) {
                    if (message.iSMe) {
                      messageComponent = (
                        <Text style={styles.chatmsgsecond}>
                          {message.message}
                        </Text>
                      );
                    } else {
                      messageComponent = (
                        <Text style={styles.chatmsg}>{message.message}</Text>
                      );
                    }
                  }
                  if (!message.iSMe) {
                    return (
                      <View key={index}>
                        <View style={styles.userone}>
                          <View style={styles.chatusermsg}>
                            {imageAvatar}
                            <View style={styles.massegwrap}>
                              <View>{messageComponent}</View>
                              {this._messageImagesElement(message.images)}
                              <Text style={{textAlign: 'left'}}>
                                {this._formatDeliveryDate(
                                  message.created_at,
                                  0,
                                )}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    );
                  } else {
                    var messagesStatus = [];

                    // if (message.status == 1 || message.status == 2 || message.status == 3) {
                    //     messagesStatus.push(<Entypo key={index + "1"} name='check' size={15} style={{color:message.status == 3 ? 'blue' : '#2d2d2d'}}/>)
                    // }

                    // if (message.status == 2 || message.status == 3) {
                    //     messagesStatus.push(<Entypo key={index + "2"} name='check' size={15}  style={{position: 'relative',left:-8,top:2,color:message.status == 3 ? 'blue' : '#2d2d2d'}}/>)
                    // }

                    // if (message.status == 4) {
                    //     messagesStatus.push(<FontAwesome key={index +  "3"}  name='check' size={15} style={{color: '#2d2d2d'}}/>)
                    // }

                    if (message.status == 5) {
                      messagesStatus.push(
                        <Text key={index + '5'}>Sending....</Text>,
                      );
                    }

                    return (
                      <View key={index}>
                        <View style={styles.usersecond}>
                          <View style={styles.chatusermsgsecond}>
                            <View style={styles.massegwrapsecond}>
                              <View>
                                {messageComponent}
                                {this._messageImagesElement(message.images)}
                              </View>

                              {message.status == 5 ? null : (
                                <Text style={{textAlign: 'right'}}>
                                  {this._formatDeliveryDate(
                                    message.created_at,
                                    0,
                                  )}
                                </Text>
                              )}

                              <View
                                style={{
                                  flexDirection: 'row',
                                  justifyContent: 'flex-end',
                                }}>
                                {messagesStatus}
                              </View>
                            </View>
                            {imageAvatar}
                          </View>
                        </View>
                      </View>
                    );
                  }
                })}
              </ScrollView>
            </View>
            {this.state.typing ? (
              <Text>{this.state.channel.name} is typing ....</Text>
            ) : null}
            <View style={[styles.Chatfooter, {}]}>
              <View style={styles.sendmassegs}>
              <TouchableOpacity
                    style={{width: '50%'}}
                    onPress={() =>
                      this._pickImage(this.state.allmessages.length)
                    }>
                    <FontAwesome
                      name="camera"
                      size={20}
                      style={{
                        color: '#fff',
                        backgroundColor: '#222',
                        width: '100%',
                        paddingVertical: 15,
                        alignItems: 'center',
                        textAlign: 'center',
                      }}
                    />
                  </TouchableOpacity>
                <TextInput
                  style={styles.typemassage}
                  placeholder="Type Your Massages"
                  placeholderTextColor="#878787"
                  underlineColorAndroid="rgba(0, 0, 0,0)"
                  value={this.state.messageinput}
                  onChangeText={messageinput => this.setState({messageinput})}
                  returnKeyType="done"
                  // onKeyPress={() => this.typinguser(1)}
                  // onEndEditing={() => this.typinguser(0)}
                />
                <View style={styles.sendbox}>
                
                  <TouchableOpacity
                    style={{width: '50%'}}
                    onPress={() => this._send(this.state.allmessages.length)}>
                    <FontAwesome
                      name="send"
                      size={20}
                      style={{
                        color: '#fff',
                        backgroundColor: '#660165',
                        width: '100%',
                        paddingVertical: 15,
                        alignItems: 'center',
                        textAlign: 'center',
                      }}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
          <View style={{height: this.state.extraDataHeight}} />
        </KeyboardAvoidingView>
      );
    }
  }
}

const mapDispatchToProps = dispatch => ({
  updatedInbox: inboxeData => {
    dispatch(inboxes(inboxeData));
  },
  updatedInboxCount: inboxType => {
    dispatch(inboxIncDec(inboxType));
  },
});

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
    inboxes: state.auth.inboxes,
    inbox_count: state.auth.inbox_count,
    users: state.commonReducers.users,
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Chat);
