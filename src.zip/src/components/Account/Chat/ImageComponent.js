import React from 'react'
import {Text, View, TouchableOpacity, TextInput, Image, Modal, SafeAreaView, StatusBar} from 'react-native'
import styles from '../../../../assets/css/style'
import Entypo from 'react-native-vector-icons/Entypo'
import FontAwesome from 'react-native-vector-icons/FontAwesome'


export default class ImageComponent extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            messageinput: ''
        }
    }

    onSubmitImage(text) {
        this.setState({
            messageinput:''
        })

        this.props.onSubmitImage(text)
        
    }


    render() {

        return (
            <SafeAreaView>
            <Modal
                animationType="slide"
                transparent={false}
                visible={true}
                onRequestClose={() => {
                    this.props.onClose(false)
                }}>
                <TouchableOpacity style={{position:'absolute',top:30,right:10,zIndex:1,}} 
                        onPress={() => this.props.onClose(false)}>
                       <Text> <Entypo name="cross" size={40} style={{color:'#000'}} /></Text>
                </TouchableOpacity>
                <View style={[styles.chatpopupcontainer,]}>
                    <StatusBar hidden={true} />
                            <Image
                                source={{
                                    uri:this.props.imageUrl
                                }}
                                resizeMode="contain"
                                style={styles.canvas}
                                />
                
                        {
                            this.props.OnlyImage ? null : <View style={{width:'100%',paddingHorizontal:10,marginVertical:10,position:'absolute',bottom:10}}>
                                <View  style={{}}>
                                    <TextInput style={{
                                        width:'100%',
                                        borderWidth:1,
                                        height:40,
                                        borderColor:'#ccc',
                                        paddingHorizontal:5,
                                        paddingRight:150,
                                    }}
                                    placeholder="Type Your Massages"
                                    placeholderTextColor="#878787"
                                    underlineColorAndroid='rgba(0, 0, 0,0)'
                                    value={this.state.messageinput}
                                    onChangeText={(messageinput) => this.setState({ messageinput })}
                                    />
                                </View>

                                <View style={{width:100,position:'absolute',right:10,height:50,zIndex:1,}}>
                                    <TouchableOpacity style={{ width:100,backgroundColor:'#660165',justifyContent:'center',height:40 }} 
                                        onPress={() => this.onSubmitImage(this.state.messageinput)}>
                                    
                                        <FontAwesome name="send" size={20} style={{ color: '#fff', textAlign:'center'}} />
                                    </TouchableOpacity>
                                </View> 
                                
                            </View>
                        }
  
                </View>
         
               
            </Modal>
            </SafeAreaView>
        )

    }
}
