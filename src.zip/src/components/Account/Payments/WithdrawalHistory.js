import React from 'react'
import {  Text, View,TouchableOpacity } from 'react-native'
import Entypo from 'react-native-vector-icons/Entypo'
import styles from '../../../../assets/css/style'

export default class WithdrawalHistory extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={[styles.card, styles.shadow]}>
          <View style={styles.wallets}>
            <View style={styles.walletbalance}>

              <Text style={{ fontSize: 22, fontWeight: '600', color: '#660165', }}>
              <Entypo name="wallet" size={30} style={{ color: '#660165', }} />  INR 220</Text>
              <TouchableOpacity>
                <Text style={styles.balancebtn}>
                  Statement</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.walletbalance}>

            </View>
          </View>
          <Text style={{ fontSize: 16,color: '#000', fontWeight: '500', marginVertical: 5, }}>Last request</Text>
          <View style={styles.paymentsaction}>
            <Text style={[styles.fontbold, styles.countnumber]}>#</Text>
            <Text style={[styles.paymentrolefour, styles.fontbold]}>Amount</Text>
            <Text style={[styles.paymentrolefour, styles.fontbold]}>status</Text>
            <Text style={[styles.paymentrolefour, styles.fontbold]}>On</Text>
            <Text style={[styles.paymentrolefour, styles.fontbold]}>View More</Text>
          </View>
          <View style={styles.paymentsaction}>
            <Text style={[styles.countnumber]}>1</Text>
            <Text style={[styles.paymentrolefour, styles.linkcolor]}>INR 670.00	</Text>
            <Text style={[styles.paymentrolefour, styles.typecolorcreadit]}>Credit</Text>
            <Text style={[styles.paymentrolefour, styles.linkcolor]}>12/08/2018	</Text>
            <Text style={[styles.paymentrolefour, styles.fontbold]}>...</Text>
          </View>
        </View>

      </View>
    );
  }
}
