import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  StatusBar,
} from 'react-native';

import OrderSubmitting from '../../Common/OrderSubmitting';
import BanAccountkList from './PaymentList/BanAccountkList';
import PaypalAccountList from './PaymentList/PaypalAccountList';

import {connect} from 'react-redux';

import styles from '../../../../assets/css/style';
import {STORAGE_URL} from '../../../config/env';
import axios from 'axios';

class Withdrawal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      paypalAccounts: [],
      bankAccounts: [],
      withdraws: [],
      amount: 0,
      exchangeRate: 0,
      currency: '',
      isLoading: false,
      payId: '',
      isBank: true,
      description: '',
      accountID: null,
    };
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  _handleChecked(accountID) {
    this.setState({accountID});
  }

  async _walletsData() {
    this.setState({
      isLoading: true,
    });

    try {
      let response = await axios.get('my/withdraw/wallet/' + this.state.payId);

      this.setState({
        currency: this.props.currency,
        exchangeRate: response.data[3],
        paypalAccounts: response.data[0],
        bankAccounts: response.data[1],
        amount: this.props.currency + ' ' + response.data[2],
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _handleSubmit() {
    if (!this.state.amount || !this.state.accountID) {
      return;
    }
    this.setState({
      isLoading: true,
    });

    try {
      var data = {
        accountID: this.state.accountID,
        description: this.state.description,
      };

      let response = await axios.post(
        'withdraw/request/' + this.state.payId,
        data,
      );

      this.setState({
        isLoading: false,
        accountID: null,
      });
      await Alert.alert(
        'Successfully saved',
        'Withdraw of amount ' +
          this.state.amount +
          ' request successfully saved, your request Id is ' +
          response.data.data.u_ticket,
      );
      this.props.navigation.navigate('BalanceAndWithdrwal');
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        accountID: null,
      });
      Alert.alert('Opps!', 'Somthing went wrong!');
    }
  }

  async componentWillMount() {
    await this.setState({
      payId: this.props.navigation.getParam('payId'),
    });

    this._walletsData();
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var formElement = null;

      if (this.state.accountID) {
        formElement = (
          <View style={[styles.card, styles.shadow]}>
            <View style={styles.fromgroup}>
              <View>
                <Text style={styles.inputlabel}>Remarks</Text>
              </View>
              <TextInput
                style={styles.inputbox}
                placeholder="Remarks"
                placeholderTextColor="#878787"
                underlineColorAndroid="rgba(0, 0, 0,0)"
                value={this.state.description}
                onChangeText={description => this.setState({description})}
              />
            </View>

            <View style={styles.fromgroup}>
              <View>
                <Text style={styles.inputlabel}>Amount</Text>
              </View>
              <TextInput
                style={styles.inputbox}
                editable={false}
                placeholder="Amount"
                placeholderTextColor="#878787"
                underlineColorAndroid="rgba(0, 0, 0,0)"
                value={this.state.amount}
              />
            </View>

            <View style={styles.fromgroup}>
              <TouchableOpacity onPress={() => this._handleSubmit()}>
                <Text style={styles.Searchbtn}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        );
      }

      return (
        <ScrollView>
          <View style={styles.container}>
            <View style={[styles.card, styles.shadow]}>
              <View style={{}}>
                <View style={styles.walletbalance}>
                  <Text
                    style={{
                      fontSize: 20,
                      fontFamily: 'Montserrat-semiBold',
                      color: '#660165',
                    }}>
                    Select your payment method.
                  </Text>
                </View>
              </View>
              <View style={styles.chosseopt}>
                <TouchableOpacity
                  style={styles.chosseselect}
                  onPress={() =>
                    this.setState({isBank: true, accountID: null})
                  }>
                  <Image
                    style={styles.fitImage}
                    source={{
                      uri: this.state.isBank
                        ? STORAGE_URL + 'mobileapp/chaked.png'
                        : STORAGE_URL + 'mobileapp/unchaked.png',
                    }}
                    resizeMode="contain"
                    style={{height: 20, width: 20, marginRight: 5}}
                  />

                  <Text style={styles.fontFamilyregular}>Bank</Text>
                </TouchableOpacity>
                {/* <TouchableOpacity style={styles.chosseselect} onPress={() => this.setState({isBank: false, accountID: null})}>
                                    <Image style={styles.fitImage} source={{
                                        uri:  !this.state.isBank ? STORAGE_URL + 'mobileapp/chaked.png' : STORAGE_URL + 'mobileapp/unchaked.png'
                                    }}
                                        resizeMode='contain'
                                        style={{ height: 20, width: 20,marginRight:5, }}
                                    />
                                    <Text style={styles.fontFamilyregular}>Paypal</Text>
                                </TouchableOpacity> */}
              </View>
            </View>

            {this.state.isBank ? (
              <BanAccountkList
                onCheked={accountID => this._handleChecked(accountID)}
                accounts={this.state.bankAccounts}
              />
            ) : (
              <PaypalAccountList
                onCheked={accountID => this._handleChecked(accountID)}
                accounts={this.state.paypalAccounts}
              />
            )}

            {formElement}
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.user.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(Withdrawal);
