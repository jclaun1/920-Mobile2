import React from 'react'
import { Text, View, Modal, ScrollView, Alert, TextInput, TouchableOpacity, StatusBar } from 'react-native'
import styles from '../../../../../assets/css/style'
import {connect}  from 'react-redux'
import axios from 'axios'

class EditPaypalAccount extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            account: props.account,
			payaplId: '',
			confirmpayaplId: '',
            isLoading: false
        }
    }

    async _validate() {
        if (!this.state.payaplId || !this.state.confirmpayaplId) {
            return false
        }

        if (this.state.payaplId !== this.state.confirmpayaplId) {
            await Alert.alert('Opps!', 'your payal account not confirmd, plz confirm')
            return false
        }

        return true
    }

    componentWillMount() {
        this.setState({
            account: this.props.account,
            payaplId: this.props.account.accountID,
            confirmpayaplId: this.props.account.accountID
        })
    }

    async _handleEditAccount() {

        var isValid = await this._validate()

        if (!isValid) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {

            var accountData = {
                payaplId: this.state.payaplId,
                confirmpayaplId: this.state.confirmpayaplId
            }

            let response =  await axios.post('edit/account/' + this.state.account.id + '/paypal', accountData)
            await this.setState({
                payaplId: '',
                confirmpayaplId: '',
                isLoading: false
            })
            this.props.onAccountUpdated(response.data.data)
        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            await Alert.alert('Opps!', 'Somthing went wrong!')
        }
    }

    render() {
        var submit_button = null
        var cancel_button = null
        if (!this.state.isLoading) {

            submit_button  = <TouchableOpacity onPress={() => this._handleEditAccount()}>
                <Text style={styles.Searchbtn}>Update</Text>
            </TouchableOpacity>

            cancel_button = <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.props.onClose(false)}>
                    <Text style={styles.Searchbtn}>Cancel</Text>
                </TouchableOpacity>
            </View>

        } else {
            submit_button  = <TouchableOpacity>
                <Text style={styles.Searchbtn}>Updating....</Text>
            </TouchableOpacity>
        }

        return (
                <Modal animationType="slide"
                    transparent={false}
                    visible={true}
                    onRequestClose={() => {
                        this.state.isLoading ? console.log('') : this.props.onClose(false)
                    }}>
                    <ScrollView>
                        <View style={styles.container}>
                            <StatusBar hidden={true} />
                            <View style={[styles.card, styles.shadow]}>

                                <View style={{marginTop:50,marginBottom:20}}>
                                    <Text style={[styles.allheading, styles.colorpurple]}>Edit Account</Text>
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>Paypal email</Text>
                                    </View>
                                    <TextInput style={styles.inputbox}
                                        placeholder="Paypal email"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        onChangeText={(payaplId) => this.setState({payaplId})}
                                        value={this.state.payaplId}
                                    />
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>Confirm Paypal email</Text>
                                    </View>
                                    <TextInput style={styles.inputbox}
                                        placeholder="Confirm Paypal email"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        onChangeText={(confirmpayaplId) => this.setState({confirmpayaplId})}
                                        value={this.state.confirmpayaplId}
                                    />
                                </View>

                                <View style={styles.fromgroup}>
                                    {submit_button}
                                </View>

                                {cancel_button}

                            </View>
                        </View>
                    </ScrollView>
                </Modal>
            )
        }
    }

export default connect(null, null)(EditPaypalAccount)
