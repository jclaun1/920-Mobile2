import React from 'react'
import { Text, View, ScrollView, Modal, TouchableOpacity, StatusBar} from 'react-native'
import styles from '../../../../assets/css/style'

export default class InvoiceDetails extends React.Component {
  constructor(props) {
    super(props);
      this.state = {
        payment: props.payment
      }
    }

    render() {
      var isShow = this.props.isModal
      var payment = this.props.payment
      return (
        <Modal
              animationType="slide"
              transparent={false}
              visible={isShow}
              onRequestClose={() => {
                this.props.onClose(false)
              }}>
            <View style={[styles.container,styles.invoicemodel]}>
            <StatusBar hidden={true} />
            <ScrollView contentContainerStyle={{flexGrow: 1}} style={{maxWidth:'100%'}}>
                <View style={{marginVertical:25}}>
                    <Text style={{fontSize:25,color:"#660165",textAlign:'center',fontFamily:'Montserrat-bold',}}>Invoice</Text>
                  </View>
                
                <View style={{width:'100%',flexDirection:'row',justifyContent:'space-between',}}> 
                  <Text style={styles.transt_text}>#{payment.invoiceID}</Text>
                  <Text style={styles.transt_text}>{payment.paymentDate}</Text>
                </View>

                <View style={{width:'100%',marginVertical:25,}}> 
                    <View style={styles.main_list_row}>
                      <Text style={styles.transt_text}>Description</Text>
                      <Text style={styles.transt_text}>Quantity</Text>
                      <Text style={styles.transt_text}>Price</Text>
                    </View>
                    <Text style={styles.hrborder}></Text>

                    <View style={styles.main_list_row}>
                      <Text style={styles.transt_text}>{payment.item_name}</Text>
                      <Text style={styles.transt_text}> {payment.quantity}</Text>
                      <Text style={styles.transt_text}>{this.props.currency} {payment.price_with_q}</Text>
                    </View>

                    <View style={styles.main_list_row}>
                      <Text style={styles.transt_text}>Traveller Fee</Text>
                      <Text style={styles.transt_text}>{this.props.currency}  {payment.delivery_fee}</Text>
                    </View>

                    <View style={styles.main_list_row}>
                      <Text style={styles.transt_text}>Service Fee & Taxes</Text>
                      <Text style={styles.transt_text}></Text>
                      <Text style={styles.transt_text}>{this.props.currency}  {payment.service_fee}</Text>
                    </View>
                  
                  <View style={styles.main_list_row}>
                      <Text style={styles.transt_text}> Total</Text>
                      <Text style={styles.transt_text}></Text>
                      <Text style={styles.transt_text}>{this.props.currency}  {payment.total}</Text>
                  </View>
              </View>
              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.props.onClose(false)}>
                    <Text style={styles.Searchbtn}>Close</Text>
                </TouchableOpacity>
            </View>
            </ScrollView>
          </View>
        </Modal>
      )
    }
}


