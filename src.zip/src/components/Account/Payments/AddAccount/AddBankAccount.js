import React from 'react'
import {Text, View, TextInput, TouchableOpacity, ScrollView, Modal, Alert, StatusBar } from 'react-native'
import styles from '../../../../../assets/css/style'
import axios from 'axios'

export default class AddBankAccount extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            account: props.account,
			bank_name: '',
			ac_no: '',
			ifc_code: '',
			ac_holder_name: '',
			ifc_code_valid: false,
            isLoading: false,
            isValidating: false
        }
    }

    async _vallidateIFC() {

        if (!this.state.ifc_code) {
            return
        }

        this.setState({
            isValidating: true
        })

        try {
            await axios.get('validate/ifcCode?ifc=' + this.state.ifc_code)
            this.setState({
                isValidating: false,
                ifc_code_valid: true
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                isValidating: false,
                ifc_code_valid: false
            })
        }

    }

    async _validate() {

        if (!this.state.bank_name) {
            return false
        }

        if (!this.state.ac_no) {
            return false
        }

        if (!this.state.ifc_code) {
            return false
        }

        if (!this.state.ac_holder_name) {
            return false
        }

        if (!this.state.ifc_code_valid) {
            return false
        }

        return true
    }

    async _handleAddAccount() {

        let isValid = await this._validate()

        if (!isValid) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {

            let accountData = {
                bank_name: this.state.bank_name,
                ac_no: this.state.ac_no,
                ifc_code: this.state.ifc_code,
                ac_holder_name: this.state.ac_holder_name
            }

            let response =  await axios.post('add/account/bank', accountData)

            // this.setState({
            //     bank_name: '',
            //     ac_no: '',
            //     ifc_code: '',
            //     ac_holder_name: '',
            //     ifc_code_valid: false,
            //     isLoading: false
            // })
            this.setState({ 
                bank_name: '',
                ac_no: '',
                ifc_code: '',
                ac_holder_name: '',
                ifc_code_valid: false,
                isLoading: false
            }, () => {
              setTimeout(() => {
                this.props.onAccountAdded(response.data.data)
              }, 200)
            })
           
        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            Alert.alert("Opps!", 'Somthing went wrong!')
        }
    }

    render() {
        let submit_button = null
        let cancel_button = null

        if (!this.state.isLoading) {

            submit_button  = <TouchableOpacity onPress={() => this._handleAddAccount()}>
                <Text style={styles.Searchbtn}>{this.state.isLoading ? 'Submiting...': 'Submit'}</Text>
            </TouchableOpacity>

            cancel_button = <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() =>  this.props.onClose(false)}>
                    <Text style={styles.Searchbtn}>Cancel</Text>
                </TouchableOpacity>
            </View>

        } else {
            submit_button  = <TouchableOpacity>
                <Text style={styles.Searchbtn}>Submiting....</Text>
            </TouchableOpacity>
        }

        return (
            <Modal animationType="slide"
                    transparent={false}
                    visible={true}
                    onRequestClose={() => {
                        this.state.isLoading ? console.log('') :  this.props.onClose(false)
                    }}>
                    <ScrollView>

                        <View style={styles.container}>
                            <StatusBar hidden={true} />
                            <View style={[styles.card, styles.shadow]}>
                                <View style={{marginTop:50,marginBottom:20}}>
                                    <Text style={[styles.allheading, styles.colorpurple]}>Add Account</Text>
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>Bank Name</Text>
                                    </View>
                                    <TextInput style={styles.inputbox}
                                        placeholder="Bank Name"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        value={this.state.bank_name}
                                        onChangeText={(bank_name) => this.setState({bank_name})}
                                    />
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>Account Number</Text>
                                    </View>
                                    <TextInput style={styles.inputbox}
                                        placeholder="Account Number"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        value={this.state.ac_no}
                                        onChangeText={(ac_no) => this.setState({ac_no})}
                                    />
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>IFSC CODE</Text>
                                    </View>
                                    <View style={{width:'100%',flexDirection:'row',borderWidth:1,borderColor:'#ccc',overflow:'hidden',borderRadius:6,}}>
                                        <View style={{width:'65%'}}>
                                            <TextInput style={[styles.inputbox,styles.borderWidth0]}
                                                placeholder="IFSC CODE"
                                                placeholderTextColor="#878787"
                                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                                value={this.state.ifc_code}
                                                onChangeText={(ifc_code) => this.setState({ifc_code, ifc_code_valid: false})}
                                            />
                                        </View>
                                        <TouchableOpacity style={{width:"35%"}} onPress={() => this._vallidateIFC()}>
                                            <Text style={[styles.validbtn, this.state.ifc_code_valid ? styles.bggreen : styles.bgred]}>
                                                {this.state.isValidating ? 'Vilidating...'  : this.state.ifc_code_valid ?  'Vilidate' : 'Not Valid'}
                                            </Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>

                                <View style={styles.fromgroup}>
                                    <View>
                                        <Text style={styles.inputlabel}>Account Holder Name</Text>
                                    </View>
                                    <TextInput style={styles.inputbox}
                                        placeholder="Account Holder Name"
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        value={this.state.ac_holder_name}
                                        onChangeText={(ac_holder_name) => this.setState({ac_holder_name})}
                                    />
                                </View>

                                <View style={styles.fromgroup}>
                                    {submit_button}
                                </View>

                                {cancel_button}

                            </View>
                        </View>
                    </ScrollView>
                </Modal>
            )
        }
    }
