import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import EditPaypalAccount from '../EditAccount/EditPaypalAccount';
import AddPaypalAccount from '../AddAccount/AddPaypalAccount';
import {connect} from 'react-redux';
import styles from '../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../config/env';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import axios from 'axios';

class PaypalAccountList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      accounts: props.accounts,
      account: {},
      currentSelected: null,
      isLoading: false,
      editIndex: 0,
      isModal: false,
      isEditModal: false,
    };
  }

  _handleEdit(index) {
    var account = this.state.accounts[index];
    this.setState({
      account,
      editIndex: index,
      isEditModal: true,
    });
  }

  async _deleteAccount(index) {
    this.setState({
      isLoading: true,
    });

    try {
      var id = this.state.accounts[index].id;
      let response = await axios.delete('delete/account/' + id);

      var stateaccounts = await this.state.accounts.filter(
        (account, arrayindex) => {
          return arrayindex !== index;
        },
      );

      this.setState({
        accounts: stateaccounts,
        isLoading: false,
      });

      Alert.alert('Success', 'Successfully Deleted');
    } catch (error) {
      // console.log(error)
      await Alert.alert('Opps!', 'somthing went wrong');
      this.setState({
        isLoading: false,
      });
    }
  }

  _handleDelete(index) {
    Alert.alert(
      'Are you sure?',
      'Are you sure want delete this account?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'Okay', onPress: () => this._deleteAccount(index)},
      ],
      {cancelable: false},
    );
  }

  _handleAccountAdded(account) {
    var accounts = this.state.accounts;
    accounts.unshift(account);
    this.setState({
      accounts,
      isModal: false,
    });

    Alert.alert(
      'Success',
      'Successfully created you can use this account but we first verify and confirm you that this account is created.',
    );
  }

  _handleAccountUpdated(account) {
    var accounts = this.state.accounts;
    accounts[this.state.editIndex] = account;
    this.setState({
      accounts,
      isEditModal: false,
    });

    Alert.alert('Success', 'Successfully account Updated!');
  }

  _handleSelect(accountID, index) {
    this.setState({currentSelected: index});
    this.props.onCheked(accountID);
  }

  _handleAddAccount() {
    this.setState({
      isModal: true,
      currentSelected: null,
    });
    this.props.onCheked(null);
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={[styles.card, styles.shadow]}>
          <ScrollView>
            <AddPaypalAccount
              isModal={this.state.isModal}
              onClose={() => this.setState({isModal: false})}
              onAccountAdded={account => this._handleAccountAdded(account)}
            />
            {this.state.isEditModal ? (
              <EditPaypalAccount
                account={this.state.account}
                onClose={() => this.setState({isEditModal: false})}
                onAccountUpdated={account =>
                  this._handleAccountUpdated(account)
                }
              />
            ) : null}

            {this.state.accounts.length == 0 ? (
              <Text
                style={{
                  fontSize: 14,
                  color: '#000',
                  fontFamily: 'Montserrat-semiBold',
                  marginVertical: 5,
                }}>
                No paypal account found{' '}
              </Text>
            ) : null}

            <TouchableOpacity
              style={[styles.addaccountbtn]}
              onPress={() => this._handleAddAccount()}>
              <Text
                style={{
                  color: '#fff',
                  textAlign: 'center',
                  fontSize: 15,
                  alignItems: 'center',
                  fontFamily: 'Montserrat-regular',
                }}>
                {this.state.accounts.length == 0
                  ? 'Add Account'
                  : 'Add More Account'}
              </Text>
            </TouchableOpacity>

            {this.state.accounts.length > 0 ? (
              <Text style={{fontFamily: 'Montserrat-regular'}}>
                Choose From Saved Details
              </Text>
            ) : null}

            {this.state.accounts.map((account, index) => {
              return (
                <View style={styles.addaccountlist} key={index}>
                  <View style={{width: '70%'}}>
                    <TouchableOpacity
                      style={{flexDirection: 'row'}}
                      onPress={() => this._handleSelect(account.id, index)}>
                      <Image
                        source={{
                          uri:
                            this.state.currentSelected == index
                              ? STORAGE_URL + 'mobileapp/chaked.png'
                              : STORAGE_URL + 'mobileapp/unchaked.png',
                        }}
                        resizeMode="contain"
                        style={{height: 20, width: 20, marginRight: 5}}
                      />
                      <Text
                        style={{
                          fontSize: 15,
                          fontFamily: 'Montserrat-semiBold',
                        }}>
                        {account.accountID}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    style={[styles.maindel, styles.bgred]}
                    onPress={() => this._handleDelete(index)}>
                    <MaterialIcons
                      name="delete"
                      size={16}
                      style={{color: '#fff', textAlign: 'center'}}
                    />
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.maindel, styles.bgyellow]}
                    onPress={() => this._handleEdit(index)}>
                    <FontAwesome
                      name="refresh"
                      size={16}
                      style={{color: '#fff', textAlign: 'center'}}
                    />
                  </TouchableOpacity>
                </View>
              );
            })}
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(PaypalAccountList);
