import React from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  Alert,
  StatusBar,
} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import AddBankAccount from '../AddAccount/AddBankAccount';
import EditBankAccount from '../EditAccount/EditBankAccount';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import {connect} from 'react-redux';
import styles from '../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../config/env';
import axios from 'axios';

class BanAccountkList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      accounts: props.accounts,
      currentSelected: null,
      editIndex: 0,
      isLoading: false,
      isModal: false,
      isEditModal: false,
    };
  }

  _handleEdit(index) {
    var account = this.state.accounts[index];
    this.setState({
      account,
      editIndex: index,
      isEditModal: true,
    });
  }

  async _deleteAccount(index) {
    this.setState({
      isLoading: true,
    });

    try {
      let id = this.state.accounts[index].id;
      await axios.delete('delete/account/' + id);

      let stateaccounts = await this.state.accounts.filter(
        (account, arrayindex) => {
          return arrayindex !== index;
        },
      );

      this.setState({
        accounts: stateaccounts,
        isLoading: false,
      });

      Alert.alert('Success', 'Successfully Deleted');
    } catch (error) {
      // console.log(error)
      await Alert.alert('Opps!', 'somthing went wrong');
      this.setState({
        isLoading: false,
      });
    }
  }

  _handleDelete(index) {
    Alert.alert(
      'Are you sure?',
      'Are you sure want delete this account?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'Okay', onPress: () => this._deleteAccount(index)},
      ],
      {cancelable: false},
    );
  }

  _handleAccountUpdated(account) {
    var accounts = this.state.accounts;
    accounts[this.state.editIndex] = account;
    this.setState({
      accounts,
      isEditModal: false,
    });

    Alert.alert('Success', 'Successfully account Updated!');
  }

  _handleAccountAdded(account) {
    let accounts = [...this.state.accounts];
    accounts.unshift(account);
    // this.setState({
    //     accounts,
    //     isModal: false
    // })

    this.setState(
      {
        accounts,
        isModal: false,
      },
      () => {
        setTimeout(() => {
          Alert.alert(
            'Success',
            'Successfully created you can use this account but we first verify and confirm you that this account is created.',
          );
          // this.props.onAccountAdded(response.data.data)
        }, 200);
      },
    );
  }

  _handleSelect(accountID, index) {
    this.setState({currentSelected: index});
    this.props.onCheked(accountID);
  }

  _handleAddAccount() {
    this.setState({
      isModal: true,
      currentSelected: null,
    });
    this.props.onCheked(null);
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={[styles.card, styles.shadow]}>
          {this.state.isModal ? (
            <AddBankAccount
              onClose={() => this.setState({isModal: false})}
              onAccountAdded={account => this._handleAccountAdded(account)}
            />
          ) : null}
          {this.state.isEditModal ? (
            <EditBankAccount
              account={this.state.account}
              onClose={() => this.setState({isEditModal: false})}
              onAccountUpdated={account => this._handleAccountUpdated(account)}
            />
          ) : null}

          {this.state.accounts.length == 0 ? (
            <Text
              style={{
                fontSize: 14,
                color: '#000',
                fontFamily: 'Montserrat-semiBold',
                marginVertical: 5,
              }}>
              No bank account found{' '}
            </Text>
          ) : null}

          <TouchableOpacity
            style={[styles.addaccountbtn]}
            onPress={() => this._handleAddAccount()}>
            <Text
              style={{
                color: '#fff',
                textAlign: 'center',
                fontSize: 15,
                fontFamily: 'Montserrat-regular',
                alignItems: 'center',
              }}>
              {this.state.accounts.length == 0
                ? 'Add Account'
                : 'Add More Account'}
            </Text>
          </TouchableOpacity>

          {this.state.accounts.length > 0 ? (
            <Text style={{fontFamily: 'Montserrat-regular'}}>
              Choose From Saved Details
            </Text>
          ) : null}

          {this.state.accounts.map((account, index) => {
            return (
              <View style={styles.addaccountlist} key={index}>
                <View style={{width: '70%'}}>
                  <TouchableOpacity
                    style={{flexDirection: 'row'}}
                    onPress={() => this._handleSelect(account.id, index)}>
                    <Image
                      style={styles.fitImage}
                      source={{
                        uri:
                          this.state.currentSelected == index
                            ? STORAGE_URL + 'mobileapp/chaked.png'
                            : STORAGE_URL + 'mobileapp/unchaked.png',
                      }}
                      resizeMode="contain"
                      style={{height: 20, width: 20, marginRight: 5}}
                    />
                    <Text
                      style={{fontSize: 15, fontFamily: 'Montserrat-semiBold'}}>
                      {account.ac_no}
                    </Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity
                  style={[styles.maindel, styles.bgred]}
                  onPress={() => this._handleDelete(index)}>
                  <MaterialIcons
                    name="delete"
                    size={16}
                    style={{color: '#fff', textAlign: 'center'}}
                  />
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.maindel, styles.bgyellow]}
                  onPress={() => this._handleEdit(index)}>
                  <FontAwesome
                    name="refresh"
                    size={16}
                    style={{color: '#fff', textAlign: 'center'}}
                  />
                </TouchableOpacity>
              </View>
            );
          })}
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(BanAccountkList);
