import React from 'react';
import {
  Text,
  View,
  StatusBar,
  Image,
  ScrollView,
  TouchableOpacity,
  BackHandler,
  Alert,
  RefreshControl,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import styles from '../../../../assets/css/style';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {connect} from 'react-redux';
import axios from 'axios';
import {STORAGE_URL} from '../../../config/env';
import moment from 'moment';
import {NavigationActions} from 'react-navigation';

const navigateAction = NavigationActions.navigate({
  routeName: 'MyOrdersStack',
  params: {},
  action: NavigationActions.navigate({routeName: 'MyOrders'}),
});

class AllOffers extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      isLoading: true,
      refreshing: false,
      slug: null,
      offers: [],
    };
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  formatdel(datetime) {
    return moment(datetime)
      .utcOffset('+0000')
      .format('DD/MM/YYYY');
  }

  sendat(datetime) {
    return moment(datetime)
      .utcOffset('+0000')
      .fromNow();
  }

  _pushToEditPage(order_type, isFood, slug) {
    if (order_type == 1 && !isFood) {
      this.props.navigation.navigate('EditGlobaly', {slug: slug});
      return;
    }

    if (order_type == 2 && !isFood) {
      this.props.navigation.navigate('EditDomestically', {slug: slug});
      return;
    }

    if (order_type == 3 && !isFood) {
      this.props.navigation.navigate('EditLocally', {slug: slug});
      return;
    }

    if (order_type == 2 && isFood) {
      navigate('EditFoodDomestically', {slug: slug});
      return;
    }

    if (order_type == 3 && isFood) {
      this.props.navigation.navigate('EditFoodLocally', {slug: slug});
      return;
    }
  }

  async order(slug, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
        slug,
      });
    }
    try {
      let response = await axios.get('offers_order/' + slug);
      var offers = [];
      if (response.data.data.paid) {
        offers = response.data.data.paidOffers;
      } else {
        offers = response.data.data.freshoffers;
      }
      this.setState({
        order: response.data.data,
        offers: offers,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      // if (error.request.response) {
      //     console.log(error.request.response)
      // }else{
      //     console.log(error)
      // }
      if (type) {
        this.setState({
          refreshing: false,
        });
      } else {
        Alert.alert('Oops!', 'No order data found!');
        // this.props.navigation.dispatch(navigateAction)

        this.props.navigation.navigate('MyOrders');
      }
    }
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      // this.props.navigation.navigate('MyOrders')
      // this.props.navigation.dispatch(navigateAction)
      this.props.navigation.goBack(null);

      return true;
    });

    const slug = this.props.navigation.getParam('slug');
    this.order(slug);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      // this.props.navigation.navigate('MyOrders')
      // this.props.navigation.dispatch(navigateAction)
      return true;
    });
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var order = this.state.order;
      return (
        <View style={styles.containerbox}>
          <StatusBar backgroundColor="#660165" barStyle="light-content" />
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={this.state.refreshing}
                onRefresh={() => this.order(this.state.slug, 1)}
                style={{backgroundColor: 'transparent'}}
              />
            }>
            <View style={[styles.card, styles.shadow]}>
              <Text style={styles.prodectname}>{order.name_item}</Text>
              <Text style={styles.allparegraph}>{order.description}</Text>
              <Image
                style={styles.fitImage}
                source={{
                  uri: order.images[0],
                }}
                resizeMode="contain"
                style={{height: 200}}
              />
              <View style={styles.imagegrid}>
                {order.images.map(function(image, index) {
                  return (
                    <View style={styles.gridfitImage} key={index}>
                      <Image
                        source={{
                          uri: image,
                        }}
                        resizeMode="contain"
                        style={{height: 100, width: 100}}
                      />
                    </View>
                  );
                })}
              </View>
            </View>

            <View style={[styles.card, styles.shadow]}>
              <View style={styles.box}>
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>From</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {order.delivery_from_no_limit}
                  </Text>
                </View>
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>To</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {order.delivery_to_no_limit}
                  </Text>
                </View>
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Item Price</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {this.props.currency} {order.price_item}
                  </Text>
                </View>
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Quantity</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {order.quantity}
                  </Text>
                </View>
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>
                    {order.isPaylater
                      ? 'Traveller Fee'
                      : 'Traveller & Service Fee'}
                  </Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {this.props.currency}{' '}
                    {order.isPaylater
                      ? order.traveller_fee
                      : order.ser_trav_fee}
                  </Text>
                </View>
                {order.isPaylater ? null : (
                  <View style={[styles.profilepricefinal, styles.borderBottom]}>
                    <Text style={styles.priceall}>Tax</Text>
                    <Text style={[styles.priceall, styles.colorpurple]}>
                      {this.props.currency} {order.taxes}
                    </Text>
                  </View>
                )}
                <View style={[styles.profilepricefinal, styles.borderBottom]}>
                  <Text style={styles.priceall}>Total Amount</Text>
                  <Text style={[styles.priceall, styles.colorpurple]}>
                    {this.props.currency}{' '}
                    {order.isPaylater ? order.subTotal : order.total_price}
                  </Text>
                </View>
              </View>
            </View>

            <View style={[styles.card, styles.shadow, styles.order_expired]}>
              <View>
                <Text style={{fontSize: 16, fontFamily: 'Montserrat-semiBold'}}>
                  {order.isExpired
                    ? 'Order Expired'
                    : this.state.offers.length > 0
                    ? 'Delivery Offers'
                    : ''}
                </Text>
              </View>

              {order.isExpired ? (
                <View style={styles.acceptpaybtngroup}>
                  <TouchableOpacity
                    style={[styles.accepybtn, styles.bgyellow]}
                    onPress={() =>
                      this._pushToEditPage(
                        order.order_type,
                        order.isFood,
                        order.slug,
                      )
                    }>
                    <Text
                      style={{color: '#fff', fontFamily: 'Montserrat-Regular'}}>
                      Edit & Reactivate
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : null}
            </View>

            {this.state.offers.map((offer, index) => {
              if (order.isExpired) {
                return null;
              }

              return (
                <View style={[styles.card, styles.shadow]} key={index}>
                  <View style={styles.deliveryofferuser}>
                    <View style={styles.deliveryimdbox}>
                      <Image
                        source={{
                          uri: offer.avatar
                            ? offer.avatar
                            : STORAGE_URL +
                              'static/assets/images/profile-up-img.png',
                        }}
                        style={styles.sm_user_fit}
                      />
                      <View style={{marginLeft: 10}}>
                        <Text
                          style={{
                            fontSize: 16,
                            color: '#660165',
                            fontFamily: 'Montserrat-semiBold',
                          }}
                          onPress={() =>
                            this.props.navigation.navigate('UserProfile', {
                              userName: offer.username,
                            })
                          }>
                          {offer.offer_by}{' '}
                        </Text>
                        <Text
                          style={{
                            fontSize: 12,
                            fontFamily: 'Montserrat-Regular',
                          }}>
                          {this.sendat(offer.created_at)}
                        </Text>
                      </View>
                    </View>
                    <Text style={styles.bigprice}>
                      {this.props.currency} {offer.total}
                    </Text>
                  </View>
                  <View style={styles.deliveryofferuser}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: 110,
                      }}>
                      <FontAwesome
                        name={offer.userRating >= 1 ? 'star' : 'star-o'}
                        size={18}
                        style={{color: '#660165', marginRight: 5}}
                      />
                      <FontAwesome
                        name={offer.userRating >= 2 ? 'star' : 'star-o'}
                        size={18}
                        style={{color: '#660165', marginRight: 5}}
                      />
                      <FontAwesome
                        name={offer.userRating >= 3 ? 'star' : 'star-o'}
                        size={18}
                        style={{color: '#660165', marginRight: 5}}
                      />
                      <FontAwesome
                        name={offer.userRating >= 4 ? 'star' : 'star-o'}
                        size={18}
                        style={{color: '#660165', marginRight: 5}}
                      />
                      <FontAwesome
                        name={offer.userRating >= 5 ? 'star' : 'star-o'}
                        size={18}
                        style={{color: '#660165'}}
                      />
                      <Text>({offer.ratesBy})</Text>
                    </View>
                    <TouchableOpacity
                      onPress={() => (offer.ishowBreak = !offer.ishowBreak)}>
                      <Text
                        style={{
                          color: '#336699',
                          fontFamily: 'Montserrat-regular',
                        }}>
                        Total Price Breakdown{' '}
                        <Entypo
                          name={
                            offer.ishowBreak ? 'chevron-down' : 'chevron-up'
                          }
                          size={18}
                        />
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {offer.ishowBreak ? (
                    <View style={{backgroundColor: '#fafafa', padding: 10}}>
                      <View
                        style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Item Price</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>
                          {this.props.currency} {order.price_item}
                        </Text>
                      </View>

                      <View
                        style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Quantity</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>
                          {order.quantity}
                        </Text>
                      </View>

                      <View
                        style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>
                          {order.isPaylater
                            ? 'Traveller Fee'
                            : 'Traveller & Service Fee'}
                        </Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>
                          {this.props.currency}{' '}
                          {order.isPaylater
                            ? offer.delivery_fee
                            : offer.ser_trav_fee}
                        </Text>
                      </View>

                      {order.isPaylater ? null : (
                        <View
                          style={[
                            styles.profilepricefinal,
                            styles.borderBottom,
                          ]}>
                          <Text style={styles.priceall}>Tax</Text>
                          <Text style={[styles.priceall, styles.colorpurple]}>
                            {this.props.currency} {offer.taxes}
                          </Text>
                        </View>
                      )}

                      <View
                        style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Total Fee</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>
                          {this.props.currency}{' '}
                          {order.isPaylater ? offer.itemSubtotal : offer.total}
                        </Text>
                      </View>
                    </View>
                  ) : null}

                  <View style={{flexDirection: 'row'}}>
                    <Text
                      style={{fontSize: 18, fontFamily: 'Montserrat-semiBold'}}>
                      Delivery From{' '}
                    </Text>
                    <Text
                      style={{
                        fontSize: 18,
                        fontFamily: 'Montserrat-semiBold',
                        color: '#660165',
                      }}>
                      {offer.travel_from}
                    </Text>
                  </View>
                  <View style={{flexDirection: 'row'}}>
                    <Text
                      style={{fontSize: 18, fontFamily: 'Montserrat-semiBold'}}>
                      On{' '}
                    </Text>
                    <Text
                      style={{
                        fontSize: 18,
                        fontFamily: 'Montserrat-semiBold',
                        color: '#660165',
                      }}>
                      {this.formatdel(offer.delivery_date)}
                    </Text>
                  </View>
                  <View style={styles.acceptpaybtngroup}>
                    {order.isPaylater ? (
                      <TouchableOpacity
                        style={styles.accepybtn}
                        onPress={() =>
                          this.props.navigation.navigate('OrderConfirm', {
                            slug: order.slug,
                            offerId: offer.id,
                          })
                        }>
                        <Text
                          style={{
                            color: '#fff',
                            fontFamily: 'Montserrat-regular',
                          }}>
                          Mark Delivered
                        </Text>
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity
                        style={styles.accepybtn}
                        onPress={() =>
                          order.paid
                            ? this.props.navigation.navigate('OrderConfirm', {
                                slug: order.slug,
                              })
                            : this.props.navigation.navigate('CheckOut', {
                                slug: order.slug,
                                offerId: offer.id,
                              })
                        }>
                        <Text
                          style={{
                            color: '#fff',
                            fontFamily: 'Montserrat-regular',
                          }}>
                          {order.paid ? 'Paid' : 'Accept & Pay'}
                        </Text>
                      </TouchableOpacity>
                    )}

                    <TouchableOpacity
                      style={[styles.accepybtn, styles.bgpurple]}
                      onPress={() =>
                        this.props.navigation.navigate('Chat', {
                          slug: order.slug,
                          chatID: offer.chatRoomIdOfferId,
                        })
                      }>
                      <Text
                        style={{
                          color: '#fff',
                          fontFamily: 'Montserrat-regular',
                        }}>
                        Send Message
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })}
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(AllOffers);
