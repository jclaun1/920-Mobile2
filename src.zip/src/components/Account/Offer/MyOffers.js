import React from 'react'
import {  Text, View, Image, ScrollView, TouchableOpacity, Dimensions, BackHandler, RefreshControl } from 'react-native'
import Entypo  from 'react-native-vector-icons/Entypo'
import styles from '../../../../assets/css/style'
import OrderSubmitting from '../../Common/OrderSubmitting'
import Carousel from 'react-native-snap-carousel'
import NewHeader from '../../Menu/NewHeader'
import {connect}  from 'react-redux'
import axios from 'axios'
import Steps from '../../Common/Steps';

class MyOffers extends React.Component {

    constructor(props){
        super(props)
        this.state = {
            offers: [],
            isLoading: false,
            refreshing:false,
            activeSlide: 0,
            viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height
            }
        }
        this._componentWillLoad()
    }

    static navigationOptions = ({ navigation }) => {
        return {
            header: <NewHeader isHome={false} title="My Offers" navigate={navigation}/>
        }
    }

    async myoffers (type) {
        if (type) {
            this.setState({
                refreshing:true
            })
        }else{
            this.setState({
                isLoading: true
            })
        }
        try {
            let response = await axios.get('/my/offers')

            this.setState({
                offers: response.data.data,
                isLoading: false,
                refreshing:false
            })

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false,
                refreshing:false
            })
        }
    }

    _componentWillLoad () {
        // this.myoffers(0)
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
        this.myoffers(0)
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    _renderItem = (item, index) => {
        var offer = item.item
        const { navigate } = this.props.navigation;
        return (
            <View style={[styles.orderitemcard, styles.shadow]}>
                <View style={{ marginBottom: 10, }}>
                    <TouchableOpacity onPress={() => navigate('OrderPost', {slug:offer.slug})}>
                        <Text style={{ color: '#660165', fontSize: 16,fontFamily:'Montserrat-semiBold',  }}>{offer.name_item}</Text>
                    </TouchableOpacity>
                </View>

                <Image style={styles.fitImage}
                    source={{ uri: offer.images[0] }}

                    style={{ resizeMode: 'contain', height: 200, }}
                />
                <View style={styles.adressbox}>
                    <View style={styles.addresslistbox}>
                        <View style={{width:95,}}>
                            <Text style={styles.addresstitel}>Delivery To </Text>
                        </View>
                        <View style={{flex:3}}>
                            <Text style={[styles.addresstitel, styles.colorpurple]}>{offer.delivery_to} </Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <View style={{width:115,}}>
                            <Text style={styles.addresstitel}>Delivery From </Text>
                        </View>
                        <View style={{flex:3}}>
                            <Text style={[styles.addresstitel, styles.colorpurple]}>{offer.delivery_from} </Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <Text style={styles.addresstitel}>Before </Text>
                        <Text style={[styles.addresstitel, styles.colorpurple]}>{offer.delivery_date}</Text>
                    </View>
                </View>
                <View style={styles.pricebox}>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Offer Price</Text>
                        <Text style={[styles.pricetitel]}>{this.props.currency} {offer.offer_fee}</Text>
                    </View>
                    <View style={[styles.pricemain, styles.borderRightleft]}>
                        <Text style={styles.pricetitel}>Status</Text>
                        <Text style={[styles.pricetitel]}>
                            {offer.isReacted ? offer.isAccepted ? 'Accepeted' : 'Rejected' : 'No Action' }
                        </Text>
                    </View>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Made On</Text>
                        <Text style={[styles.pricetitel]}>{offer.made_on}</Text>
                    </View>
                </View>

                <TouchableOpacity>
                    <Text style={{ color: '#336699',textAlign:'right',fontFamily:'Montserrat-Regular',  }}>
                        Total Price Breakdown <Entypo name={offer.isBreakDown ? 'chevron-down' : 'chevron-up'} size={18} />
                    </Text>
                </TouchableOpacity>

                <View style={{ backgroundColor: '#fff', padding: 10,marginVertical:5, }}>
                    <View style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Item Price</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>{this.props.currency} {offer.price_item}</Text>
                    </View>

                    <View style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Quantity</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>{offer.quantity}</Text>
                    </View>

                    <View style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Traveller Fee</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>{this.props.currency} {offer.offer_fee}</Text>
                    </View>

                    <View style={[styles.profilepricefinal, styles.borderBottom]}>
                        <Text style={styles.priceall}>Total Amount</Text>
                        <Text style={[styles.priceall, styles.colorpurple]}>{this.props.currency} {offer.totalOfferFee}</Text>
                    </View>

                </View>

            </View>
        )
    }

    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting/>
            )
        } else {
            if (this.state.offers.length == 0) {
                return (
                    <View style={styles.fromgroup}>
                        <Text style={{textAlign:'center',
                        fontSize:18,color:'black',marginLeft:10,
                        fontFamily:'Montserrat-Regular', }}>
                            No offer
                        </Text>
                    </View>
                )
            }
            return (
                <View style={styles.containerbox}
                    onLayout={() => {
                        this.setState({
                            viewport: {
                                width: Dimensions.get('window').width,
                                height: Dimensions.get('window').height
                            }
                        });
                    }}>
                    <View style={{paddingVertical:10,}}>
                        
                    </View>
                    <ScrollView
                        refreshControl={
                        <RefreshControl
                        refreshing={this.state.refreshing}
                        onRefresh={() => this.myoffers( 1)}
                        style={{backgroundColor: 'transparent'}}
                        />}>
                        <Carousel
                            ref={(c) => { this._carousel = c; }}
                            data={this.state.offers}
                            renderItem={this._renderItem}
                            sliderWidth={this.state.viewport.width}
                            itemWidth={this.state.viewport.width}
                            onSnapToItem={(index) => this.setState({ activeSlide: index }) }
                        />
                    </ScrollView>
                </View>
            )
        }
    }
}

const mapStateToProps = state => {
    return {
      currency: state.auth.currency,
      user: state.auth.user
    }
}

export default connect(mapStateToProps, null)(MyOffers)
