import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  RefreshControl,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../assets/css/style';
import {onUserRequest} from '../../redux/actions/authAction';
import {connect} from 'react-redux';
import {STORAGE_URL} from '../../config/env';
import NewHeader from '../Menu/NewHeader';
import moment from 'moment';
import axios from 'axios';

class Notifacations extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
    };
  }

  static navigationOptions = ({navigation}) => {
    return {
      title: 'Notifications',
      header: (
        <NewHeader type="1" title="Notifications" navigate={navigation} />
      ),
    };
  };

  async _marked_as_read(id, index, readat) {
    if (readat) {
      return;
    }
    try {
      let response = await axios.get('mark/as_read/offer/' + id);
      this.props.dispatch({
        type: 'NOTIFICATION_READ',
        payload: index,
      });
      this.props.dispatch({
        type: 'NOTIFICATION_INC_DEC',
        payload: 0,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _marked_as_read_all(notifications) {
    notifications.forEach((element, key) => {
      if (!element.read_at) {
        this._marked_as_read(element.id, key, element.read_at);
      }
    });
  }

  _pushTo(type, data) {
    if (type == 1) {
      this.props.navigation.push('AllOffers', {slug: data.order_slug});
    }

    if (type == 2 || type == 3) {
      this.props.navigation.push('Chat', {
        slug: data.order_slug,
        chatID: data.chatRoomId,
      });
    }

    if (type == 4) {
      this.props.navigation.push('OrderPost', {slug: data.order_slug});
    }

    if (type == 5 || type == 6) {
      this.props.navigation.push('ConfirmOrderTraveller', {
        slug: data.order_slug,
      });
    }

    if (type == 7) {
      this.props.navigation.push('BalanceAndWithdrwal');
    }

    if (type == 8) {
      this.props.navigation.push('OrderConfirm', {slug: data.order_slug});
    }

    if (type == 9) {
      if (data.tripId) {
        this.props.navigation.push('DeliveryOrders', {
          tripId: data.tripId,
          notify: 'notify',
        });
      } else {
        this.props.navigation.push('OrderPost', {slug: data.order_slug});
      }
    }
  }

  _onPressAction(notification, index) {
    this._pushTo(notification.data.notification_type, notification.data);
    this._marked_as_read(notification.id, index, notification.read_at);
  }

  async _onPullRequest() {
    this.setState({refreshing: true});
    try {
      var token = await AsyncStorage.getItem('token');
      await this.props.onUserRequest(token);
      this.setState({refreshing: false});
    } catch (error) {
      this.setState({refreshing: false});
    }
  }

  render() {
    var notifications = this.props.notifications;
    return (
      <View style={styles.container}>
        <View
          style={{
            flexDirection: 'column',
            alignItems: 'center',
            width: '100%',
            paddingHorizontal: 20,
            backgroundColor: '#fff',
            borderBottomWidth: 1,
            borderColor: '#ccc',
            paddingVertical: 10,
          }}>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              onPress={() => this._marked_as_read_all(notifications)}>
              <Text
                style={{
                  fontSize: 14,
                  color: '#660165',
                  fontFamily: 'Montserrat-semiBold',
                  borderBottomWidth: 0.5,
                  borderColor: '#660165',
                }}>
                Mark all as read
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView
          style={{maxHeight: '100%'}}
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={() => this._onPullRequest()}
              style={{backgroundColor: 'transparent'}}
            />
          }>
          {notifications.map((notification, index) => {
            return (
              <View
                key={index}
                style={[
                  !notification.read_at ? styles.msgnotifactactive : null,
                ]}>
                <TouchableOpacity
                  style={[
                    styles.massagerownotification,
                    !notification.read_at ? styles.msgnotifactactive : null,
                  ]}
                  onPress={() => this._onPressAction(notification, index)}>
                  <Image
                    style={styles.fitImage}
                    source={{
                      uri:
                        STORAGE_URL + 'static/assets/images/profile-up-img.png',
                    }}
                    style={{height: 50, width: 50, borderRadius: 25}}
                  />
                  <View style={styles.notifacationtextmain}>
                    <Text
                      style={{
                        fontSize: 13,
                        color: '#000',
                        fontFamily: 'Montserrat-Regular',
                      }}>
                      {notification.data.message}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        color: '#ccc',
                        fontFamily: 'Montserrat-Regular',
                      }}>
                      {notification.data.created_at.date
                        ? moment(notification.data.created_at.date).fromNow()
                        : moment(notification.data.created_at).fromNow()}
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            );
          })}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    inboxCount: state.auth.inbox_count,
    notificationCount: state.auth.notification_count,
    notifications: state.auth.notifications,
  };
};

export default connect(
  mapStateToProps,
  {onUserRequest},
)(Notifacations);
