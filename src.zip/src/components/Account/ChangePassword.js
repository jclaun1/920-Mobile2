import React from 'react'
import { Text, View, TextInput, ScrollView, TouchableOpacity, Alert, BackHandler } from 'react-native'
import OrderSubmitting from '../Common/OrderSubmitting'
import styles from '../../../assets/css/style'
import NewHeader from '../Menu/NewHeader'
import { connect } from 'react-redux'
import axios from 'axios'
import FlyButton from '../Common/FlyButton';

class ChangePassword extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            current_pass: '',
            new_pass: '',
            confirm_new_pass: '',
            isCurrentPass: props.user.isCurrentPass,
            isLoading: false
        }
    }

    static navigationOptions = ({ navigation }) => {
        return {
          header: <NewHeader password="1" isHome={false} navigate={navigation}/>
        }
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }
    
    isValid(data) {
        var isValidData = true
        for (let i = 0; i < Object.keys(data).length; i++) {
          if (!data[Object.keys(data)[i]]) {
            this[Object.keys(data)[i]].focus()
            isValidData = false
            break
          }
        }
        return isValidData
    }

    async _handleSubmit() {

        let validateData = {}
        if (this.state.isCurrentPass) {
            validateData = {
                current_pass: this.state.current_pass,
                new_pass: this.state.new_pass,
                confirm_new_pass: this.state.confirm_new_pass
            }
        } else {
            validateData = {
                new_pass: this.state.new_pass,
                confirm_new_pass: this.state.confirm_new_pass
            }
        }
        
        if (!this.isValid(validateData)) {
            return false
        }

        this.setState({
            isLoading: true
        })

        try {
            var data = {
                password: this.state.new_pass,
                password_confirmation: this.state.confirm_new_pass,
                current_password: this.state.current_pass
            }

            await axios.post('update/password', data)

            var user = this.props.user
            user.isCurrentPass = true
            await this.props.dispatch({
                type: 'USER_SUCCESS',
                payload: user
            })

            isNew = this.state.isCurrentPass

            await this.setState({
                new_pass: '',
                confirm_new_pass:'',
                current_pass: '',
                isCurrentPass: true,
                isLoading: false
            })

            Alert.alert('Success', `Successfully Password ${isNew ? 'changed': 'created'}!`)

        } catch (error) {

            let resposneError = JSON.parse(error.request.response)
            var message = ''
            if (resposneError.errors) {
                var errors = resposneError.errors
                message = errors[Object.keys(errors)[0]][0]
            } else {
                message = resposneError.message
            }

            this.setState({
                isLoading: false
            })

            Alert.alert('Opps!', message)
        }
    }

    render() {
        if (this.state.isLoading) {
            return (
              <OrderSubmitting/>
            )
        } else {

            var old_pass = null
            if (this.state.isCurrentPass) {
                old_pass = <View style={styles.changepasswordfromgroup}>
                        <TextInput style={styles.changePasswordInputbox}
                            secureTextEntry={true}
                            placeholder="Current Password"
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            value={this.state.current_pass}
                            ref={input => { this.current_pass = input}}
                            onChangeText={(current_pass) => this.setState({current_pass})}
                        />
                    </View>
            }
            return (
                <View style={styles.container}>
                    <ScrollView style={{width:'100%',}}>
                        <View style={[styles.card, styles.shadow,styles.change_pass_container]}>
                        {/* <Text style={styles.profilemenuheading}>{this.state.isCurrentPass ? 'Change password' : 'New password'}</Text> */}

                        {old_pass}

                        <View style={styles.changepasswordfromgroup}>
                            <TextInput style={styles.changePasswordInputbox}
                                secureTextEntry={true}
                                placeholder="New Password"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                value={this.state.new_pass}
                                ref={input => { this.new_pass = input}}
                                onChangeText={(new_pass) => this.setState({new_pass})}
                            />
                        </View>

                        <View style={styles.changepasswordfromgroup}>
                            <TextInput style={styles.changePasswordInputbox}
                                secureTextEntry={true}
                                placeholder="Confirm New Password"
                                placeholderTextColor="#878787"
                                underlineColorAndroid='rgba(0, 0, 0,0)'
                                value={this.state.confirm_new_pass}
                                ref={input => { this.confirm_new_pass = input}}
                                onChangeText={(confirm_new_pass) => this.setState({confirm_new_pass})}
                            />
                        </View>

                        <View style={[styles.changepasswordfromgroup,{padding:10}]}>

                        <FlyButton color='#4A0B49' title='Update Password' onPress={() => this._handleSubmit()}/>
  
                        </View>

                    </View>
                    </ScrollView>
                </View>
            )
        }
    }
}

const mapStateToProps = state => {
    return {
        user: state.auth.user
    }
}

export default connect(mapStateToProps, null)(ChangePassword)
