import React from 'react'
import { Dimensions } from 'react-native'
import { createMaterialTopTabNavigator, createAppContainer} from 'react-navigation'
import OrderSubmitting from '../Common/OrderSubmitting'
import {connect}  from 'react-redux'
import axios from 'axios'
import NewHeader from '../Menu/NewHeader'
import Balance from './PartialBalanceWithDrawl/Balance'
import Withdrawal from './PartialBalanceWithDrawl/Withdrawal'

const fontsizerwidth = Dimensions.get('window').width

const fontSizer = (screenWidth) => {
    if(screenWidth > 400){
      return 12;
    }else if(screenWidth > 360){
      return 11;
    }
    else if(screenWidth > 250){
        return 10;
      }else { 
      return 9;
    }
}

class BalanceAndWithdrwal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      wallets: [],
			balance: 0.0,
			withdraws: [],
			exchangeRate: 0,
      isLoading: true
    }

    this.walletsData()
  }

  static navigationOptions = ({ navigation }) => {
    return {
      header: <NewHeader isHome={false} title="Balance & Withdrawal"  navigate={navigation}/>
    }
  }

  async walletsData() {
    try {
      let response = await axios.get('my/wallet')
      this.setState({
        wallets: response.data[0],
        withdraws: response.data[1],
        balance: response.data[2],
        exchangeRate: response.data[3],
        isLoading: false
      })

      this.setState({
        isLoading: false
      })

    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        refreshing:false
      })
    }
  }

  render() {

    if (this.state.isLoading) {
      return (
        <OrderSubmitting/>
      )
    } else {
      return (
        <Tabs screenProps={{push: this.props.navigation.push, 
          wallets: this.state.wallets, 
          withdraws: this.state.withdraws, 
          exchangeRate:this.state.exchangeRate,
          balance:this.state.balance}}/>
      )
    }
  }
}




const Tabs =  createAppContainer(createMaterialTopTabNavigator(
  {
      Balance: {
          screen: Balance,
          navigationOptions:{
            tabBarLabel:'Balance'
          }
      },

      WithdrawalBalance: {
          screen: Withdrawal,
          navigationOptions:{
              tabBarLabel:'Withdrawal'
          }
      }
  },{
      tabBarOptions: {
          style: {
              backgroundColor: '#660165',
              marginBottom:30,
          },
          labelStyle: {
              fontSize: fontSizer(fontsizerwidth),
              fontFamily:'Montserrat-Bold',
              // fontWeight:"800",
              // borderBottomColor:'#fff'
          },
          activeTintColor: '#ffff',
          inactiveTintColor: 'gray',
          indicatorStyle:{
              borderBottomColor: '#ffffff',
              borderBottomWidth: 4,

          },
      }
  }
))

export default connect(null, null)(BalanceAndWithdrwal)
