import React from 'react'
import {Text, View, TextInput,ScrollView, TouchableOpacity, Modal, Alert, StatusBar } from 'react-native'
import AsyncStorage from '@react-native-community/async-storage'
import styles from '../../../assets/css/style'
import {connect}  from 'react-redux'
import axios from 'axios'
import moment from 'moment'

class ConfirmPhone extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            phone: props.phone,
            otp: '',
            isLoading: false,
            visible: false
        }
    }

    async _resendotp() {

        if (this.state.isLoading) {
            return
        }

        let otpsession = await AsyncStorage.getItem('otp_session')
        let otpsendat  = await AsyncStorage.getItem('otp_send_at')
        if (otpsession) {
            if (moment().diff(moment(JSON.parse(otpsendat)).utc(), 'seconds') < 30) {
                Alert.alert('Oops!', "Code can be resent only once per 30 seconds")
                return
            }
        }

        this.props.onResend()
    }

    async matching_otp() {
        
        let otpsession = await AsyncStorage.getItem('otp_session')
        let otpsendat  = await AsyncStorage.getItem('otp_send_at')

        if (!this.state.otp || !otpsession || !otpsendat || this.state.isLoading) {
            return
        }

        this.setState({
            isLoading: true
        })

        try {
            const data = {
                otp: this.state.otp,
                sessionid: otpsession
            }
            await axios.post('confirm/otp', data)
            await AsyncStorage.setItem('otp_session', '')
            this.setState({
                isLoading: false
            })
            this.props.onSuccess()
        } catch (error) {
            this.setState({
                otp: '',
                isLoading: false
            })
            Alert.alert('Oops!', "The OTP entered is incorrect. Please enter correct OTP")
        }
    }

    _handleClose() {
        if (this.state.isLoading) {
            return
        }
        this.props.onClose(false)
    }

    render() {

        return (
            <Modal animationType="slide"
                transparent={false}
                visible={true}
                onRequestClose={() => {
                alert('Modal has been closed.');
                }}>
                <ScrollView>
                    <View style={styles.container}>
                        <StatusBar hidden={true} />
                        <View style={[styles.card, styles.shadow,styles.change_pass_container]}>
                            <Text style={styles.allheading}>Enter your 6-digit verification code</Text>

                            <View style={styles.changepasswordfromgroup}>
                                <TextInput style={styles.inputbox}
                                    placeholderTextColor="#878787"
                                    underlineColorAndroid='rgba(0, 0, 0,0)'
                                    placeholder="0000"
                                    value={this.state.otp}
                                    onChangeText={(otp) => this.setState({otp})}
                                />
                            </View>

                            <View style={{width:'100%',marginVertical:10}}>
                                <Text style={{textAlign:'center',fontSize:16,fontWeight:'600'}}>Sent to {this.props.phone}</Text>
                            </View>

                            <View style={{width:'100%',marginVertical:10,flexDirection:"row",justifyContent:'space-between'}}>
                                <TouchableOpacity onPress={() => this._resendotp()}>
                                    <Text style={{textAlign:'center',fontSize:16,fontWeight:'600',color:'#051aef'}}>Resend  Code</Text>
                                </TouchableOpacity>

                                <TouchableOpacity  onPress={() => this._handleClose()}>
                                    <Text style={{textAlign:'center',fontSize:16,fontWeight:'600',color:'#051aef'}}>Change Phone Number</Text>
                                </TouchableOpacity>
                            </View>


                            <View style={styles.changepasswordfromgroup}>
                                <TouchableOpacity onPress={() => this.matching_otp()}>
                                    <Text style={styles.Searchbtn}>{this.state.isLoading ? 'Verifying...' : 'Verify Phone Number'}</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={styles.changepasswordfromgroup}>
                                <TouchableOpacity onPress={() => this._handleClose()}>
                                    <Text style={styles.Searchbtn}>Cancel</Text>
                                </TouchableOpacity>
                            </View>

                        </View>
                    </View>
                </ScrollView>
            </Modal>
        )

    }
}


export default connect(null, null)(ConfirmPhone)
