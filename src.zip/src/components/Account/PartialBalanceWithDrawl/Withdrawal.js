import React from 'react'
import { Text, View, ScrollView, RefreshControl } from 'react-native'
import Entypo from 'react-native-vector-icons/Entypo'
import styles from '../../../../assets/css/style'
import {connect}  from 'react-redux'
import axios from 'axios'

class Withdrawal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
        balance: props.screenProps.balance,
        withdraws:props.screenProps.withdraws,
        exchangeRate: props.screenProps.exchangeRate,
        refreshing:false
    }
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
}
  async walletsData() {

    this.setState({
        refreshing:true,
    })
   
    try {
      let response = await axios.get('my/wallet')
      this.setState({
        withdraws: response.data[1],
        balance: response.data[2],
        exchangeRate: response.data[3],
        refreshing:false
      })

    } catch (error) {
      // console.log(error)
      this.setState({
        refreshing:false
      })
    }
  }


  _withdraw_statement_element() {

      return <View>
        <View style={styles.paymentsaction}>
        <View style={[styles.payment_price40,]}>
          <Text style={[ styles.fontbold]}>Amount</Text>
        </View>
          <View style={[styles.payment_des30,]}>
            <Text style={[styles.fontbold,styles.textAlign_center]}>status</Text>
          </View>
          <View style={[styles.payment_des30,]}>
            <Text style={[styles.fontbold,styles.textAlign_center]}>On</Text>
          </View>
        </View>

        {
          this.state.withdraws.map((withdraw, index) => {
            return (
              <View style={styles.paymentsaction} key={index}>
                <View style={[styles.payment_price40,]}>
                  <Text style={[styles.linkcolor,styles.fontFamilyregular]}>{this.props.user.currency} {withdraw.point}	</Text>
                </View>
                <View style={[styles.payment_des30,]}>
                    <Text style={[styles.typecolorcreadit,styles.textAlign_center,styles.fontFamilyregular]}>{withdraw.status}</Text>
                </View>
                <View style={[styles.payment_des30]}>
                    <Text style={[styles.textAlign_center,styles.fontFamilyregular]}>{withdraw.at}</Text>
                </View>
              </View>
            )
          })
        }
      </View>
    
  }

  render() {
    
      
      return (
        <ScrollView 
          refreshControl={
          <RefreshControl
          refreshing={this.state.refreshing}
          onRefresh={() => this.walletsData(1)}
          style={{backgroundColor: 'transparent'}}
          />}>
          <View style={styles.container}>
            <View style={[styles.card, styles.shadow]}>
              <View style={styles.wallets}>
                <View style={styles.walletbalance}>
                  <Text style={{ fontSize: 22, fontFamily:'Montserrat-semiBold', color: '#660165', }}>
                    <Entypo name="wallet" size={30} style={{ color: '#660165', }} />  {this.props.user.currency} {this.state.balance}
                  </Text>
                </View>
                <View style={styles.walletbalance}></View>
              </View>

              {this._withdraw_statement_element()}

            </View>
          </View>
        </ScrollView>
      )
    
  }
}



const mapStateToProps = state => {
  return {
    user: state.auth.user
  }
}

export default connect(mapStateToProps, null)(Withdrawal)
