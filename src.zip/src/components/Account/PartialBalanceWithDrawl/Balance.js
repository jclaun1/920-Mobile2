import React from 'react'
import { Text, View, TouchableOpacity, ScrollView, RefreshControl } from 'react-native'
import Entypo from 'react-native-vector-icons/Entypo'
import styles from '../../../../assets/css/style'
import {connect}  from 'react-redux'
import axios from 'axios'

class Balance extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
        wallets: props.screenProps.wallets,
        balance: props.screenProps.balance,
        withdraws:props.screenProps.withdraws,
        exchangeRate: props.screenProps.exchangeRate,
        refreshing:false
    }
  }

 

  async walletsData(type) {
      this.setState({
        refreshing:true,
      })
    try {
      let response = await axios.get('my/wallet')
      this.setState({
        wallets: response.data[0],
        balance: response.data[2],
        exchangeRate: response.data[3],
        refreshing: false
      })

    } catch (error) {
      // console.log(error)
      this.setState({
        refreshing:false
      })
    }
  }


  _withdraw_statement_element() {
      return <View>

        <View style={styles.paymentsaction}>
          <View style={[styles.payment_price40,]}>
            <Text style={[styles.fontbold,styles.paymet_text]}>Amount</Text>
          </View>
          <View style={[styles.payment_des30,]}>
            <Text style={[styles.fontbold,styles.paymet_text]}>Type</Text>
          </View>
          <View style={[styles.payment_des30,]}>
            <Text style={[styles.fontbold,styles.paymet_text,styles.textAlign_center]}>status</Text>
          </View>
        </View>

        {
          this.state.wallets.map((wallet, index) => {
            var statustype

            if (!wallet.isAppllied && wallet.is_Credit) {

              statustype = <View style={[styles.payment_des30,]}> 
                <TouchableOpacity style={[styles.widrowbtn]} onPress={() => this.props.screenProps.push('Withdrawal', {payId: wallet.payID})}>
                    <Text style={{ color: '#fff', textAlign: 'center', alignItems: 'center' ,fontFamily:'Montserrat-regular'}}>Withdraw</Text>
                </TouchableOpacity>
                </View>
            }else{
              statustype = <View style={[styles.payment_des30,]}>
                        <Text style={{ color: '#000', textAlign: 'center', alignItems: 'center',fontFamily:'Montserrat-regular' }}>
                              {wallet.withdrawStatus ? wallet.withdrawStatus : '...'}
                        </Text>
                  </View>
            }


            return (
              <View style={styles.paymentsaction} key={index}>
                <View style={[styles.payment_price40,]}>
                    <Text style={[styles.linkcolor]}>{this.props.user.currency} {wallet.point}	</Text>
                </View>
                <View style={[styles.payment_des30,]}>
                    <Text style={[styles.typecolorcreadit]}>{wallet.type}</Text>
                </View>
                  {statustype}
              </View>
            )
          })
        }
      </View>
    
  }

  render() { 
      return (
        <ScrollView 
          refreshControl={
          <RefreshControl
          refreshing={this.state.refreshing}
          onRefresh={() => this.walletsData(1)}
          style={{backgroundColor: 'transparent'}}
          />}>
          <View style={styles.container}>
            <View style={[styles.card, styles.shadow]}>
              <View style={styles.wallets}>
                <View style={styles.walletbalance}>
                  <Text style={{ fontSize: 22, fontFamily:'Montserrat-semiBold', color: '#660165', }}>
                    <Entypo name="wallet" size={30} style={{ color: '#660165', }} />  {this.props.user.currency} {this.state.balance}
                  </Text>
                </View>
                <View style={styles.walletbalance}></View>
              </View>

              {this._withdraw_statement_element()}

            </View>
          </View>
        </ScrollView>
      )
    
  }
}



const mapStateToProps = state => {
  return {
    user: state.auth.user
  }
}

export default connect(mapStateToProps, null)(Balance)
