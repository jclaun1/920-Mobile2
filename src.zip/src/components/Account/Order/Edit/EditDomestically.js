import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  StatusBar,
  TouchableOpacity,
  TextInput,
  Alert,
  BackHandler,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import styles from '../../../../../assets/css/style';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import ImageViewer from '../../../Common/ImageViewer';
import ModalFilterPicker from 'react-native-modal-filter-picker';
import GooglePlaces from '../../../Common/GooglePlaces';
import {connect} from 'react-redux';
import {DatePicker, CheckBox} from 'native-base';
import ImagePicker from 'react-native-image-picker';
import moment from 'moment';
import axios from 'axios';
import Warning from '../../../Shop/Warning';

class EditDomestically extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      quantity: 1,
      step: 1,

      visible: false,
      fromShow: false,
      toShow: false,

      country_list: [],

      selectedCountry: {code: '', name: ''},
      showTotal: '',
      showServiceFee: '',

      city: '',
      state_to: '',
      state_from: '',
      slug: '',
      name_item: '',
      description: '',
      link_item: '',
      price_item: '',
      traveller_fee: '',
      delivery_from: '',
      delivery_to: '',
      delivery_domestic: '',
      delivery_date: '',
      additional_note: '',
      isAccepted: false,
      trvale_item_price: 0,
      service_fee: 0,
      total: 0,
      item_images: [],
      item_image_uris: [],
      imageViewUrl: null,
      isShowModal: false,

      isWarning: false,
      isPaylater: false,
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  _pickImage = async () => {
    var options = {
      maxWidth: 1000,
      maxHeight: 1000,
      mediaType: 'photo',
    };

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else if (this.state.item_image_uris.length >= 3) {
        return;
      } else {
        var uris = this.state.item_image_uris;

        uris.unshift({uri: response.uri, base64: response.data});
        this.setState({
          item_image_uris: uris,
        });
      }
    });
  };

  _removeImage = async index => {
    try {
      var urisD = this.state.item_image_uris;
      await urisD.splice(index, 1);
      this.setState({
        item_image_uris: urisD,
      });
    } catch (error) {
      // console.log(error)
    }
  };

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  _increaseQuantity() {
    var qant = this.state.quantity + 1;
    if (qant < 11) {
      this.setState({
        quantity: qant,
      });

      this._servicefeeTotal();
    }
    return;
  }

  _decreaseQuantity() {
    var qantneg = this.state.quantity - 1;
    if (qantneg > 1) {
      this.setState({
        quantity: qantneg,
      });
      this._servicefeeTotal();
    }
    return;
  }

  async _servicefeeTotal() {
    var price_item = this.state.price_item;
    var traveller_fee = this.state.traveller_fee;
    var travele_item_price = 0;
    var servicefee = 0;

    travele_item_price =
      (await parseFloat(price_item)) * this.state.quantity +
      parseFloat(traveller_fee);

    var servicefee = (await travele_item_price) * 0.08;

    if (this.props.currency !== '₹') {
      servicefee = servicefee + 0.3;
    }
    var gst = (await servicefee) * 0.18 + parseFloat(traveller_fee) * 0.18;

    var serviceFeeState =
      (await parseFloat(Math.round(servicefee * 100) / 100)) +
      parseFloat(Math.round(gst * 100) / 100);

    var showServiceFee = (await Math.round(serviceFeeState * 100)) / 100;

    var totalState = (await travele_item_price) + serviceFeeState;
    var showTotal = (await Math.round(totalState * 100)) / 100;

    this.setState({
      service_fee: serviceFeeState,
      total: totalState,
      showTotal: showTotal,
      showServiceFee: showServiceFee,
    });
    return;
  }

  _setState(type, value) {
    let isValid = Math.sign(value);

    if (isValid < 0 || isNaN(isValid)) {
      return;
    }
    if (type == 'price') {
      this.setState({
        price_item: value,
      });
    } else {
      this.setState({
        traveller_fee: value,
      });
    }
    this._servicefeeTotal();
  }

  async _handleFrom(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        delivery_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        state_from: state,
        country_from:
          data.address_components[data.address_components.length - 1].long_name,
        fromShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        delivery_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        state_to: state,
        country_to:
          data.address_components[data.address_components.length - 1].long_name,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _handleDatePicked = async date => {
    await this.setState({
      delivery_date: moment(date).format('DD/MM/YYYY'),
      defaultDateData: new Date(
        moment(date).format('YYYY'),
        moment(date).format('MM'),
        moment(date).format('DD'),
      ),
    });
  };

  _filterResult(indexkey) {
    const result = this.state.country_list.find(
      element => element.key === indexkey,
    );
    return result;
  }

  _changeDateFor(date) {
    return moment(date, 'DD/MM/YYYY').format('DD MMM, YYYY');
  }

  _onSelect = async picked => {
    try {
      let result = await this._filterResult(picked);
      this.setState({
        selectedCountry: {code: picked, name: result.label},
        visible: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        visible: false,
      });
    }
  };

  async _countryListCall() {
    try {
      let response = await axios.get('country/list');
      let responses = response.data;

      var countryList = [];
      await responses.forEach(element => {
        countryList.push({key: element.value, label: element.text});
      });

      await this.setState({
        country_list: countryList,
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _order(slug) {
    try {
      let response = await axios.get('edit/order/' + slug);
      var order = response.data.data;

      var item_image_uris = [];
      await order.item_images.forEach(element => {
        item_image_uris.push({uri: element, base64: element});
      });

      await this.setState({
        order: order,
        delivery_from: order.delivery_from,
        isPaylater: order.isPaylater,
        lang_from: order.lang_from,
        lat_from: order.lat_from,
        country_from: order.country_from,
        delivery_to: order.delivery_to,
        lang_to: order.lang_to,
        lat_to: order.lat_to,
        country_to: order.country_to,
        delivery_date: moment(order.delivery_date).format('DD/MM/YYYY'),

        selectedCountry: {name: order.country, code: order.country_code},
        item_images: order.item_images,
        item_image_uris: item_image_uris,
        price_item: String(order.price_item),
        traveller_fee: String(order.traveller_fee),
        name_item: order.name_item,

        link_item: order.link_item,
        description: order.description,
        additional_note: order.additional_note,
        quantity: order.quantity,
        slug: slug,

        delivery_domestic: order.city_name,
        city: order.city_name,
        state_from: order.state_from,
        state_to: order.state_to,
        isLoading: false,
      });

      this._servicefeeTotal();
    } catch (error) {
      // console.log(error)

      await Alert.alert('Oops!', 'No order data found!');
      this.props.navigation.navigate('MyOrders');
    }
  }

  isValid(data) {
    var isValidData = true;
    for (let i = 0; i < Object.keys(data).length; i++) {
      if (!data[Object.keys(data)[i]]) {
        this[Object.keys(data)[i]].focus();
        isValidData = false;
        break;
      }
    }
    return isValidData;
  }

  isfirstStepcompleted() {
    let data = {
      name_item: this.state.name_item,
      description: this.state.description,
      price_item: this.state.price_item,
      traveller_fee: this.state.traveller_fee,
    };

    if (!this.isValid(data)) {
      return false;
    }

    return true;
  }

  _next = key => {
    if (key == 2) {
      if (this.state.item_image_uris.length == 0) {
        alert('select atleast one image');
        return;
      }

      if (!this.isfirstStepcompleted()) {
        return;
      }
    }

    if (key == 3) {
      if (!this.state.delivery_from) {
        Alert.alert('Oops!', 'enter delivery from address');
        return;
      }

      if (!this.state.delivery_to) {
        Alert.alert('Oops!', 'enter delivery to address');
        return;
      }

      if (!this.state.delivery_date) {
        Alert.alert('Oops!', 'enter delivery date');
        return;
      }
    }

    this.scroller.scrollTo({x: 0, y: 0, animated: true});

    if (this.state.step) {
      this.setState({
        step: key,
      });
    }
  };

  _submitpost_paylater(isSubmit, navigate) {
    this.setState({
      isWarning: false,
    });

    if (isSubmit) {
      this._submitpost(navigate);
    } else {
      return;
    }
  }

  async _submitpost_warning() {
    if (!this.state.isAccepted) {
      await Alert.alert('Oops!', 'First Accept Terms And Conditions.');
      return;
    } else {
      this.setState({
        isWarning: true,
      });
    }
  }

  async _submitpost(navigate) {
    this.setState({
      isLoading: true,
    });

    try {
      if (!this.state.isAccepted) {
        await Alert.alert('First Accept Terms And Conditions.');
        this.setState({
          isLoading: false,
        });
        return;
      }

      var imagesBase64 = [];

      await this.state.item_image_uris.forEach(element => {
        imagesBase64.push(element.base64);
      });

      const data = {
        delivery_from: this.state.delivery_from,
        delivery_to: this.state.delivery_to,
        country: this.state.selectedCountry.name,
        country_code: this.state.selectedCountry.code,
        city: this.state.city,
        lang_from: this.state.lang_from,
        lang_to: this.state.lang_to,
        lat_from: this.state.lat_from,
        state_from: this.state.state_from,
        state_to: this.state.state_to,
        lat_to: this.state.lat_to,
        delivery_date: moment(this.state.delivery_date, 'DD/MM/YYYY').format(
          'YYYY-MM-DD H:mm:ss',
        ),
        item_images: imagesBase64,
        price_item: this.state.price_item,
        traveller_fee: this.state.traveller_fee,
        service_fee: this.state.service_fee,
        name_item: this.state.name_item,
        link_item: this.state.link_item,
        description: this.state.description,
        additional_note: this.state.additional_note,
        quantity: this.state.quantity,
        isMobile: true,
        isPayLater: this.state.isPaylater,
      };

      let response = await axios.post(
        'order/domestic/edit/' + this.state.slug,
        data,
      );

      await this.setState({
        isLoading: false,
      });

      navigate('OrderPost', {slug: response.data.data.slug});
    } catch (error) {
      // console.log(error)

      await Alert.alert('Opps!', 'Somthing went wrong!');
      this.setState({
        isLoading: false,
      });
    }
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });

    this._countryListCall();
    const slug = this.props.navigation.getParam('slug');
    this._order(slug);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  _domesticLocalElement() {
    return (
      <View style={styles.fromgroup}>
        <TouchableOpacity
          onPress={() => this.setState({visible: true})}
          style={styles.gpcountery}>
          <Text
            style={{
              fontSize: 16,
              color: '#5d5d5d',
              textAlign: 'left',
              width: '100%',
              paddingLeft: 25,
            }}>
            {this.state.selectedCountry.name
              ? this.state.selectedCountry.name
              : 'Country'}
          </Text>
        </TouchableOpacity>
        <ModalFilterPicker
          visible={this.state.visible}
          onSelect={this._onSelect}
          onCancel={() => this.setState({visible: false})}
          options={this.state.country_list}
          selectedOption={this.state.selectedCountry.code}
        />

        <View style={styles.googlefromGp}>
          <GooglePlaces
            defaultText={this.state.delivery_from}
            countryCode={this.state.selectedCountry.code}
            listDisplayed={this.state.fromShow}
            onSelectAddress={this._handleFrom}
            placeHolder="From city"
          />
        </View>

        <View style={styles.googlefromGp}>
          <GooglePlaces
            defaultText={this.state.delivery_to}
            countryCode={this.state.selectedCountry.code}
            listDisplayed={this.state.toShow}
            onSelectAddress={this._handleTo}
            placeHolder="To city"
          />
        </View>
      </View>
    );
  }

  elementOrder(navigate) {
    if (this.state.step == 1) {
      var images = [];
      var items = [1, 2, 3];
      if (this.state.item_image_uris.length > 0) {
        this.state.item_image_uris.forEach((image, index) => {
          var compo = (
            <View style={styles.gridimg} key={index}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({imageViewUrl: image.uri, isShowModal: true})
                }>
                <Image
                  source={{
                    uri: image.uri,
                  }}
                  resizeMode="cover"
                  style={{height: 105, width: 105}}
                />
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.imggride_remove_btn}
                onPress={() => this._removeImage(index)}>
                <Entypo name="cross" size={30} style={{color: '#660165'}} />
              </TouchableOpacity>
            </View>
          );
          images.push(compo);
        });
      }

      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          {/* <Text style={styles.allheading}>Shop Domestically & Locally</Text> */}
          <View style={styles.fromgroup}>
            <Text style={styles.tell_us}>Tell us about your items.</Text>

            <Text
              style={{
                fontSize: 14,
                color: '#2d2d2d',
                fontFamily: 'Montserrat-Regular',
              }}>
              Images Of The Porduct (Atleast One Required)
            </Text>
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity
              onPress={() => this._pickImage()}
              style={styles.cameraupload}>
              <FontAwesome name="camera" size={25} style={{color: '#fff'}} />
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 18,
                  color: '#fff',
                  marginLeft: 10,
                }}>
                {this.state.item_image_uris.length > 0
                  ? 'Upload More Item Images'
                  : 'Upload Item Images'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.grideimageshop}>
            {images.length > 0 ? images : null}
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Name of item:</Text>
            </View>
            <TextInput
              style={styles.inputbox}
              placeholder=""
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              onChangeText={name_item => this.setState({name_item})}
              value={this.state.name_item}
              ref={input => {
                this.name_item = input;
              }}
            />
          </View>
          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Description:</Text>
            </View>
            <TextInput
              style={styles.inputdescription}
              placeholder="Describe your item (e.g. color, size)"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              onChangeText={description => this.setState({description})}
              value={this.state.description}
              ref={input => {
                this.description = input;
              }}
            />
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Link of product:</Text>
            </View>
            <TextInput
              style={styles.inputbox}
              placeholder="Web link to the item (optional)"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              onChangeText={link_item => this.setState({link_item})}
              value={this.state.link_item}
            />
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Price of the item:</Text>
            </View>
            <TextInput
              style={styles.inputbox}
              placeholder="Enter item price (inc. all Tax)"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              onChangeText={price_item => this._setState('price', price_item)}
              value={this.state.price_item}
              ref={input => {
                this.price_item = input;
              }}
            />
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Traveller Fee:</Text>
            </View>
            <TextInput
              style={styles.inputbox}
              placeholder="Traveller Fee:"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              onChangeText={traveller_fee =>
                this._setState('traveller', traveller_fee)
              }
              value={this.state.traveller_fee}
              ref={input => {
                this.traveller_fee = input;
              }}
            />
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>Quantity</Text>
            </View>
            <View style={styles.quantatybtn}>
              <Text
                style={styles.increment}
                onPress={() => this._decreaseQuantity()}>
                <FontAwesome name="minus" size={16} style={styles.colorwhite} />
              </Text>
              <Text style={[styles.increment, styles.incrementcount]}>
                {this.state.quantity}
              </Text>
              <Text
                style={styles.increment}
                onPress={() => this._increaseQuantity()}>
                <FontAwesome name="plus" size={16} style={styles.colorwhite} />
              </Text>
            </View>
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity onPress={() => this._next(2)}>
              <Text style={styles.Searchbtn}>Next</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else if (this.state.step == 2) {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={{width: '100%', marginVertical: 5}}>
            <Text
              style={{
                fontSize: 16,
                color: '#660165',
                fontFamily: 'Montserrat-semiBold',
                marginBottom: 5,
              }}>
              Where you will take the delivery of your item?
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: '#2d2d2d',
                fontFamily: 'Montserrat-Regular',
                lineHeight: 22,
              }}>
              Provide Us The Detail And Name Of The City Where You Want Ot Take
              The Delivery Of Your Order. You And The Traveller Will Decide The
              Address Or Teh Meeting Point Mutually. So We Need To Know The
              Details Of The Delivery City Now Itself.
            </Text>
            <Text
              style={{
                fontSize: 17,
                color: '#660165',
                fontFamily: 'Montserrat-Bold',
                marginTop: 5,
              }}>
              Make Your Choice
            </Text>
          </View>

          {this._domesticLocalElement()}

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                By What Date You Want The Delivery
              </Text>
            </View>
            <View style={styles.datepiker}>
              <DatePicker
                defaultDate={
                  new Date(
                    moment(this.state.delivery_date, 'DD/MM/YYYY').format(
                      'YYYY, MM, DD',
                    ),
                  )
                }
                minimumDate={new Date()}
                locale={'en'}
                timeZoneOffsetInMinutes={undefined}
                modalTransparent={false}
                animationType={'fade'}
                androidMode={'default'}
                placeholder="DD/MM/YYY"
                textStyle={{color: '#878787'}}
                placeHolderTextStyle={{color: '#878787'}}
                onDateChange={this._handleDatePicked}
                style={{borderWidth: 1}}
              />
            </View>
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                Additional Note To Traveller(Optional)
              </Text>
            </View>
            <TextInput
              style={styles.inputdescription}
              placeholder="Type your message here...."
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              value={this.state.additional_note}
              onChangeText={additional_note => this.setState({additional_note})}
            />
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity onPress={() => this._next(3)}>
              <Text style={styles.Searchbtn}>Next</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(1)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={styles.fromgroup}>
            <Text style={styles.review_final}>
              Review before final submission.
            </Text>
          </View>
          <View
            style={{
              height: 300,
              width: '99%',
              alignItems: 'center',
              overflow: 'hidden',
              borderWidth: 2,
              borderColor: '#fff',
            }}>
            <Image
              style={styles.fitImage}
              source={{uri: this.state.item_image_uris[0].uri}}
              style={{width: 400, height: 300}}
              resizeMode="contain"
            />
          </View>
          <View style={styles.fromgroup}>
            <Text style={styles.productname}>{this.state.name_item}</Text>
            <View style={styles.adressbox}>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling From : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_from}{' '}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling To : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_to}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Delivery Date: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this._changeDateFor(this.state.delivery_date)}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Quantity: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.quantity}
                </Text>
              </View>
            </View>
          </View>
          <View style={[styles.fromgroup, styles.borderBottom]}>
            <Text style={{fontSize: 14, lineHeight: 26, marginBottom: 10}}>
              Below Is The Approximate Price Summary For Your Order Delivery.
            </Text>
          </View>

          <View style={[styles.fromgroup, styles.borderBottom]}>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Item Price</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.price_item}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Traveller Fee</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.traveller_fee}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Quantity</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.state.quantity}
              </Text>
            </View>
            {this.state.isPaylater ? null : (
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Service Fee</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {this.state.showServiceFee}
                </Text>
              </View>
            )}
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Total Amount</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency}{' '}
                {this.state.isPaylater
                  ? parseFloat(this.state.price_item) * this.state.quantity +
                    parseFloat(this.state.traveller_fee)
                  : this.state.showTotal}
              </Text>
            </View>
          </View>
          {/* pay later */}

          {/* <View style={styles.paylater}>
                    <CheckBox checked={this.state.isPaylater} onPress={() => this.setState({ isPaylater: !this.state.isPaylater})} />
                    <View style={{marginLeft:25,}}>
                        <Text style={{fontFamily:'Montserrat-Medium',fontSize:14 }}>Pay Later</Text>
                    </View>
                </View> */}
          {/* Terms Conditions */}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'flex-start',
              width: '100%',
            }}>
            <CheckBox
              checked={this.state.isAccepted}
              onPress={() =>
                this.setState({isAccepted: !this.state.isAccepted})
              }
            />
            <View
              style={{
                marginLeft: 25,
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
              <Text style={{fontFamily: 'Montserrat-Medium', fontSize: 14}}>
                By Submitting The Order, I Agree To
              </Text>
              <TouchableOpacity>
                <Text
                  style={{
                    color: '#660165',
                    fontSize: 17,
                    fontFamily: 'Montserrat-Medium',
                  }}>
                  Terms And Conditions.
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity
              onPress={() =>
                this.state.isPaylater
                  ? this._submitpost_warning()
                  : this._submitpost(navigate)
              }>
              <Text style={styles.Searchbtn}>Update My Order</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(2)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }

  render() {
    const {navigate} = this.props.navigation;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={styles.containerbox}>
          {this.state.isWarning ? (
            <Warning
              onCloseDes={data => this._submitpost_paylater(data, navigate)}
            />
          ) : null}
          <ImageViewer
            isShowModal={this.state.isShowModal}
            imageUrl={this.state.imageViewUrl}
            onClose={() =>
              this.setState({isShowModal: false, imageViewUrl: null})
            }
          />
          <ScrollView
            ref={scroller => {
              this.scroller = scroller;
            }}>
            {this.elementOrder(navigate)}
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(EditDomestically);
