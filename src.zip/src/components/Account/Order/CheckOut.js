import React from 'react';
import {
  StyleSheet,
  Text,
  BackHandler,
  View,
  Image,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
  Alert,
  Modal,
  RefreshControl,
  StatusBar,
} from 'react-native';
import styles from '../../../../assets/css/style';
import OrderSubmitting from '../../Common/OrderSubmitting';
import AddNewAddresses from './Addresses/AddNewAddresses';
import AddressesList from './Addresses/AddressesList';
import EditAddress from './Addresses/EditAddress';
import {STORAGE_URL} from '../../../config/env';
import axios from 'axios';
import {connect} from 'react-redux';
import {WebView} from 'react-native-webview';

class CheckOut extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      offerId: null,
      slug: null,
      isLoading: true,
      country_codes: [],
      paymentsData: null,
      countryCode: '+91',
      addresses: [],
      email: '',
      phone: '',
      zip: '',
      country: 'India',
      city: '',
      state: '',
      address_1: '',
      address_2: '',
      first_name: '',
      last_name: '',
      isRazorPay: true,
      showAddress: false,
      showCancel: false,
      editAddress: false,
      editAddressIndex: 0,
      address: {},
      addressID: null,
      addressModel: null,
      updateAddress: false,
      clickedfun: false,
      actionUrl: null,
      payID: null,
      invoiceID: '',
      jsonData: {},
      uri: '',
      isPayment: false,
      isWebViewLoading: true,
      refreshing: false,
    };

    this._handleAddressSaved = this._handleAddressSaved.bind(this);
    this._handleAddressUpdated = this._handleAddressUpdated.bind(this);
    this._handleCancle = this._handleCancle.bind(this);
    this._handleEditIndex = this._handleEditIndex.bind(this);
    this._handleDelete = this._handleDelete.bind(this);
    this._handleCheked = this._handleCheked.bind(this);
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  async componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });

    const offerId = await this.props.navigation.getParam('offerId');
    const slug = await this.props.navigation.getParam('slug');
    await this.setState({offerId, slug});
    await this._countryCodeCall();
    this._order(offerId, slug, 0);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  ActivityIndicatorLoadingView() {
    return (
      <ActivityIndicator
        color="#009688"
        size="large"
        style={stylesLoading.ActivityIndicatorStyle}
      />
    );
  }

  async _handleDelete(index) {
    try {
      var stateaddresses = this.state.addresses.filter(
        (address, arrayindex) => {
          return arrayindex !== index;
        },
      );

      this.setState({
        addresses: stateaddresses,
      });

      Alert.alert('Success', 'Successfully address deleted.');
    } catch (error) {
      // console.log(error)
    }
  }

  _handleCheked(index) {
    let addresses = [...this.state.addresses];
    let address = addresses[index];
    this.setState({
      email: address.email,
      first_name: address.first_name,
      last_name: address.last_name,
      phone: address.phone,
      zip: address.zip,
      city: address.city,
      state: address.state,
      country: address.country,
      address_1: address.address_1,
      address_2: address.address_2,
      countryCode: address.country_data ? address.country_data.dial_code : 101,
    });
  }

  _addressData() {
    let data = {
      email: this.state.email,
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      phone: this.state.phone,
      zip: this.state.zip,
      city: this.state.city,
      state: this.state.state,
      country: this.state.country,
      address_1: this.state.address_1,
      address_2: this.state.address_2,
      countryCode: this.state.countryCode,
      isMobile: true,
    };

    return data;
  }

  _handleCancle(type) {
    if (type === 1) {
      this.setState({
        showAddress: false,
        editAddress: false,
        showCancel: false,
      });
    } else if (type === 2) {
      this.setState({
        editAddress: false,
      });
    } else {
      this.setState({
        showAddress: true,
        editAddress: false,
        showCancel: true,
      });
    }
  }

  _handleEditIndex(index) {
    this.setState({
      address: this.state.addresses[index],
      editAddressIndex: index,
      editAddress: true,
    });
  }

  async _order(offerId, slug, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }

    try {
      let response = await axios.get('checkout/data/' + slug + '/' + offerId);
      if (response.data[1].length > 0) {
        // this._handleCheked(this.state.addresses[0])
        var address = response.data[1][0];
        this.setState({
          order: response.data[0],
          addresses: response.data[1],
          showAddress: response.data[1].length > 0 ? false : true,
          showCancel: response.data[1].length > 0 ? true : false,
          email: address.email,
          first_name: address.first_name,
          last_name: address.last_name,
          phone: address.phone,
          zip: address.zip,
          city: address.city,
          state: address.state,
          country: address.country,
          address_1: address.address_1,
          address_2: address.address_2,
          countryCode: address.country_data
            ? address.country_data.dial_code
            : 101,
          isLoading: false,
          refreshing: false,
        });
      } else {
        this.setState({
          order: response.data[0],
          addresses: response.data[1],
          showAddress: response.data[1].length > 0 ? false : true,
          showCancel: response.data[1].length > 0 ? true : false,
          isLoading: false,
          refreshing: false,
        });
      }
    } catch (error) {
      if (type) {
        this.setState({
          refreshing: false,
        });
      } else {
        Alert.alert('Oops!', 'No order data found!');
        this.props.navigation.navigate('MyOrders');
      }
    }
  }

  async _countryCodeCall() {
    try {
      let response = await axios.get('country/code');
      this.setState({
        country_codes: response.data,
      });

      return;
    } catch (error) {
      // console.log(error)
    }
  }

  _handleAddressSaved = async address => {
    try {
      let addresses = [...this.state.addresses];
      addresses.unshift(address);
      this.setState({
        addresses,
        showAddress: false,
      });
      Alert.alert('Success', 'Successfully address saved.');
      if (addresses.length - 1 == 0) {
        this._handleCheked(0);
      }
    } catch (error) {
      // console.log(error)
      Alert.alert('Opps!', 'Somthing went wrong');
    }
  };

  _handleAddressUpdated = async address => {
    // return
    try {
      var addresses = this.state.addresses;
      addresses[this.state.editAddressIndex] = address;
      this.setState({
        addresses: addresses,
        showAddress: false,
        editAddress: false,
      });
      Alert.alert('Success', 'Successfully address updated.');
    } catch (error) {
      // console.log(error)
      Alert.alert('Opps!', 'Somthing went wrong');
    }
  };

  _handleAddressUpdated = async address => {
    try {
      let addresses = this.state.addresses;
      addresses[this.state.editAddressIndex] = address;
      this.setState({
        addresses: addresses,
        showAddress: false,
        editAddress: false,
      });
      Alert.alert('Success', 'Successfully address updated.');
    } catch (error) {
      // console.log(error)
      Alert.alert('Opps!', 'Somthing went wrong');
    }
  };

  getParams(url) {
    var params = {};
    // var parser = document.createElement('a');
    // parser.href = url;
    // var query = url.search.substring(1);
    var query = url;
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split('=');
      params[pair[0]] = decodeURIComponent(pair[1]);
    }
    return params;
  }

  async _handleCallBack(data) {
    try {
      let types = ['success', 'cancel'];
      let isType = types.indexOf(data.title);
      if (isType < 0) {
        return;
      }

      this.setState({
        isPayment: false,
        isLoading: true,
      });

      let url, newDatas;

      if (this.state.isRazorPay) {
        url =
          'payment/status/' +
          data.title +
          '/' +
          this.state.invoiceID +
          '/' +
          this.state.payID;
        if (data.title == 'success') {
          newDatas = this.getParams(data.url.split('?')[1]);
          response = await axios.post(url, newDatas);
        } else {
          response = await axios.post(url);
        }
      } else {
        newDatas = this.getParams(data.url.split('?')[1]);
        url = 'payment/status/' + data.title + '/' + this.state.invoiceID;
        response = await axios.post(url, newDatas);
      }

      this.setState({
        isPayment: false,
        isLoading: false,
      });

      if (data.title == 'success') {
        this.props.navigation.navigate('OrderConfirm', {slug: this.state.slug});
        return;
      }

      Alert.alert('Faild', 'Payment faild!');
    } catch (error) {
      // console.log(error)
      this.setState({
        isPayment: false,
        isLoading: false,
      });
      Alert.alert('Opps!', 'Somthing went wrong');
    }
  }

  async _handlePayment() {
    this.setState({
      isLoading: true,
    });

    try {
      let newData = this._addressData();

      let postUri;
      if (this.state.isRazorPay) {
        postUri =
          'checkout/pay/razorpay/' + this.state.slug + '/' + this.state.offerId;
      } else {
        postUri = 'checkout/pay/' + this.state.slug + '/' + this.state.offerId;
      }
      let response = await axios.post(postUri, newData);
      let uri = '';
      let jsonData = {};
      if (this.state.isRazorPay) {
        uri = response.data.url;
        jsonData = response.data.jsonData;
      } else {
        uri = response.data.redirect;
      }
      this.setState({
        uri: uri,
        payID: response.data.payID,
        jsonData: jsonData,
        invoiceID: response.data.invoiceID,
        isPayment: true,
        isWebViewLoading: true,
        isLoading: false,
      });
    } catch (error) {
      // if (rror.request.response) {
      //      console.log(JSON.parse(error.request.response))
      // }else{
      //     console.log(error);
      // }
      Alert.alert('Oops!', 'server error!');
      this.setState({
        isLoading: false,
      });
      // this.props.navigation.navigate('MyOrders')
    }
  }

  render() {
    const navigate = this.props.navigation;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else if (this.state.isPayment && !this.state.isRazorPay) {
      return (
        <Modal
          animationType="slide"
          transparent={false}
          visible={true}
          onRequestClose={() => {
            //   Alert.alert('Modal has been closed.');
            Alert.alert(
              'Are you sure',
              'Are you sure want to abort this payment',
              [
                {
                  text: 'Cancel',
                  onPress: () => console.log('Cancel Pressed'),
                  style: 'cancel',
                },
                {
                  text: 'OK',
                  onPress: () =>
                    this.setState({
                      isPayment: false,
                    }),
                },
              ],
              {cancelable: false},
            );
          }}>
          <WebView
            javaScriptEnabled={true}
            domStorageEnabled={true}
            renderLoading={this.ActivityIndicatorLoadingView}
            startInLoadingState={this.state.isWebViewLoading}
            onNavigationStateChange={data => this._handleCallBack(data)}
            onLoadEnd={() => this.setState({isWebViewLoading: false})}
            onMessage={data => this._handleCallBack(data)}
            source={{uri: this.state.uri}}
          />
        </Modal>
      );
    } else if (this.state.isPayment && this.state.isRazorPay) {
      return (
        <Modal
          animationType="slide"
          transparent={false}
          visible={true}
          onRequestClose={() => {
            Alert.alert(
              'Are you sure',
              'Are you sure want to abort this payment',
              [
                {
                  text: 'Cancel',
                  onPress: () => console.log('Cancel Pressed'),
                  style: 'cancel',
                },
                {
                  text: 'OK',
                  onPress: () =>
                    this.setState({
                      isPayment: false,
                    }),
                },
              ],
              {cancelable: false},
            );
          }}>
          <WebView
            javaScriptEnabled={true}
            source={{uri: this.state.uri}}
            domStorageEnabled={false}
            renderLoading={this.ActivityIndicatorLoadingView}
            startInLoadingState={this.state.isWebViewLoading}
            onNavigationStateChange={data => this._handleCallBack(data)}
            onLoadEnd={() => this.setState({isWebViewLoading: false})}
            onMessage={data => this._handleCallBack(data)}
          />
        </Modal>
      );
    } else {
      var order_data = this.state.order;
      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={() =>
                this._order(this.state.offerId, this.state.slug, 1)
              }
              style={{backgroundColor: 'transparent'}}
            />
          }>
          <StatusBar backgroundColor="#660165" barStyle="light-content" />
          <View style={styles.container}>
            <View style={[styles.card, styles.shadow]}>
              <View style={{width: '100%', marginBottom: 10}}>
                <TouchableOpacity>
                  <Text style={styles.prodectname}>
                    {order_data.name_item_lm}
                  </Text>
                </TouchableOpacity>

                <Image
                  style={styles.fitImage}
                  source={{
                    uri: order_data.images[0],
                  }}
                  resizeMode="cover"
                  style={{height: 200}}
                />
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Item Price</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {order_data.price_item}
                </Text>
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Quantity</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {order_data.quantity}
                </Text>
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Traveller & Service Fee</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {order_data.tra_ser_fee}
                </Text>
              </View>
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Tax</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {order_data.taxes}
                </Text>
              </View>
              <View style={styles.hrborder} />

              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Total Amount</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {order_data.total}
                </Text>
              </View>
            </View>

            {this.state.showAddress || this.state.addresses.length === 0 ? (
              <AddNewAddresses
                country_codes={this.state.country_codes}
                onCancle={() => this._handleCancle(1)}
                showCancel={this.state.showCancel}
                AddreesedSaved={this._handleAddressSaved}
              />
            ) : null}

            {!this.state.showAddress && this.state.addresses.length > 0 ? (
              <AddressesList
                addMore={() => this._handleCancle(0)}
                addresses={this.state.addresses}
                onDeleteAddress={this._handleDelete}
                onEditAddress={this._handleEditIndex}
                onChekedAddress={this._handleCheked}
              />
            ) : null}

            {this.state.editAddress ? (
              <EditAddress
                country_codes={this.state.country_codes}
                onCancle={() => this._handleCancle(2)}
                address={this.state.address}
                AddreesedUpdated={this._handleAddressUpdated}
              />
            ) : null}

            <View style={[styles.card, styles.shadow]}>
              <View style={{marginVertical: 10}}>
                <View
                  style={{flexDirection: 'row', justifyContent: 'flex-start'}}>
                  <TouchableOpacity
                    style={{marginRight: 5}}
                    onPress={() => this.setState({isRazorPay: true})}>
                    <Image
                      style={styles.fitImage}
                      source={{
                        uri: this.state.isRazorPay
                          ? STORAGE_URL + 'mobileapp/chaked.png'
                          : STORAGE_URL + 'mobileapp/unchaked.png',
                      }}
                      resizeMode="cover"
                      style={{height: 30, width: 30}}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity style={{}}>
                    <Text style={{fontFamily: 'Montserrat-semiBold'}}>
                      Credit Card/Debit Card/Net Banking/Wallets(For India Only){' '}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* <View style={{ marginVertical: 10, }}>
                                <View style={{flexDirection:'row', justifyContent:'flex-start'}}>
                                    <TouchableOpacity style={{marginRight:5}} onPress={() => this.setState({isRazorPay: false})}>
                                        <Image style={styles.fitImage} source={{
                                            uri: !this.state.isRazorPay ? STORAGE_URL+ 'mobileapp/chaked.png' :  STORAGE_URL+ 'mobileapp/unchaked.png'
                                        }}
                                            resizeMode='cover'
                                            style={{ height: 30, width: 30, }}
                                        />
                                    </TouchableOpacity>
                                    <TouchableOpacity style={{}}>
                                        <Text style={{fontFamily:'Montserrat-regular'}}>Paypal(For Outside India User Only)</Text>
                                    </TouchableOpacity>
                                </View>
                            </View> */}

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handlePayment()}>
                  <Text style={styles.Searchbtn}>Pay Now</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      );
    }
  }
}

const stylesLoading = StyleSheet.create({
  ActivityIndicatorStyle: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(CheckOut);
