import React from 'react'
import { BackHandler ,Dimensions} from 'react-native'
import { createMaterialTopTabNavigator, createAppContainer} from 'react-navigation'
import OrderSubmitting from '../../Common/OrderSubmitting'
import { connect } from 'react-redux'
import filter from 'lodash/filter'
import moment from 'moment'
import axios from 'axios'
import NewHeader from '../../Menu/NewHeader'
import styles from '../../../../assets/css/style'

import Inactive  from './Partial/Inactive'
import Received  from './Partial/Received'
import Request  from './Partial/Request'
import Transit  from './Partial/Transit'

import { RECEIVED_ORDERS, INACTIVE_ORDERS, TRANSIT_ORDERS, REQUEST_ORDERS, ALL_ORDERS } from "../../../redux/actions/types"

const fontsizerwidth = Dimensions.get('window').width

const fontSizer = (screenWidth) => {
    if(screenWidth > 400){
      return 12;
    }else if(screenWidth > 360){
      return 11;
    }
    else if(screenWidth > 250){
        return 10;
      }else { 
      return 9;
    }
}
// console.log(fontsizerwidth);

  
class MyOrders extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            navigation: this.props.navigation,
            orders: [],
            requestedOrders: [],
            inactiveOrders: [],
            intransitOrders: [],
            receivedOrders: [],
            allorders: [],
            isLoading: true,
            refreshing:false
        }

    }

    static navigationOptions = ({ navigation }) => {
        return {
            header: <NewHeader isHome={false} title="My Orders" navigate={navigation} routeName="MyOrders"/>
        }
    }

    async _filterOrder(allorders) {
        try {
           
            var requestedOrders =  await filter(allorders, (order) =>  {
                return !order.isCanceled && !order.isDeleted && !order.paid && moment(order.deliverydate).isSameOrAfter(moment().format('YYYY-MM-DD'));
            })

            var inactiveOrders =  await filter(allorders, (order) =>  {
                return order.isCanceled || order.isDeleted || moment(order.deliverydate).isBefore(moment().format('YYYY-MM-DD'));
            })

            var intransitOrders =  await filter(allorders, (order) =>  {
                return order.paid && !order.isDelivered;
            })

            var receivedOrders = await filter(allorders, (order) =>  {
                return order.paid && order.isDelivered;
            })

            await this.props.sendReceivedOrders(receivedOrders)
            await this.props.sendInactiveOrders(inactiveOrders)
            await this.props.sendTransitOrders(intransitOrders)
            await this.props.sendRequestOrders(requestedOrders)

             this.setState({
                requestedOrders,
                inactiveOrders,
                intransitOrders,
                receivedOrders,
                isLoading:false,
                refreshing:false
            })
        } catch (error) {
            // console.log(error)
        }
    }
    


    async order(type) {
        if (type) {
            this.setState({
                refreshing:true
            })
        }else{
            this.setState({
                isLoading: true
            })
        }
        try {
            let response = await axios.get('my/orders')
            this.setState({
                allorders: response.data.data,
            })
            this.props.sendAllOrders(response.data.data)
            this._filterOrder(response.data.data)
        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false,
                refreshing:false
            })
        }
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
        this.order(0)

    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }
  
    render() {
        
        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {

            if (this.state.allorders.lenght == 0) {
                return (
                    <View style={styles.container}>
                        <ScrollView 
                            refreshControl={
                            <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={() => this.order( 1)}
                            style={{backgroundColor: 'transparent'}}
                            />}>
                            <View style={styles.fromgroup}>
                                <Text style={{textAlign:'center',
                                fontSize:18,color:'black',marginLeft:10,
                                fontFamily:'Montserrat-Regular', }}>
                                    No  order found
                                </Text>
                            </View>
                        </ScrollView>
                    </View >
                )
            }

            return (
                <Tabs screenProps={this.props.navigation.push} />
            )
        }
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency,
        user: state.auth.user
    }
}

const mapDispatchToProps = dispatch => {
    return({
        sendReceivedOrders: (orders) => {
            dispatch({
                type:RECEIVED_ORDERS,
                payload:orders
            })
        },
        sendInactiveOrders: (orders) => {
            dispatch({
                type:INACTIVE_ORDERS,
                payload:orders
            })
        },
        sendTransitOrders: (orders) => {
            dispatch({
                type:TRANSIT_ORDERS,
                payload:orders
            })
        },
        sendRequestOrders: (orders) => {
            dispatch({
                type:REQUEST_ORDERS,
                payload:orders
            })
        },
        sendAllOrders: (orders) => {
            dispatch({
                type:ALL_ORDERS,
                payload:orders
            })
        }
    })
}



const Tabs =  createAppContainer(createMaterialTopTabNavigator(
    {
        RequestOrders: {
            screen: Request,
            navigationOptions:{
              tabBarLabel:'Request'
            }
        },

        TransitOrders: {
            screen: Transit,
            navigationOptions:{
                tabBarLabel:'Transit'
            }
        },

        ReceivedOrders: {
            screen: Received,
            navigationOptions:{
                tabBarLabel:'Received'
            }
        },

        InactiveOrders: {
            screen: Inactive,
            navigationOptions:{
                tabBarLabel:'Inactive'
            }
        },
    },{
        tabBarOptions: {
            style: {
                backgroundColor: '#660165',
                marginBottom:30,
            },
            labelStyle: {
                fontSize: fontSizer(fontsizerwidth),
                fontFamily:'Montserrat-Bold',
                // fontWeight:"800",
                // borderBottomColor:'#fff'
            },
            activeTintColor: '#ffff',
            inactiveTintColor: 'gray',
            indicatorStyle:{
                borderBottomColor: '#ffffff',
                borderBottomWidth: 4,

            },
        }
    }
))

export default connect(mapStateToProps, mapDispatchToProps)(MyOrders)
