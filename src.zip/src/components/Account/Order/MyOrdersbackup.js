import React from 'react'
import { Text, View, Image, TouchableOpacity, Dimensions, ScrollView, Alert, BackHandler, RefreshControl } from 'react-native'

import styles from '../../../../assets/css/style'
import OrderSubmitting from '../../Common/OrderSubmitting'
import { connect } from 'react-redux'
import _ from 'lodash'
import Carousel from 'react-native-snap-carousel'
import moment from 'moment'
import axios from 'axios'
import NewHeader from '../../Menu/NewHeader'

const sliderWidth = Dimensions.get('window').width
const itemWidth = sliderWidth

class MyOrders extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            navigation: this.props.navigation,
            orders: [],
            requestedOrders: [],
            inactiveOrders: [],
            intransitOrders: [],
            receivedOrders: [],
            allorders: [],
            isLoading: false,
            refreshing:false,
            step: 1,
            activeSlide:0
        }
    }

    static navigationOptions = ({ navigation }) => {
        return {
            header: <NewHeader isHome={true} title="My Orders" navigate={navigation}/>
        }
    }

    async _stepFun(step) {
        try {

            if (step == 1) {
                await this.setState({
                    step: step,
                    orders: this.state.requestedOrders
                })
            } else if (step == 2) {
                await this.setState({
                    step: step,
                    orders: this.state.intransitOrders
                })
            } else if (step == 3) {
                await this.setState({
                    step: step,
                    orders: this.state.receivedOrders
                })
            } else {
                await this.setState({
                    step: step,
                    orders: this.state.inactiveOrders
                })
            }

        } catch (error) {

        }
    }

    _pushToEditPage(order_type, isFood, slug, navigate) {


        if (order_type == 1 && !isFood) {
            navigate('EditGlobaly', { slug: slug })
            return
        }

        if (order_type == 2 && !isFood) {
            navigate('EditDomestically', { slug: slug })
            return
        }

        if (order_type == 3 && !isFood) {
            navigate('EditLocally', { slug: slug })
            return
        }

        if (order_type == 2 && isFood) {
            navigate('EditFoodDomestically', { slug: slug })
            return
        }

        if (order_type == 3 && isFood) {
            navigate('EditFoodLocally', { slug: slug })
            return
        }
    }

    async _filterOrder(allorders) {
        try {
            await this.setState({

                requestedOrders: _.filter(allorders, function (order) {
                    return !order.isCanceled && !order.isDeleted && !order.paid && moment(order.deliverydate).isSameOrAfter(moment().format('YYYY-MM-DD'));
                }),

                inactiveOrders: _.filter(allorders, function (order) {
                    return order.isCanceled || order.isDeleted || moment(order.deliverydate).isBefore(moment().format('YYYY-MM-DD'));
                }),

                intransitOrders: _.filter(allorders, function (order) {
                    return order.paid && !order.isDelivered;
                }),

                receivedOrders: _.filter(allorders, function (order) {
                    return order.paid && order.isDelivered;
                }),

                isLoading: false
            })

            this._stepFun(1)
        } catch (error) {
            // console.log(error)
        }
    }

    _filterOrderById(id, orders) {
        var index = orders.findIndex(order => order.id == id);
        if (index > -1) {
            return index
        }else{
            return null
        }
    }

    async _handleDelete(id) {
        this.setState({
            isLoading: true
        })

        try {
            await axios.post('my/delete/order/'+id)
            var allorders = this.state.allorders
            var inactiveOrders = this.state.inactiveOrders

            var indexAll = await this._filterOrderById(id,  allorders)
            var inActiveIndex =  await this._filterOrderById(id,  inactiveOrders)

            allorders = await allorders.filter((order, indexOrder) => {
                return indexOrder !== indexAll
            })

            inactiveOrders = await inactiveOrders.filter((order, index) => {
                return index !== inActiveIndex
            })

            await this.setState({
                allorders,
                inactiveOrders,
                orders: inactiveOrders,
                isLoading: false
            })

            await Alert.alert('Succcess', 'Successfully deleted order')

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            await Alert.alert('Opps!', 'Somthing went wrong')
        }
    }

    async _handleCancel(id, index) {

        this.setState({
            isLoading: true
        })

        try {
            await axios.post('my/cancel/order/'+id)
            var requestedOrders = this.state.requestedOrders
            var inactiveOrders = this.state.inactiveOrders
            var allorders = this.state.allorders

            var indexAll = await this._filterOrderById(id, allorders)
            var indexRequested = await this._filterOrderById(id, requestedOrders)

            if (indexAll) {
                allorders[indexAll]['isCanceled'] =  1
            }
            await inactiveOrders.unshift(requestedOrders[indexRequested])

            var newrequestedOrders = await requestedOrders.filter((order, indexOrder) => {
                return indexOrder != indexRequested
            })

            await this.setState({
                allorders,
                requestedOrders : newrequestedOrders,
                orders: newrequestedOrders,
                inactiveOrders,
                isLoading: false
            })

            Alert.alert('Success', 'Successfully canceled order')

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            Alert.alert('Opps!', 'somthing went wrong')
        }
    }

    async _handleWarning(id, type) {
        await Alert.alert(
            'Are you sure?',
            'Are you sure want' +  type ? 'delete' : 'cancel' + ' this order?',
            [
              {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
              {text: 'Okay', onPress: () => type ? this._handleDelete(id) : this._handleCancel(id)},
            ],
            { cancelable: false }
        )
    }

    async order(type) {
        if (type) {
            this.setState({
                refreshing:true
            })
        }else{
            this.setState({
                isLoading: true
            })
        }
        try {
            let response = await axios.get('my/orders')

            this.setState({
                allorders: response.data.data,
                refreshing:false
            })

            this._filterOrder(response.data.data)

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false,
                refreshing:false
            })
        }
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    componentWillMount() {
        this.order(0)
    }

   

    _renderItem = (item, index) => {
        var order = item.item
        const { navigate } = this.props.navigation
        var step = this.state.step
        var editButton = null
        var canceleButton = null
        var deleteButton = null

        if (step == 4 || !order.countOffer && step == 1) {
            editButton = <TouchableOpacity onPress={() => this._pushToEditPage(order.order_type, order.isFood, order.slug, navigate)}>
                            <Text style={[styles.offer, styles.bgyellow]}> {step == 4 ? 'Edit & Reactivate' : 'Edit'}</Text>
                        </TouchableOpacity>
        }

        if (step == 4) {
            deleteButton = <TouchableOpacity onPress={() => this._handleWarning(order.id, 1)}>
                            <Text style={[styles.offer, styles.bgred]}>Delete</Text>
                        </TouchableOpacity>
        }

        if (!order.countOffer && step == 1) {
            canceleButton = <TouchableOpacity onPress={() => this._handleWarning(order.id, 0)}>
                            <Text style={[styles.offer, styles.bgred]}>Cancel</Text>
                        </TouchableOpacity>
        }

        return (

            <View style={[styles.orderitemcard, styles.shadow]}>
                <View style={{ marginBottom: 10, }}>
                    <TouchableOpacity  onPress={() => navigate('OrderPost', { slug: order.slug })}>
                        <Text style={{ color: '#660165', fontSize: 16,fontFamily:'Montserrat-semiBold',  }}>{order.name_item}</Text>
                    </TouchableOpacity>
                </View>

                <Image style={styles.fitImage} source={{ uri: order.images[0] }} resizeMode='contain' style={{ height: 200, }} />
                <View style={styles.adressbox}>
                    <View style={styles.addresslistbox}>
                        <View style={{width:95,}}>
                            <Text style={styles.addresstitel}>Delivery To  </Text>
                        </View>
                        <View style={{flex:5}}>
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_to_no_limit}</Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <View style={{width:115,}}> 
                            <Text style={styles.addresstitel}>Delivery From  </Text>
                        </View>
                        <View style={{flex:5}}> 
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_from_no_limit} </Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <Text style={styles.addresstitel}>Before  </Text>
                        <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_date}</Text>
                    </View>
                </View>

                <View style={styles.pricebox}>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Item Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}> {this.props.currency} {order.price_item}</Text>
                    </View>
                    <View style={[styles.pricemain, styles.borderRightleft]}>
                        <Text style={styles.pricetitel}>Travellar Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{this.props.currency} {order.traveller_fee}</Text>
                    </View>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Quantity</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{order.quantity}</Text>
                    </View>
                </View>

                <View style={styles.offercontainer}>
                    <TouchableOpacity onPress={() => navigate('AllOffers', { slug: order.slug })}>
                        <Text style={[styles.offer, styles.bggreen]}> {order.countOffer} Offer</Text>
                    </TouchableOpacity>

                    {editButton}
                    {canceleButton}
                    {deleteButton}

                </View>

            </View>
        );
    }

    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {

            return (

                    <View style={styles.container}>
                        <ScrollView 
                            refreshControl={
                            <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={() => this.order( 1)}
                            style={{backgroundColor: 'transparent'}}
                            />}>

                            <View  style={styles.tabgpmain}>
                                <TouchableOpacity style={[styles.tabcolumn,styles.bdrright, this.state.step == 1 ? styles.tabcolumnactive : null]}>
                                    <Text style={[styles.tabcolumntxt,this.state.step == 1 ? styles.tabcolumnactivetext : null]} onPress={() => this._stepFun(1)}>
                                        {this.state.requestedOrders.length} Request
                                </Text>
                                </TouchableOpacity>

                                <TouchableOpacity  style={[styles.tabcolumn, styles.bdrright, this.state.step == 2 ? styles.tabcolumnactive : null]}>
                                    <Text style={[styles.tabcolumntxt,this.state.step == 2 ? styles.tabcolumnactivetext : null]} onPress={() => this._stepFun(2)}>
                                        {this.state.intransitOrders.length} in transit
                                </Text>
                                </TouchableOpacity >

                                <TouchableOpacity  style={[styles.tabcolumn, styles.bdrright, this.state.step == 3 ? styles.tabcolumnactive : null]}>
                                    <Text style={[styles.tabcolumntxt,this.state.step == 3 ? styles.tabcolumnactivetext : null]} onPress={() => this._stepFun(3)}>
                                    {this.state.receivedOrders.length} Received
                                </Text>
                            </TouchableOpacity >

                            <TouchableOpacity  style={[styles.tabcolumn, this.state.step == 4 ? styles.tabcolumnactive : null]}>
                                <Text style={[styles.tabcolumntxt,this.state.step == 4 ? styles.tabcolumnactivetext : null]} onPress={() => this._stepFun(4)}>
                                    {this.state.inactiveOrders.length} inactive
                                </Text>

                            </TouchableOpacity >
                            </View>
                            <Carousel
                                ref={(c) => { this._carousel = c; }}
                                data={this.state.orders}
                                renderItem={this._renderItem}
                                sliderWidth={sliderWidth}
                                itemWidth={itemWidth}
                                onSnapToItem={(index) => this.setState({ activeSlide: index })}
                            />
                        </ScrollView>
                    </View >

            )
        }
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency,
        user: state.auth.user
    }
}

export default connect(mapStateToProps, null)(MyOrders)
