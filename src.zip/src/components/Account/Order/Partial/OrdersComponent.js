import React from 'react'
import { Text, View, Image, TouchableOpacity, Dimensions, ScrollView, Alert, BackHandler, RefreshControl } from 'react-native'

import styles from '../../../../../assets/css/style'
import OrderSubmitting from '../../../Common/OrderSubmitting'
import { connect } from 'react-redux'
import _ from 'lodash'
import Carousel from 'react-native-snap-carousel'
import moment from 'moment'
import axios from 'axios'
import { RECEIVED_ORDERS, INACTIVE_ORDERS, TRANSIT_ORDERS, REQUEST_ORDERS, ALL_ORDERS } from "../../../../redux/actions/types"

class OrdersComponent extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            navigation: props.navigation,
            orders: props.orders,
            requestedOrders: props.requestOrders,
            inactiveOrders: props.inactiveOrders,
            intransitOrders: props.intransitOrders,
            receivedOrders: props.receivedOrders,
            allorders: props.allOrders,
            isLoading: false,
            refreshing:false,
            step: props.step,
            activeSlide:0,
            viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height
            }
        }
    }

 

    async _stepFun(step) {
        try {

            if (step == 1) {
                await this.setState({
                    step: step,
                    orders: this.state.requestedOrders
                })
            } else if (step == 2) {
                await this.setState({
                    step: step,
                    orders: this.state.intransitOrders
                })
            } else if (step == 3) {
                await this.setState({
                    step: step,
                    orders: this.state.receivedOrders
                })
            } else {
                await this.setState({
                    step: step,
                    orders: this.state.inactiveOrders
                })
            }

        } catch (error) {

        }
    }

    _pushToEditPage(order_type, isFood, slug) {

       
        
        if (order_type == 1 && !isFood) {
            this.props.push('EditGlobaly', { slug: slug })
            return
        }

        if (order_type == 2 && !isFood) {
            this.props.push('EditDomestically', { slug: slug })
            return
        }

        if (order_type == 3 && !isFood) {
            this.props.push('EditLocally', { slug: slug })
            return
        }

        if (order_type == 2 && isFood) {
            this.props.push('EditFoodDomestically', { slug: slug })
            return
        }

        if (order_type == 3 && isFood) {
            this.props.push('EditFoodLocally', { slug: slug })
            return
        }
    }

    async _filterOrder(allorders) {
        try {
           

            var requestedOrders = await _.filter(allorders, (order) => {
                return !order.isCanceled && !order.isDeleted && !order.paid && moment(order.deliverydate).isSameOrAfter(moment().format('YYYY-MM-DD'));
            })

            var inactiveOrders = await _.filter(allorders, (order) => {
                return order.isCanceled || order.isDeleted || moment(order.deliverydate).isBefore(moment().format('YYYY-MM-DD'));
            })

            var intransitOrders =  await _.filter(allorders, (order) => {
                return order.paid && !order.isDelivered;
            })

            var receivedOrders = await _.filter(allorders, (order) => {
                return order.paid && order.isDelivered;
            })

    
            await this.props.sendReceivedOrders(receivedOrders)
            await this.props.sendInactiveOrders(inactiveOrders)
            await this.props.sendTransitOrders(intransitOrders)
            await this.props.sendRequestOrders(requestedOrders)

            await this.setState({
                requestedOrders,
                inactiveOrders,
                intransitOrders,
                receivedOrders,
                isLoading:false,
                refreshing:false
            })

            this._stepFun(this.state.step)
        } catch (error) {
            // console.log(error)
        }
    }


    async order() {
       
        this.setState({
            refreshing:true
        })
        
        try {
            let response = await axios.get('my/orders')

            this.setState({
                allorders: response.data.data,
            })

            this.props.sendAllOrders(response.data.data)

            this._filterOrder(response.data.data)

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false,
                refreshing:false
            })
        }
    }

    _filterOrderById(id, orders) {
       
        
        var index = orders.findIndex(order => order.id == id)
        if (index > -1) {
            return index
        }else{
            return null
        }
    }

    async _handleDelete(id) {
       
        this.setState({
            isLoading: true
        })

        try {
            await axios.post('my/delete/order/'+id)
            var allorders = await this.state.allorders
            var inactiveOrders = await this.state.inactiveOrders

            var indexAll = await this._filterOrderById(id,  allorders)
            var inActiveIndex =  await this._filterOrderById(id,  inactiveOrders)

            allorders = await allorders.filter((order, indexOrder) => {
                return indexOrder !== indexAll
            })

            inactiveOrders = await inactiveOrders.filter((order, index) => {
                return index !== inActiveIndex
            })

            await this.props.sendAllOrders(allorders)
            await this.props.sendInactiveOrders(inactiveOrders)
            await this.setState({
                allorders,
                inactiveOrders,
                orders: inactiveOrders,
                isLoading: false
            })

            await Alert.alert('Succcess', 'Successfully deleted order')

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            await Alert.alert('Opps!', 'Somthing went wrong')
        }
    }

    async _handleCancel(id, index) {

        this.setState({
            isLoading: true
        })

        try {
            await axios.post('my/cancel/order/'+id)
            var requestedOrders = await this.state.requestedOrders
            var inactiveOrders = await this.state.inactiveOrders
            var allorders = await this.state.allorders
           
            var indexAll = await this._filterOrderById(id, allorders)
            var indexRequested = await this._filterOrderById(id, requestedOrders)

            if (indexAll) {
                allorders[indexAll]['isCanceled'] =  1
            }
            await inactiveOrders.unshift(requestedOrders[indexRequested])

            var newrequestedOrders = await requestedOrders.filter((order, indexOrder) => {
                return indexOrder != indexRequested
            })

            await this.props.sendAllOrders(allorders)
            await this.props.sendInactiveOrders(inactiveOrders)
            await this.props.sendRequestOrders(newrequestedOrders)

            await this.setState({
                allorders,
                requestedOrders : newrequestedOrders,
                orders: newrequestedOrders,
                inactiveOrders,
                isLoading: false
            })

            Alert.alert('Success', 'Successfully canceled order')

        } catch (error) {
            //  console.log(error)
            this.setState({
                isLoading: false
            })
            Alert.alert('Opps!', 'somthing went wrong')
        }
    }

    async _handleWarning(id, type) {

        await Alert.alert(
            "Are you sure?",
            `Are you sure want ${type ? " delete " : " cancel "} this order?`,
            [
              {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
              {text: 'Okay', onPress: () => type ? this._handleDelete(id) : this._handleCancel(id)},
            ],
            { cancelable: false }
        )
    }


    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

   

    _renderItem = (item, index) => {
        var order = item.item
    
        var step = this.state.step
        var editButton = null
        var canceleButton = null
        var deleteButton = null

        if (step == 4 ||  step == 1) {
            editButton = <TouchableOpacity onPress={() => this._pushToEditPage(order.order_type, order.isFood, order.slug)}>
                            <Text style={[styles.offer, styles.bgyellow]}> {step == 4 ? 'Edit & Reactivate' : 'Edit'}</Text>
                        </TouchableOpacity>
        }

        if (step == 4) {
            deleteButton = <TouchableOpacity onPress={() => this._handleWarning(order.id, 1)}>
                            <Text style={[styles.offer, styles.bgred]}>Delete</Text>
                        </TouchableOpacity>
        }

        if (step == 1 ) {
            canceleButton = <TouchableOpacity onPress={() => this._handleWarning(order.id, 0)}>
                            <Text style={[styles.offer, styles.bgred]}>Cancel</Text>
                        </TouchableOpacity>
        }

        return (

            <View style={[styles.orderitemcard, styles.shadow]}>
                <View style={{ marginBottom: 10, marginTop:5,}}>
                    <TouchableOpacity  onPress={() => this.props.push('OrderPost', { slug: order.slug })}>
                        <Text style={{ color: '#660165', fontSize: 16,fontFamily:'Montserrat-semiBold',  }}>{order.name_item}</Text>
                    </TouchableOpacity>
                </View>

                <Image style={styles.fitImage} source={{ uri: order.images[0] }} resizeMode='contain' style={{ height: 200, }} />
                <View style={styles.adressbox}>
                    <View style={styles.addresslistbox}>
                        <View style={{width:95,}}>
                            <Text style={styles.addresstitel}>Delivery To  </Text>
                        </View>
                        <View style={{flex:5}}>
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_to_no_limit}</Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <View style={{width:115,}}> 
                            <Text style={styles.addresstitel}>Delivery From  </Text>
                        </View>
                        <View style={{flex:5}}> 
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_from_no_limit} </Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <Text style={styles.addresstitel}>Before  </Text>
                        <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_date}</Text>
                    </View>
                </View>

                <View style={styles.pricebox}>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Item Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}> {this.props.currency} {order.price_item}</Text>
                    </View>
                    <View style={[styles.pricemain, styles.borderRightleft]}>
                        <Text style={styles.pricetitel}>Traveller Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{this.props.currency} {order.traveller_fee}</Text>
                    </View>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Quantity</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{order.quantity}</Text>
                    </View>
                </View>

                <View style={styles.offercontainer}>
                    <TouchableOpacity onPress={() => this.props.push('AllOffers', { slug: order.slug })}>
                        <Text style={[styles.offer, styles.bggreen]}> {order.countOffer} Offer</Text>
                    </TouchableOpacity>

                    {editButton}
                    {canceleButton}
                    {deleteButton}

                </View>

            </View>
        )
    }

    render() {

        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {
            
            return (

                <View style={styles.container}
                    onLayout={() => {
                        this.setState({
                            viewport: {
                                width: Dimensions.get('window').width,
                                height: Dimensions.get('window').height
                            }
                        });
                    }}>
                    <ScrollView 
                        refreshControl={
                        <RefreshControl
                        refreshing={this.state.refreshing}
                        onRefresh={() => this.order( 1)}
                        style={{backgroundColor: 'transparent'}}
                        />}>
                        <Carousel
                            ref={(c) => { this._carousel = c; }}
                            data={this.state.orders}
                            renderItem={this._renderItem}
                            sliderWidth={this.state.viewport.width}
                            itemWidth={this.state.viewport.width}
                            onSnapToItem={(index) => this.setState({ activeSlide: index })}
                        />
                    </ScrollView>
                </View >

            )
        }
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency,
        requestOrders: state.auth.requestOrders,
        inactiveOrders: state.auth.inactiveOrders,
        intransitOrders: state.auth.intransitOrders,
        receivedOrders: state.auth.receivedOrders,
        allOrders:state.auth.allOrders,
        user: state.auth.user
    }
}

const mapDispatchToProps = dispatch => {
    return({
        sendReceivedOrders: (orders) => {
            dispatch({
                type:RECEIVED_ORDERS,
                payload:orders
            })
        },
        sendInactiveOrders: (orders) => {
            dispatch({
                type:INACTIVE_ORDERS,
                payload:orders
            })
        },
        sendTransitOrders: (orders) => {
            dispatch({
                type:TRANSIT_ORDERS,
                payload:orders
            })
        },
        sendRequestOrders: (orders) => {
            dispatch({
                type:REQUEST_ORDERS,
                payload:orders
            })
        },
        sendAllOrders: (orders) => {
            dispatch({
                type:ALL_ORDERS,
                payload:orders
            })
        }
    })
}


export default connect(mapStateToProps, mapDispatchToProps)(OrdersComponent)
