import React from 'react'
import OrdersComponent from './OrdersComponent'
import {View, Text} from 'react-native'
import {connect}  from 'react-redux'
import styles from '../../../../../assets/css/style'

class Transit extends React.Component {

    render() {
        
        if (this.props.transitOrders.length > 0) {
            return (
                <OrdersComponent step={2} 
                    push={this.props.screenProps} 
                    navigation={this.props.navigation} 
                    orders={this.props.transitOrders}
                />
            )
        }
        
        return (
            <View style={styles.fromgroup}>
                <Text style={{textAlign:'center',
                fontSize:18,color:'black',marginLeft:10,
                fontFamily:'Montserrat-Regular', }}>
                    No request order
                </Text>
            </View>
        )
        
    }
}

const mapStateToProps = state => {
    return {
      transitOrders: state.auth.transitOrders
    }
}



export default connect(mapStateToProps, null)(Transit)
