import React from 'react'
import {View, Text} from 'react-native'
import OrdersComponent from './OrdersComponent'
import {connect}  from 'react-redux'
import styles from '../../../../../assets/css/style'

class Request extends React.Component {

    render() {

        if (this.props.requestOrders.length > 0) {
            return (
                <OrdersComponent step={1} 
                    push={this.props.screenProps} 
                    navigation={this.props.navigation} 
                    orders={this.props.requestOrders}
                />
            )
        }
        
        return (
            <View style={styles.fromgroup}>
                <Text style={{textAlign:'center',
                fontSize:18,color:'black',marginLeft:10,
                fontFamily:'Montserrat-Regular', }}>
                    No request order
                </Text>
            </View>
        )
        
    }
}

const mapStateToProps = state => {
    return {
      requestOrders: state.auth.requestOrders
    }
}


export default connect(mapStateToProps, null)(Request)
