import React from 'react'
import OrdersComponent from './OrdersComponent'
import {connect}  from 'react-redux'
import styles from '../../../../../assets/css/style'
import {View, Text} from 'react-native'
class Inactive extends React.Component {

    render() {

        if (this.props.inactiveOrders.length > 0) {
            return (
                <OrdersComponent step={4} 
                    push={this.props.screenProps} 
                    navigation={this.props.navigation} 
                    orders={this.props.inactiveOrders}
                />
            )
        }
        
        return (
            <View style={styles.fromgroup}>
                <Text style={{textAlign:'center',
                fontSize:18,color:'black',marginLeft:10,
                fontFamily:'Montserrat-Regular', }}>
                    No inactive order
                </Text>
            </View>
        )
       
    }
}

const mapStateToProps = state => {
    return {
      inactiveOrders: state.auth.inactiveOrders
    }
}



export default connect(mapStateToProps, null)(Inactive)
