import React from 'react'
import { Text, View, TextInput, TouchableOpacity , Alert} from 'react-native'
import ModalFilterPicker from 'react-native-modal-filter-picker'
import OrderSubmitting from '../../../Common/OrderSubmitting'
import styles from '../../../../../assets/css/style'
import { connect } from 'react-redux'
import axios from 'axios'


class AddAddresses extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isLoading: true,
            country_codes: [],
            countries: [],
            countryDatas: props.country_codes,
            address:props.address,
            selectedCountry: {},
            visible: false,
            visibleCountry: false,
            countryCode: 101,
            email: '',
            phone: '',
            zip: '',
            country: '',
            city: '',
            state: '',
            address_1: '',
            address_2: '',
            first_name: '',
            last_name: '',
            showCancel: false,
        }
    }

    checkAllfield() {
        if (!this.state.first_name) {
          return false
        }

        if (!this.state.last_name) {
          return false
        }

        if (!this.state.email) {
          return false
        }

        if (!this.state.phone) {
          return false
        }

        if (!this.state.selectedCountry.id) {
          return false
        }

        if (!this.state.address_1) {
          return false
        }

        if (!this.state.address_2) {
          return false
        }

        if (!this.state.city) {
          return false
        }

        if (!this.state.state) {
          return false
        }

        if (!this.state.country) {
          return false
        }

        if (!this.state.zip) {
          return false
        }

        return true
    }

    async _resetValues() {
        await this.setState({
            countryCode: 101,
            email: '',
            phone: '',
            zip: '',
            country: 'India',
            city: '',
            state: '',
            address_1: '',
            address_2: '',
            first_name: '',
            last_name: ''
        })

        return
    }

    

    async _reAssign() {
        try {
            var country_codes = []
            var countries = []
            var responses = this.state.countryDatas
            await responses.forEach(element => {
                country_codes.push({ key: element.id, label: element.name + '(' + element.dial_code + ')' })
                countries.push({ key: element.id, label: element.name })
            })
            
            var address = this.state.address
            
            await this.setState({
                country_codes: country_codes,
                countries: countries,
                email: address.email,
                first_name: address.first_name,
                last_name: address.last_name,
                country: address.country_data.name,
                phone: address.phone,
                zip: address.zip,
                city: address.city,
                state: address.state,
                address_1: address.address_1,
                address_2: address.address_2,
                selectedCountry: { id: address.country_data.id, name:address.country_data.name + '(' + address.country_data.dial_code + ')'},
                visible: false,
                isLoading: false
            })
            
        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            }) 
        }
    }

    _filterResult(id) {
        const result = this.state.countryDatas.find(element => element.id === id)
        return result
    }

    _onSelect = async (picked) => {
        try {
            let result = await this._filterResult(picked)
            
            this.setState({
                selectedCountry: { id: result.id, name:result.name + '(' + result.dial_code + ')'},
                visible: false
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                visible: false
            })
        }
    }

    _onSelectCountry = async (picked) => {
        try {
            let result = await this._filterResult(picked)
            this.setState({
                country:result.name,
                visibleCountry: false
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                visibleCountry: false
            })
        }
    }

    _allDatas() {
		const data = {
            email: this.state.email,
            first_name: this.state.first_name,
            last_name: this.state.last_name,
            phone: this.state.phone,
            zip: this.state.zip,
            city: this.state.city,
            state: this.state.state,
            country: this.state.country,
            address_1: this.state.address_1,
            address_2: this.state.address_2,
            countryCode: this.state.selectedCountry.id
		}
		return data
    }

    async _updateAddress(id) {
        this.setState({
            isLoading: true
        })
        try {

            var isValid = await this.checkAllfield()
            if (!isValid) {
                return
            }

            var data = await this._allDatas()

            let response = await axios.put('address/edit/' + id, data)
            this.props.AddreesedUpdated(response.data.data)

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            })
            await Alert.alert('Opps!', 'somthing went wrong')
        }
    }

    componentDidMount() {
        this._reAssign()
    }

    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {
            
            return (
                       
                <View style={[styles.card, styles.shadow]}>
                    
                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>First Name</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(first_name) => this.setState({first_name})}
                            value={this.state.first_name}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Last Name</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(last_name) => this.setState({last_name})}
                            value={this.state.last_name}
                        />
                    </View>
                    
                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Email</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(email) => this.setState({email})}
                            value={this.state.email}
                        />
                    </View>

                    <View style={styles.fromgroup}>

                        <View>
                            <Text style={styles.inputlabel}>Phone</Text>
                        </View>
                        <View View style={styles.country_phone}>
                            <View style={{width:'35%'}}>
                                <TouchableOpacity onPress={() => this.setState({ visible: true })}>
                                    <Text style={{ fontSize: 16, color: '#5d5d5d', textAlign: 'left', width: '100%', }} >{this.state.selectedCountry.name ? this.state.selectedCountry.name : 'Country'}</Text>
                                </TouchableOpacity >
                                <ModalFilterPicker
                                        visible={this.state.visible}
                                        onSelect={this._onSelect}
                                        onCancel={() => this.setState({ visible: false })}
                                        options={this.state.country_codes}
                                />
                            </View>

                            <View style={{width:'65%'}}>
                                <TextInput style={[styles.inputbox,styles.borderWidth0]}
                                        placeholderTextColor="#878787"
                                        underlineColorAndroid='rgba(0, 0, 0,0)'
                                        keyboardType = 'phone-pad'
                                        onChangeText={(phone) => this.setState({phone})}
                                        value={this.state.phone}
                                />
                            </View>
                        </View>
                    
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Address1</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(address_1) => this.setState({address_1})}
                            value={this.state.address_1}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Address2</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(address_2) => this.setState({address_2})}
                            value={this.state.address_2}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>City</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(city) => this.setState({city})}
                            value={this.state.city}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>State</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(state) => this.setState({state})}
                            value={this.state.state}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Country</Text>
                        </View>
                        <TouchableOpacity onPress={() => this.setState({ visibleCountry: true })} style={styles.gpcountery}>
                            <Text style={{ fontSize: 16, color: '#5d5d5d', textAlign: 'left', width: '100%', paddingLeft: 25, }} >{this.state.country? this.state.country: 'Country'}</Text>
                        </TouchableOpacity >
                    </View>
                  
                    <ModalFilterPicker
                        visible={this.state.visibleCountry}
                        onSelect={this._onSelectCountry}
                        onCancel={() => this.setState({ visibleCountry: false })}
                        options={this.state.countries}
                    />

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Zip Code</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            keyboardType = 'number-pad'
                            onChangeText={(zip) => this.setState({zip})}
                            value={this.state.zip}
                        />

                    </View>

                    <View style={styles.fromgroup}>
                        <TouchableOpacity onPress={() => this._updateAddress(this.state.address.id)}>
                            <Text style={styles.Searchbtn}>Update Address</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.fromgroup}>
                        <TouchableOpacity onPress={() => this.props.onCancle()}>
                            <Text style={styles.Searchbtn}>Cancel</Text>
                        </TouchableOpacity>
                    </View>

                </View>
            )
        }
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency,
        user: state.auth.user
    }
}

export default connect(mapStateToProps, null)(AddAddresses)
