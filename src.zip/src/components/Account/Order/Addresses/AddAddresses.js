import React from 'react'
import { Text, View, TextInput, TouchableOpacity , Alert} from 'react-native'
import ModalFilterPicker from 'react-native-modal-filter-picker'
import OrderSubmitting from '../../../Common/OrderSubmitting'
import styles from '../../../../../assets/css/style'
import { connect } from 'react-redux'
import axios from 'axios'


class AddAddresses extends React.Component {
    
    constructor(props) {
        super(props)
        this.state = {
            isLoading: true,
            country_codes: [],
            countries: [],
            countryDatas: [],
            selectedCountry: {},
            visible: false,
            visibleCountry: false,
            countryCode: 101,
            email: '',
            phone: '',
            zip: '',
            country: '',
            city: '',
            state: '',
            address_1: '',
            address_2: '',
            first_name: '',
            last_name: '',
            showCancel: false,
        }

        this._resetValues = this._resetValues.bind(this)
    }

    isValid(data) {
        var isValidData = true
        for (let i = 0; i < Object.keys(data).length; i++) {
          if (!data[Object.keys(data)[i]]) {
            this[Object.keys(data)[i]].focus()
            isValidData = false
            break
          }
        }
        return isValidData
    }

    checkAllfield() {
        const data = {
            first_name: this.state.first_name,
            last_name: this.state.last_name,
            email: this.state.email,
            phone: this.state.phone,
            address_1: this.state.address_1,
            address_2: this.state.address_2,
            zip: this.state.zip,
            city: this.state.city,
            state: this.state.state,
        }
       
        
        if (!this.isValid(data)) {
            return false
        }

        if (!this.state.country) {
            Alert.alert('Oops!', 'select your country code')
            return false
        }

        if (!this.state.selectedCountry.id) {
            Alert.alert('Oops!', 'select your country')
            return false
        }

        return true
    }

    _resetValues() {
        this.setState({
            countryCode: 101,
            email: '',
            phone: '',
            zip: '',
            country: 'India',
            city: '',
            state: '',
            address_1: '',
            address_2: '',
            first_name: '',
            last_name: ''
        })

        return
    }

     _reAssign() {
        
        try {
            let country_codes = []
            let countries = []
            let responses = this.props.country_codes
             responses.forEach(element => {
                country_codes.push({ key: element.id, label: element.name + '(' + element.dial_code + ')' })
                countries.push({ key: element.id, label: element.name })
            })
            let user = this.props.user
            
            if (user.country_code) {
                 this._onSelect(user.country_code.id)
            }

            this.setState({
                country_codes: country_codes,
                countries: countries,
                email: user.email_update ? user.email_update : user.email,
                first_name: user.first_name,
                last_name: user.last_name,
                country: user.country,
                phone: user.phone,
                countryDatas: this.props.country_codes,
                isLoading: false
            })

            console.log(this.state);
            

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false
            }) 
        }
    }

    _filterResult(id) {
        const result = this.props.country_codes.find(element => element.id === id)
        return result
    }

    _onSelect = async (picked) => {
        try {
            let result = await this._filterResult(picked)
           
            this.setState({
                selectedCountry: { id: result.id, name:result.name + '(' + result.dial_code + ')'},
                visible: false
            })
            
            return
        } catch (error) {
            // console.log(error)
            this.setState({
                visible: false
            })
        }
    }

    _onSelectCountry = async (picked) => {
        try {
            let result = await this._filterResult(picked)
            this.setState({
                country:result.name,
                visibleCountry: false
            })
        } catch (error) {
            // console.log(error)
            this.setState({
                visibleCountry: false
            })
        }
    }

    _allDatas() {
        
		const data = {
            email: this.state.email,
            first_name: this.state.first_name,
            last_name: this.state.last_name,
            phone: this.state.phone,
            zip: this.state.zip,
            city: this.state.city,
            state: this.state.state,
            country: this.state.country,
            address_1: this.state.address_1,
            address_2: this.state.address_2,
            countryCode: this.state.selectedCountry.id
		}
		return data
    }
    
    _saveAddress() {
        this.setState({
            isLoading: true
        })
        const data = {
            // email: this.state.email,
            // first_name: this.state.first_name,
            // last_name: this.state.last_name,
            // phone: this.state.phone,
            // zip: this.state.zip,
            // city: this.state.city,
            // state: this.state.state,
            // country: this.state.country,
            // address_1: this.state.address_1,
            // address_2: this.state.address_2,
            // countryCode: this.state.selectedCountry.id
        }
        alert(this.state.isLoading)
        axios.post('address/add', data).then(response => {
            this._resetValues()
            this.props.AddreesedSaved(response.data.data)
        }).catch(error => {
            console.log(error)
            this.setState({
                isLoading: false
            })
            Alert.alert('Opps!', 'somthing went wrong')
        })
    }

    componentWillUnmount() {
        this._resetValues()
    }

    componentDidMount() {
        
        this._reAssign()
    }

    _checkData(data){
        this.setState({
            address_1: 'fffff'
        })
        
    }

    render() {
        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {

            var cancleButton = <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.props.onCancle()}>
                    <Text style={styles.Searchbtn}>Cancel</Text>
                </TouchableOpacity>
            </View>
            
            return (
                       
                <View style={[styles.card, styles.shadow]}>
                    
                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>First Name</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(first_name) => this.setState({first_name})}
                            value={this.state.first_name}
                            ref={input => { this.first_name = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Last Name</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(last_name) => this.setState({last_name})}
                            value={this.state.last_name}
                            ref={input => { this.last_name = input}}
                        />
                    </View>
                    
                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Email</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(email) => this.setState({email})}
                            value={this.state.email}
                            ref={input => { this.email = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Phone</Text>
                        </View>
                        <View style={styles.country_phone}>  
                            <View style={{width:'35%'}}>
                                <TouchableOpacity onPress={() => this.setState({ visible: true })}>
                                    <Text style={{ fontSize: 16, color: '#5d5d5d', textAlign: 'left', width: '100%',}} >{this.state.selectedCountry.name ? this.state.selectedCountry.name : 'Country'}</Text>
                                </TouchableOpacity >
                                <ModalFilterPicker
                                visible={this.state.visible}
                                onSelect={this._onSelect}
                                onCancel={() => this.setState({ visible: false })}
                                options={this.state.country_codes}
                            />
                            </View>
                        
                            <View style={{width:'65%'}}>
                                <TextInput style={[styles.inputbox,styles.borderWidth0]}
                                    placeholderTextColor="#878787"
                                    underlineColorAndroid='rgba(0, 0, 0,0)'
                                    keyboardType = 'phone-pad'
                                    onChangeText={(phone) => this.setState({phone})}
                                    value={this.state.phone}
                                    ref={input => { this.phone = input}}
                                />
                            </View>
                        </View>
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Address1</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(address_1) => this.setState({address_1})}
                            value={this.state.address_1}
                            ref={input => { this.address_1 = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Address2</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(address_2) => this.setState({address_2})}
                            value={this.state.address_2}
                            ref={input => { this.address_2 = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>City</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(city) => this.setState({city})}
                            value={this.state.city}
                            ref={input => { this.city = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>State</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            onChangeText={(state) => this.setState({state})}
                            value={this.state.state}
                            ref={input => { this.state = input}}
                        />
                    </View>

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Country</Text>
                        </View>
                        <TouchableOpacity onPress={() => this.setState({ visibleCountry: true })} style={styles.gpcountery}>
                            <Text style={{ fontSize: 16, color: '#5d5d5d', textAlign: 'left', width: '100%', paddingLeft: 25, }} >{this.state.country? this.state.country: 'Country'}</Text>
                        </TouchableOpacity >
                    </View>
                  
                    <ModalFilterPicker
                        visible={this.state.visibleCountry}
                        onSelect={this._onSelectCountry}
                        onCancel={() => this.setState({ visibleCountry: false })}
                        options={this.state.countries}
                    />

                    <View style={styles.fromgroup}>
                        <View>
                            <Text style={styles.inputlabel}>Zip Code</Text>
                        </View>
                        <TextInput style={styles.inputbox}
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                            keyboardType = 'number-pad'
                            onChangeText={(zip) => this.setState({zip})}
                            value={this.state.zip}
                            ref={input => { this.zip = input}}
                        />

                    </View>

                    <View style={styles.fromgroup}>
                        <TouchableOpacity onPress={() => this._saveAddress()}>
                            <Text style={styles.Searchbtn}>Save Address</Text>
                        </TouchableOpacity>
                    </View>

                    {this.props.showCancel ? cancleButton : null}

                </View>
            )
        }
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency,
        user: state.auth.user
    }
}

export default connect(mapStateToProps, null)(AddAddresses)
