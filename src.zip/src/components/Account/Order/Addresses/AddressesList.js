import React from 'react';
import {View, Image, TouchableOpacity, Alert} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../../assets/css/style';
import {connect} from 'react-redux';
import {Content, Text} from 'native-base';
import {STORAGE_URL} from '../../../../config/env';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import axios from 'axios';

class AddressesList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      addresses: props.addresses,
      currentSelected: 0,
    };

    this._handleDelete = this._handleDelete.bind(this);
    this._handleEdit = this._handleEdit.bind(this);

    this._handleAddMore = this._handleAddMore.bind(this);
  }

  async _deleteAddrees(index) {
    this.setState({
      isLoading: true,
    });

    try {
      var id = this.state.addresses[index].id;
      await axios.delete('address/delete/' + id);
      var stateaddresses = this.state.addresses.filter(
        (address, arrayindex) => {
          return arrayindex !== index;
        },
      );

      this.setState({
        addresses: stateaddresses,
        isLoading: false,
      });

      this.props.onDeleteAddress(index);
    } catch (error) {
      // console.log(error)
      Alert.alert('Opps!', 'somthing went wrong');
      this.setState({
        isLoading: false,
      });
    }
  }

  _handleDelete(index) {
    Alert.alert(
      'Are you sure?',
      'Are you sure want delete this address?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'Okay', onPress: () => this._deleteAddrees(index)},
      ],
      {cancelable: false},
    );
  }

  _handleEdit(index) {
    this.props.onEditAddress(index);
    return;
  }

  _selectAddress(index) {
    this.setState({
      currentSelected: index,
    });

    this.props.onChekedAddress(index);
  }

  _handleAddMore() {
    this.props.addMore(false);
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var add_more = (
        <View style={{justifyContent: 'center', alignItems: 'center'}}>
          <TouchableOpacity
            style={{
              backgroundColor: '#660165',
              paddingVertical: 10,
              width: 120,
              borderRadius: 6,
              overflow: 'hidden',
            }}
            onPress={this._handleAddMore}>
            <Text style={{color: '#fff', textAlign: 'center', fontSize: 16}}>
              Add More
            </Text>
          </TouchableOpacity>
        </View>
      );
      return (
        <View style={[styles.card, styles.shadow]}>
          {this.state.addresses.map((address, index) => {
            return (
              <Content key={index}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'column',
                    borderBottomWidth: 1,
                    borderColor: '#ccc',
                    marginBottom: 10,
                  }}>
                  <View
                    style={{
                      width: '100%',
                      flexDirection: 'row',
                      justifyContent: 'flex-start',
                    }}>
                    <View>
                      <TouchableOpacity
                        style={{marginRight: 5}}
                        onPress={() => this._selectAddress(index)}>
                        <Image
                          style={styles.fitImage}
                          source={{
                            uri:
                              index == this.state.currentSelected
                                ? STORAGE_URL + 'mobileapp/chaked.png'
                                : STORAGE_URL + 'mobileapp/unchaked.png',
                          }}
                          resizeMode="cover"
                          style={{height: 30, width: 30}}
                        />
                      </TouchableOpacity>
                    </View>
                    <View>
                      <Text>
                        {address.first_name} {address.last_name}
                      </Text>
                      <Text>
                        {address.address_1}, {address.address_2}
                      </Text>
                      <Text>{address.city}</Text>
                      <Text>
                        {address.state} {address.zip_code}
                      </Text>
                      <Text>{address.country_data.name}</Text>
                    </View>
                  </View>

                  <View
                    style={{
                      width: '100%',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginVertical: 10,
                    }}>
                    <View>
                      <TouchableOpacity
                        style={[
                          styles.paymentsmode,
                          styles.payments_address_del_btn,
                        ]}
                        onPress={() => this._handleDelete(index)}>
                        <FontAwesome
                          name="trash"
                          size={25}
                          style={{color: '#fff'}}
                        />
                        <Text style={{color: '#fff'}}>Delete</Text>
                      </TouchableOpacity>
                    </View>

                    <View>
                      <TouchableOpacity
                        style={[
                          styles.paymentsmode,
                          styles.payments_address_edit_btn,
                        ]}
                        onPress={() => this._handleEdit(index)}>
                        <FontAwesome
                          name="edit"
                          size={25}
                          style={{color: '#fff'}}
                        />
                        <Text style={{color: '#fff'}}>Edit</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
                {this.state.addresses.length - 1 == index ? add_more : null}
              </Content>
            );
          })}
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(AddressesList);
