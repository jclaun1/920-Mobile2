import React, { Component } from 'react'
import {View, Text, Image } from 'react-native'

import styles from '../../../../../../assets/css/style'
import { connect } from 'react-redux'

class TravellerOrderDetails extends Component {

    render() {
        var order_data = this.props.order
        var currency = this.props.currency

        return (
                <View style={[styles.card, styles.shadow]}>
                    <View style={{ width: '100%', marginBottom: 10, }}>
                        <Text style={styles.prodectname}>{order_data.name_item_lm}</Text>
                        <Image style={styles.fitImage} source={{
                            uri: order_data.images[0]
                        }}
                            resizeMode='cover'
                            style={{ height: 200, }}
                        />
                    </View>
                    <View style={{ marginVertical: 10, flexDirection: 'row', justifyContent: 'space-between', }}>
                        <Text style={{ fontSize: 16, fontWeight: '600', color: '#000', }}>Order:#{order_data.invoiceID}</Text>
                        <Text style={{ fontSize: 16, fontWeight: '600', color: '#000', }}> {order_data.paymentDate}</Text>
                    </View>
                    <View style={{ marginVertical: 10, }}>
                        <View style={styles.pricefinal}>
                            <Text style={styles.priceall}>Particulars</Text>
                            <Text style={[styles.priceall]}>Amount</Text>
                        </View>
                        <View style={styles.pricefinal}>
                            <Text style={styles.priceall}>Item Price</Text>
                            <Text style={[styles.priceall, styles.colorpurple]}>{currency} {order_data.item_price}</Text>
                        </View>
                        <View style={styles.pricefinal}>
                            <Text style={styles.priceall}>Quantity</Text>
                            <Text style={[styles.priceall, styles.colorpurple]}>{order_data.quantity}</Text>
                        </View>
                        <View style={styles.pricefinal}>
                            <Text style={styles.priceall}>Traveller Fee</Text>
                            <Text style={[styles.priceall, styles.colorpurple]}>{currency} {order_data.delivery_fee}</Text>
                        </View>
                        <View style={styles.hrborder}></View>
                        <View style={styles.pricefinal}>
                            <Text style={styles.priceall}>Total</Text>
                            <Text style={[styles.priceall, styles.colorpurple]}>{currency} {order_data.subTotal}</Text>
                        </View>
                    </View>
                </View>

        )
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency
    }
}

export default connect(mapStateToProps, null)(TravellerOrderDetails)
