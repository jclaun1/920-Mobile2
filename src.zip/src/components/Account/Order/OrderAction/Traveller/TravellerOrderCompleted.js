import React, {Component} from 'react';
import {View, Text, ScrollView, Image} from 'react-native';
import styles from '../../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../../config/env';
import {connect} from 'react-redux';

class TravellerOrderCompleted extends Component {
  render() {
    var order_data = this.props.order;
    return (
      <View style={styles.container}>
        <ScrollView style={{width: '100%'}}>
          <View style={[styles.card, styles.shadow]}>
            <View
              style={{
                width: '100%',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                source={{
                  uri: STORAGE_URL + 'static/assets/images/box-gift.png',
                }}
                resizeMode="cover"
                style={{height: 97, width: 130}}
              />
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: '600',
                  color: '#660165',
                  marginVertical: 8,
                  textAlign: 'center',
                }}>
                Order Completed !
              </Text>
            </View>

            <Text style={{fontSize: 15, fontWeight: '600', marginVertical: 10}}>
              Dear {order_data.traveller},
            </Text>
            <Text>
              You have sucessfully delivered
              <Text style={{fontSize: 15, fontWeight: '600'}}>
                {order_data.item_name}{' '}
              </Text>
              to{order_data.name} on
              <Text style={{fontSize: 15, fontWeight: '600'}}>
                {order_data.delivered_At} and earned
              </Text>
              <Text style={{fontSize: 15, fontWeight: '600'}}>
                {this.props.currency} {order_data.delivery_fee}
              </Text>
              . We hope to see you again.
            </Text>
            <Text style={{marginTop: 20}}>Thanks</Text>
            <Text>The Flypur Team</Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(TravellerOrderCompleted);
