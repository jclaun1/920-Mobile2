import React, { Component } from 'react';
import { View, TouchableOpacity, Text , TextInput} from 'react-native'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import styles from '../../../../../assets/css/style'

export default class TravellerFeedBack extends Component {

    render() {
        return (
            <View style={styles.container}>
                <View style={[styles.card, styles.shadow]}>
                    <Text>Please rate your experience with Buyer .</Text>
                    <View style={styles.FeedBackbox}>
                        <View>
                            <Text style={{ fontSize: 15, fontWeight: '600', }}>Excellent</Text>
                        </View>
                        <View style={styles.retingstarbox}>
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                        </View>
                    </View>
                    <View style={styles.FeedBackbox}>
                        <View>
                            <Text style={{ fontSize: 15, fontWeight: '600', }}>Good</Text>
                        </View>
                        <View style={styles.retingstarbox}>
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                        </View>
                    </View>
                    <View style={styles.FeedBackbox}>
                        <View> 
                            <Text style={{ fontSize: 15, fontWeight: '600', }}>Okay</Text>
                        </View>
                        <View style={styles.retingstarbox}>
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                        </View>
                    </View>
                    <View style={styles.FeedBackbox}>
                        <View>
                            <Text style={{ fontSize: 15, fontWeight: '600', }}>Poor</Text>
                        </View>
                        <View style={styles.retingstarbox}>
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                        </View>
                    </View>
                    <View style={styles.FeedBackbox}>
                        <View>
                            <Text style={{ fontSize: 15, fontWeight: '600', }}>Terrible</Text>
                        </View>
                        <View style={styles.retingstarbox}>
                            <FontAwesome name="star" size={18} style={{ color: '#ffa500' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                            <FontAwesome name="star" size={18} style={{ color: '#ccc' }} />
                        </View>
                    </View>
                    <View>
                        <TextInput style={{ height: 50, borderWidth: 1, padding: 10, }}
                            placeholder="Excellent Traveller"
                            placeholderTextColor="#878787"
                            underlineColorAndroid='rgba(0, 0, 0,0)'
                        />

                    </View>
                    <View style={styles.changepasswordfromgroup}>
                        <TouchableOpacity>
                            <Text style={styles.Searchbtn}>SEND FEEDBACK </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        );
    }
}



