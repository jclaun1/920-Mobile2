import React, { Component } from 'react'
import { View} from 'react-native'
import StepIndicator from 'react-native-step-indicator'

import styles from '../../../../../assets/css/style'

const firstIndicatorStyles = {
    stepIndicatorSize: 30,
    currentStepIndicatorSize: 35,
    separatorStrokeWidth: 3,
    currentStepStrokeWidth: 4,
    separatorFinishedColor: '#660165',
    separatorUnFinishedColor: '#660165',
    stepIndicatorFinishedColor: '#660165',
    stepIndicatorUnFinishedColor: '#660165',
    stepIndicatorCurrentColor: '#ffffff',
    stepIndicatorLabelFontSize: 15,
    currentStepIndicatorLabelFontSize: 15,
    stepIndicatorLabelCurrentColor: '#000000',
    stepIndicatorLabelFinishedColor: '#ffffff',
    stepIndicatorLabelUnFinishedColor: 'rgba(255,255,255,0.5)',
    labelColor: '#666666',
    labelSize: 12,
    currentStepLabelColor: '#660165'
}

export default class StepIndecator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentPage: props.step
        }
    }
    render() {
        return (
            <View style={[styles.cardslider, styles.shadow]}>
                <View style={styles.stepIndicator}>
                    <StepIndicator
                        stepCount={4}
                        customStyles={firstIndicatorStyles}
                        currentPosition={this.props.step}
                        labels={["Offer Made", "Offer Accepted", "Payment Holded", "Order Completed"]}
                    />
                </View>
            </View>
        )
    }
}



