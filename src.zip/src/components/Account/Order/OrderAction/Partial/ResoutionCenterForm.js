import React, {Component} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import styles from '../../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../../config/env';
import axios from 'axios';

export default class ResoutionCenterForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      slug: null,
      isLoading: true,
      resoution_type: 1,
      resoution_text: '',
    };
  }

  async _handleSubmit(slug, invoiceID) {
    var reason;
    this.setState({
      isLoading: true,
    });

    if (this.state.resoution_type == 1) {
      reason = 'Traveller denied to bring your item or cancelled his trip.';
    } else if (this.state.resoution_type == 2) {
      reason = 'Traveller brought broken or defective item.';
    } else {
      reason = this.state.resoution_text;
    }

    try {
      let response = await axios.post(
        'resoution/create/' + slug + '/' + invoiceID,
        {reason: reason},
      );
      this.setState({
        isLoading: false,
        resoution_text: '',
      });
      this.props.onTicketCreated(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  render() {
    var textForm = (
      <View style={styles.fromgroup}>
        <View style={{width: '100%'}}>
          <TextInput
            style={styles.inputdescription}
            placeholder="Type your Problem"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            value={this.state.resoution_text}
            onChangeText={resoution_text => this.setState({resoution_text})}
          />
        </View>
      </View>
    );
    var order = this.props.order;
    return (
      <View style={styles.container}>
        <ScrollView style={{width: '100%'}}>
          <View style={[styles.card, styles.shadow]}>
            <View style={styles.optionboxchat}>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#660165',
                  marginBottom: 5,
                  fontSize: 18,
                  fontFamily: 'Montserrat-semiBold',
                }}>
                Resoution Center
              </Text>
              <Image
                source={{
                  uri: STORAGE_URL + 'static/assets/images/light.png',
                }}
                resizeMode="contain"
                style={{height: 98, width: 130}}
              />
              <Text
                style={{
                  fontSize: 15,
                  textAlign: 'center',
                  fontFamily: 'Montserrat-semiBold',
                  marginVertical: 10,
                }}>
                What issues are you having with this order?
              </Text>
            </View>

            <View style={styles.hrborder} />
            <View style={styles.optionboxchat}>
              <View
                style={{
                  flexDirection: 'row',
                  marginVertical: 10,
                  justifyContent: 'flex-start',
                  width: '100%',
                }}>
                <TouchableOpacity
                  style={{marginRight: 5}}
                  onPress={() => this.setState({resoution_type: 1})}>
                  <Image
                    source={{
                      uri:
                        this.state.resoution_type == 1
                          ? STORAGE_URL + 'mobileapp/chaked.png'
                          : STORAGE_URL + 'mobileapp/unchaked.png',
                    }}
                    resizeMode="cover"
                    style={{height: 30, width: 30}}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    textAlign: 'left',
                    fontSize: 15,
                    color: '#000',
                    fontFamily: 'Montserrat-semiBold',
                  }}>
                  Traveller denied to bring your item or cancelled his trip.
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  marginVertical: 10,
                  justifyContent: 'flex-start',
                  width: '100%',
                }}>
                <TouchableOpacity
                  style={{marginRight: 5}}
                  onPress={() => this.setState({resoution_type: 2})}>
                  <Image
                    source={{
                      uri:
                        this.state.resoution_type == 2
                          ? STORAGE_URL + 'mobileapp/chaked.png'
                          : STORAGE_URL + 'mobileapp/unchaked.png',
                    }}
                    resizeMode="cover"
                    style={{height: 30, width: 30}}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    textAlign: 'left',
                    fontSize: 15,
                    color: '#000',
                    fontFamily: 'Montserrat-semiBold',
                  }}>
                  Traveller brought broken or defective item.
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  marginVertical: 10,
                  justifyContent: 'flex-start',
                  width: '100%',
                }}>
                <TouchableOpacity
                  style={{marginRight: 5}}
                  onPress={() => this.setState({resoution_type: 3})}>
                  <Image
                    source={{
                      uri:
                        this.state.resoution_type == 3
                          ? STORAGE_URL + 'mobileapp/chaked.png'
                          : STORAGE_URL + 'mobileapp/unchaked.png',
                    }}
                    resizeMode="cover"
                    style={{height: 30, width: 30}}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    textAlign: 'left',
                    fontSize: 15,
                    color: '#000',
                    fontFamily: 'Montserrat-semiBold',
                  }}>
                  Other
                </Text>
              </View>
            </View>

            {this.state.resoution_type == 3 ? textForm : null}

            <View style={styles.fromgroup}>
              <TouchableOpacity
                onPress={() => this._handleSubmit(order.slug, order.invoiceID)}>
                <Text style={styles.Searchbtn}>Submit Ticket</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.props.onProblemForm(false)}>
                <Text style={styles.Searchbtn}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}
