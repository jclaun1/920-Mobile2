import React from 'react'
import {  Text, View, Image, ScrollView, TouchableOpacity } from 'react-native'

import styles from '../../../../../../assets/css/style'


export default class Invoice extends React.Component {

    render() {
        return (
            <View style={styles.container}>
            <ScrollView style={{width:'100%'}}>
            <View style={{}}>
                <Text style={styles.allheading}>INVOICE</Text>
                    <View style={styles.invoice_main}>
                        <View style={styles.invoice_row_hor}>
                            <Text style={{fontSize:18,color:'#660165',fontWeight:'600',}}>FLYPUR TECHLABS PVT LTD</Text>
                            <View>
                                <Image                                   
                                    source={{uri: 'https://flypur.s3.ap-south-1.amazonaws.com/static/assets/images/logo.png'}}
                                    style={{width: 50, height: 50,overflow:'hidden'}}
                                />
                            </View>
                        </View>
                        <View style={styles.invoice_row_hor}>
                            <Text style={{fontSize:17,color:'#000',fontWeight:'600'}}>Invoice: #12345678</Text>
                            <Text>22 Aug , 2018</Text>
                        </View>
                        <View style={styles.invoice_row_hor}>
                          <Text style={{fontSize:17,color:'#ccc'}}>INVOICE</Text>
                          <Text style={{fontSize:17,color:'#000',fontWeight:'600'}}>Invoice To</Text>
                          
                        </View>
                        <View style={styles.invoice_row_hor}>
                          <Text>+19-9911287266</Text>
                          <Text>Vipin Kumar</Text>
                        </View>

                        <View style={styles.invoice_row_hor}>
                          <Text>office@flypur.com</Text>
                          <Text>New Delhi</Text>
                        </View>

                        <View style={styles.invoice_row_hor}>
                          <Text>C-155 Nirman Vihar Delhi-110092</Text>
                          <Text>Delhi</Text>
                        </View>

                        <View style={styles.invoice_row_hor}>
                          <Text>GSTIN : 07AADCF3457A1Z1</Text>
                          <Text>Delhi</Text>
                        </View>

                        <View style={styles.invoice_row_hor}>
                          <Text>CIN : U72900DL2018PTC331292</Text>
                          <Text>India</Text>
                        </View>


                        {/* invoice tabel */}
                        <View style={styles.invoice_row_hor}>
                            <View style={[styles.tabel_wid_40,styles.bgpurple]}>
                                <Text style={[styles.tabel_head]}>Description</Text>
                            </View>
                            <View style={[styles.tabel_wid_20,styles.bgpurple]}>
                                <Text style={[styles.tabel_head]}>Quantity</Text>
                            </View>
                            <View style={[styles.tabel_wid_20,styles.bgpurple]}> 
                                <Text style={[styles.tabel_head]}>Unit Price</Text>
                            </View>
                            <View style={[styles.tabel_wid_20,styles.bgpurple]}>
                                <Text style={[styles.tabel_head]}>Cost</Text>
                            </View>
                        </View>

                        {/* invoice desc and price */}
                    
                        <View style={styles.invoice_des_row_hor}>
                          <View style={[styles.tabel_wid_40]}>
                            <Text style={[styles.tabel_des,]}>Bosch Gsb 500W 10 Re Professional Too Kit Blue Pack Of 100</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>1</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>₹3,469.00</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm]}>₹3,469.00</Text>
                          </View>
                        </View>
                        

                    <View style={styles.invoice_des_row_hor}>
                          <View style={[styles.tabel_wid_40]}>
                            <Text style={[styles.tabel_des,]}> </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}> </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>SubTotal</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm]}>₹3,469.00</Text>
                          </View>
                        </View>


                        <View style={styles.invoice_des_row_hor}>
                          <View style={[styles.tabel_wid_40]}>
                            <Text style={[styles.tabel_des,]}>Traveller & Service Fee</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>  </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}> </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm]}>₹331.52</Text>
                          </View>
                        </View>




                        <View style={styles.invoice_des_row_hor}>
                          <View style={[styles.tabel_wid_40]}>
                            <Text style={[styles.tabel_des,]}>Taxes</Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>  </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>  </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm]}>₹59.67</Text>
                          </View>
                        </View>

                        <View style={styles.invoice_des_row_hor}>
                          <View style={[styles.tabel_wid_40]}>
                            <Text style={[styles.tabel_des,]}> </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}> </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm,]}>Total </Text>
                          </View>
                          <View style={[styles.tabel_wid_20]}>
                            <Text style={[styles.tabel_des_sm]}>₹3,860.19</Text>
                          </View>
                        </View>
                        <Text style={{marginTop:20,}}>Thanks For Your Order : )</Text>
                        <Text>Sincerely Yours,</Text>
                        <Text>Team Flypur </Text>

                        <View style={{marginTop:40,justifyContent:'center',alignItems:'center'}}>
                            <TouchableOpacity >
                                <Text style={styles.invoice_print_btn}>Print</Text>
                            </TouchableOpacity>
                        </View>
                    </View>

                </View>
                </ScrollView>
            </View>
            
        );

    }
}

