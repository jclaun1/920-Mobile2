import React, {Component} from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TextInput,
  TouchableOpacity,
  WebView,
} from 'react-native';
import styles from '../../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../../config/env';
import {connect} from 'react-redux';
import axios from 'axios';
import moment from 'moment';
import HTMLView from 'react-native-htmlview';

class ResoutionCenter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      order: props.order,
      sendText: '',
    };
  }

  toupercasename(text) {
    return text;
    text.replace(/^[a-z]/, x => {
      return x.toUpperCase();
    });
  }

  async _handleSend(ticket) {
    if (!this.state.sendText) {
      return;
    }

    try {
      var userdata = this.props.user;
      var first_name = userdata.first_name;
      var last_name = userdata.last_name;
      const datasend = {
        message: this.state.sendText,
        avatar: userdata.avatar,
        senderName: first_name + ' ' + last_name,
        created_at: {date: moment().format()},
        isSame: true,
      };
      this.setState({sendText: ''});

      this.state.order.messages.push(datasend);

      await axios.post('send/message/resoution/' + ticket, {
        message: this.state.sendText,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _messageElement(message, index) {
    if (!message.isSame) {
      var admintext;
      if (index == 0) {
        admintext = <HTMLView value={message.message} />;
      } else {
        admintext = (
          <Text
            style={{
              fontSize: 15,
              color: '#fff',
              fontFamily: 'Montserrat-regular',
            }}>
            {message.message}
          </Text>
        );
      }
      return (
        <View style={styles.help_user} key={index}>
          <View style={{flexDirection: 'row', justifyContent: 'flex-start'}}>
            <View style={{width: 60, marginRight: 10}}>
              <Image
                source={{
                  uri: STORAGE_URL + 'static/assets/images/Help.png',
                }}
                resizeMode="cover"
                style={{height: 60, width: 60}}
              />
            </View>
            <View style={{flexDirection: 'column', maxWidth: 270}}>
              <View
                style={{
                  width: '98%',
                  marginBottom: 5,
                  backgroundColor: '#c9e5c6',
                  borderRadius: 6,
                  paddingHorizontal: 10,
                  paddingVertical: 10,
                  overflow: 'hidden',
                }}>
                {admintext}
              </View>
              <Text style={{fontFamily: 'Montserrat-semiBold', fontSize: 14}}>
                {moment(message.created_at.date).format('DD MMM, YYYY h:mm A')}
              </Text>
            </View>
          </View>
        </View>
      );
    } else {
      return (
        <View style={styles.help_user} key={index}>
          <View style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
            <View
              style={{
                flexDirection: 'column',
                maxWidth: '80%',
                justifyContent: 'flex-end',
              }}>
              <View
                style={{
                  marginBottom: 5,
                  backgroundColor: '#660165',
                  borderRadius: 6,
                  paddingHorizontal: 10,
                  paddingVertical: 10,
                  overflow: 'hidden',
                  maxWidth: '100%',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: 15,
                    color: '#fff',
                    fontFamily: 'Montserrat-regular',
                    maxWidth: '100%',
                  }}>
                  {message.message}
                </Text>
              </View>
              <Text
                style={{
                  fontFamily: 'Montserrat-semiBold',
                  fontSize: 14,
                  color: '#000',
                }}>
                {moment(message.created_at.date).format('DD MMM, YYYY h:mm A')}
              </Text>
            </View>
          </View>
        </View>
      );
    }
  }
  render() {
    var newOrderData = this.state.order;

    return (
      <View style={styles.container}>
        <View style={[styles.card, styles.shadow]}>
          <View style={styles.chatinfo_help}>
            <ScrollView
              ref={ref => (this.scrollView = ref)}
              onContentSizeChange={() =>
                this.scrollView.scrollToEnd({animated: true})
              }>
              <View style={styles.ticket_del_box}>
                <Text style={styles.allheading}>Ticket Details</Text>
                <Text>Created on: {newOrderData.resoution_created_at} </Text>
                <View>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginVertical: 5,
                    }}>
                    <Text style={{fontFamily: 'Montserrat-regular'}}>
                      Tikcet ID: {newOrderData.ticket}
                    </Text>
                    <Text style={{fontFamily: 'Montserrat-regular'}}>
                      Status:
                      <Text
                        style={{
                          color: '#52ad08',
                          fontFamily: 'Montserrat-regular',
                        }}>
                        {newOrderData.isResolved ? 'Closed' : 'Open'}
                      </Text>
                      <Text style={{fontFamily: 'Montserrat-regular'}}>
                        {newOrderData.isResolved ? 'Closed At:' : ''}{' '}
                        {newOrderData.isResolved ? newOrderData.closed_at : ''}
                      </Text>
                    </Text>
                  </View>
                  <Text>Reason: {newOrderData.reason}</Text>
                  <Text>
                    Priority:{' '}
                    <Text
                      style={{
                        color: '#940303',
                        fontFamily: 'Montserrat-regular',
                      }}>
                      High
                    </Text>
                  </Text>
                </View>
              </View>
              <View style={{borderWidth: 1, borderColor: '#ccc', marginTop: 4}}>
                {newOrderData.messages.map((message, index) => {
                  return this._messageElement(message, index);
                })}
              </View>
            </ScrollView>
          </View>

          {/* chat input is here */}

          <View style={styles.sendinputbox}>
            <View style={{width: '80%'}}>
              <TextInput
                style={styles.typemassageuser_help}
                placeholder="Type Your Messages"
                placeholderTextColor="#878787"
                underlineColorAndroid="rgba(0, 0, 0,0)"
                value={this.state.sendText}
                onChangeText={sendText => this.setState({sendText})}
              />
            </View>
            <TouchableOpacity
              onPress={() => this._handleSend(newOrderData.ticket)}
              style={{
                backgroundColor: '#660165',
                width: 75,
                height: 50,
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Text style={{color: '#fff', fontSize: 15, textAlign: 'center'}}>
                Send
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(ResoutionCenter);
