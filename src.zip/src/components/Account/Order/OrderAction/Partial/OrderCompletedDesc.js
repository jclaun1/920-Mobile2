import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../../config/env';
import OrderSubmitting from '../../../../Common/OrderSubmitting';
import axios from 'axios';

export default class OrderCompletedDesc extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      isResoution: false,
      feedbackPoint: 5,
      feedback: 'Excelent',
      offerId: props.offerId,
      feedbacks: [
        {name: 'Excelent', point: 5},
        {name: 'Good', point: 4},
        {name: 'Okay', point: 3},
        {name: 'Poor', point: 2},
        {name: 'Terrible', point: 1},
      ],
    };
  }

  async _handleFeedBack(order) {
    this.setState({
      isLoading: true,
    });

    var urlf;
    if (order.isPaylater) {
      urlf =
        'paylater/send/feedback/' +
        order.slug +
        '/' +
        this.state.offerId +
        '/sender';
    } else {
      urlf = 'send/feedback/' + order.slug + '/' + order.invoiceID + '/sender';
    }

    try {
      var data = {
        feedback: this.state.feedback,
        rating: parseInt(this.state.feedbackPoint),
      };

      let response = await axios.post(urlf, data);
      this.setState({
        feedback: '',
        isLoading: false,
      });
      this.props.onFeedbackComplete(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _handleOnConfirmDelivery(order_data) {
    this.setState({
      isLoading: true,
    });
    var url;
    if (order_data.isPaylater) {
      url =
        'paylater/complete/order/' + order_data.slug + '/' + this.state.offerId;
    } else {
      url = 'complete/order/' + order_data.slug + '/' + order_data.invoiceID;
    }

    try {
      let response = await axios.post(url);
      this.setState({
        isLoading: false,
        feedback: '',
      });
      this.props.OnCompletedOrder(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  _handleOnCofirmDeliveryWarning(order) {
    Alert.alert(
      'Are you sure?',
      "You won't be able to revert this!",
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Yes, Confirmed it!',
          onPress: () => this._handleOnConfirmDelivery(order),
        },
      ],
      {cancelable: false},
    );
  }

  _handleProblemOrder() {
    this.props.onProblemForm(true);
  }

  _renderElement(order, navigate) {
    if (!order.isDelivered) {
      return (
        <View>
          <View style={styles.optionboxchat}>
            <Text
              style={{
                textAlign: 'center',
                color: '#660165',
                marginBottom: 5,
                fontSize: 18,
                fontFamily: 'Montserrat-semiBold',
              }}>
              ORDER STARTED
            </Text>
            <FontAwesome name="gift" size={100} style={{color: '#660165'}} />
            <Text
              style={{
                fontSize: 14,
                textAlign: 'center',
                fontFamily: 'Montserrat-regular',
              }}>
              {order.traveller} will travel soon and bring your item. your item
              is expected to be delivered on {order.delivery_date}
            </Text>
          </View>

          <View style={styles.hrborder} />
          <View style={styles.optionboxchat}>
            <Text
              style={{
                fontSize: 14,
                textAlign: 'center',
                fontFamily: 'Montserrat-regular',
              }}>
              Meanwhile chat with traveller to discuss the meeting point for
              taking the delivery. We want you both to meet in a public place
              only
            </Text>
            <FontAwesome name="wechat" size={100} style={{color: '#660165'}} />
            <Text
              style={{
                textAlign: 'center',
                color: '#23527c',
                fontSize: 12,
                fontFamily: 'Montserrat-regular',
              }}
              onPress={() =>
                navigate('Chat', {slug: order.slug, chatID: order.chatRoomId})
              }>
              Chat Now
            </Text>
          </View>

          <View style={styles.hrborder} />
          <View style={styles.optionboxchat}>
            <Text
              style={{
                textAlign: 'center',
                color: '#660165',
                marginBottom: 5,
                fontSize: 18,
                fontFamily: 'Montserrat-semiBold',
              }}>
              Confirm your Delivery
            </Text>
            <Text
              style={{
                fontSize: 14,
                textAlign: 'center',
                fontFamily: 'Montserrat-regular',
              }}>
              Once you have received your item confirm the delivery to mark your
              order completed so we can release the payment to the traveller.
              Also drop a quick feedback so it will help us to build best
              shoppers and travellers community.
            </Text>
          </View>

          <View style={styles.hrborder} />
          <View style={styles.optionboxchat}>
            <View style={styles.fromgroup}>
              <TouchableOpacity
                onPress={() => this._handleOnCofirmDeliveryWarning(order)}>
                <Text style={styles.Searchbtn}>Confirm Delivery</Text>
              </TouchableOpacity>
            </View>

            {order.isPaylater ? null : (
              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleProblemOrder()}>
                  <Text style={styles.Searchbtn}>Problem with order ?</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      );
    } else {
      var widthdata = 120;
      return (
        <View>
          <View style={styles.optionboxchat}>
            <Text
              style={{
                textAlign: 'center',
                color: '#660165',
                marginBottom: 5,
                fontSize: 18,
                fontFamily: 'Montserrat-semiBold',
              }}>
              You Confirm Your Delivery
            </Text>
            <Text
              style={{
                fontSize: 15,
                textAlign: 'center',
                fontFamily: 'Montserrat-regular',
              }}>
              Please rate your experience with traveller.
            </Text>
          </View>

          <View style={styles.hrborder} />
          <View style={styles.feedback_box}>
            {this.state.feedbacks.map((element, index) => {
              var points = [];
              widthdata = widthdata - 20;
              for (let indexp = 1; indexp <= element.point; indexp++) {
                points.push(indexp);
              }
              return (
                <View
                  key={index}
                  style={{
                    flexDirection: 'row',
                    marginVertical: 10,
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}>
                  <View style={{flexDirection: 'row'}}>
                    <TouchableOpacity
                      style={{marginRight: 5}}
                      onPress={() =>
                        this.setState({
                          feedbackPoint: element.point,
                          feedback: element.name,
                        })
                      }>
                      <Image
                        source={{
                          uri:
                            element.point == this.state.feedbackPoint
                              ? STORAGE_URL + 'mobileapp/chaked.png'
                              : STORAGE_URL + 'mobileapp/unchaked.png',
                        }}
                        resizeMode="cover"
                        style={{height: 30, width: 30}}
                      />
                    </TouchableOpacity>
                    <Text style={styles.feedback_text_opt}>{element.name}</Text>
                  </View>
                  <View
                    style={{
                      width: widthdata,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>
                    {points.map((elementp, indexpp) => {
                      return (
                        <FontAwesome
                          key={indexpp}
                          name="star"
                          size={20}
                          style={{color: '#660165'}}
                        />
                      );
                    })}
                  </View>
                </View>
              );
            })}
          </View>

          <View style={styles.optionboxchat}>
            <Text
              style={{
                textAlign: 'center',
                color: '#660165',
                marginBottom: 5,
                fontSize: 18,
                fontFamily: 'Montserrat-semiBold',
              }}>
              Share your experience with traveller
            </Text>
            <View style={{width: '100%'}}>
              <TextInput
                style={styles.inputdescription}
                placeholder="feedback"
                placeholderTextColor="#878787"
                underlineColorAndroid="rgba(0, 0, 0,0)"
                value={this.state.feedback}
                onChangeText={feedback => this.setState({feedback})}
              />
            </View>
          </View>
          <View style={styles.fromgroup}>
            <TouchableOpacity onPress={() => this._handleFeedBack(order)}>
              <Text style={styles.Searchbtn}>SEND FEEDBACK</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var order = this.props.order;
      var navigate = this.props.navigate;

      return (
        <View style={styles.container}>
          <View style={[styles.card, styles.shadow]}>
            {this._renderElement(order, navigate)}
          </View>
        </View>
      );
    }
  }
}
