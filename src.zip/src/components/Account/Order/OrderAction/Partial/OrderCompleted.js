import React, {Component} from 'react';
import {View, Text, ScrollView, Image} from 'react-native';
import styles from '../../../../../../assets/css/style';
import {STORAGE_URL} from '../../../../../config/env';

export default class OrderCompleted extends Component {
  render() {
    var order_data = this.props.order;
    return (
      <View style={styles.container}>
        <ScrollView style={{width: '100%'}}>
          <View style={[styles.card, styles.shadow]}>
            <View
              style={{
                width: '100%',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                source={{
                  uri: STORAGE_URL + 'static/assets/images/box-gift.png',
                }}
                resizeMode="cover"
                style={{height: 97, width: 130}}
              />
              <Text
                style={{
                  fontSize: 22,
                  fontFamily: 'Montserrat-Bold',
                  color: '#660165',
                  marginVertical: 8,
                  textAlign: 'center',
                }}>
                Order Completed !{' '}
              </Text>
            </View>

            <Text
              style={{
                fontSize: 15,
                fontFamily: 'Montserrat-semiBold',
                marginVertical: 10,
              }}>
              Dear {order_data.name},
            </Text>
            <Text>
              The item you ordered{' '}
              <Text style={{fontSize: 15, fontFamily: 'Montserrat-semiBold'}}>
                {order_data.item_name}
              </Text>{' '}
              has been delivered by{' '}
              <Text style={{fontSize: 15, fontWeight: '600'}}>
                {' '}
                {order_data.traveller}
              </Text>{' '}
              on{' '}
              <Text style={{fontSize: 15, fontWeight: '600'}}>
                {' '}
                {order_data.delivered_At}{' '}
              </Text>
              . We hope to see you again.
            </Text>
            <Text style={{marginTop: 20}}>Thanks</Text>
            <Text>The Flypur Team</Text>
          </View>
        </ScrollView>
      </View>
    );
  }
}
