import React, {Component} from 'react';
import {
  View,
  ScrollView,
  BackHandler,
  Alert,
  RefreshControl,
  StatusBar,
} from 'react-native';
import OrderDetails from '../OrderDetails';
import StepIndecator from './StepIndecator';

import ResoutionCenter from './Partial/ResoutionCenter';
import OrderCompletedDesc from './Partial/OrderCompletedDesc';
import ResoutionCenterForm from './Partial/ResoutionCenterForm';
import OrderCompleted from './Partial/OrderCompleted';

import OrderSubmitting from '../../../Common/OrderSubmitting';
import styles from '../../../../../assets/css/style';
import axios from 'axios';

export default class OrderConfirm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      slug: null,
      offerId: null,
      isLoading: true,
      step: 2,
      isResoution: false,
      refreshing: false,
    };
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      // this.props.navigation.navigate(null)
      this.props.navigation.push('AllOffers', {slug: this.state.slug});
      return true;
    });

    const slug = this.props.navigation.getParam('slug');
    const offerId = this.props.navigation.getParam('offerId');
    this.setState({slug, offerId});
    this._order(slug, offerId, 0);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      // this.props.navigation.navigate(null)
      this.props.navigation.push('AllOffers', {slug: this.state.slug});
      return true;
    });
  }

  async _order(slug, offerId, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }
    let url;
    if (offerId) {
      url = 'paylater/confirm/order/' + slug + '/' + offerId;
    } else {
      url = 'confirm/order/' + slug;
    }

    try {
      let response = await axios.get(url);
      this.setState({
        order: response.data.data,
        step: response.data.data.isDelivered ? 4 : 3,
        isResoution: response.data.data.isResoution,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      // if (rror.request.response) {
      //      console.log(JSON.parse(error.request.response))
      // }else{
      //     console.log(error);
      // }

      if (type) {
        this.setState({
          refreshing: false,
        });
      } else {
        Alert.alert('Oops!', 'No order data found!');
        this.props.navigation.navigate('MyOrders');
      }
    }
  }

  _onHandleConfirmOrder(data) {
    this.setState({
      step: data.isDelivered ? 4 : 3,
      order: data,
    });
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var order = this.state.order;
      return (
        <View style={styles.container}>
          <StatusBar backgroundColor="#660165" barStyle="light-content" />
          <ScrollView
            style={{width: '100%'}}
            refreshControl={
              <RefreshControl
                refreshing={this.state.refreshing}
                onRefresh={() =>
                  this._order(this.state.slug, this.state.offerId, 1)
                }
                style={{backgroundColor: 'transparent'}}
              />
            }>
            {!order.isResoution ? (
              <StepIndecator step={this.state.step} />
            ) : null}
            {!order.isResoution ? <OrderDetails order={order} /> : null}

            <View style={{width: '100%'}}>
              {order.isResoution && !order.isDelivered ? (
                <ResoutionCenter order={order} />
              ) : null}
              {!order.isResoution &&
              !order.isMarkedByBuyer &&
              this.state.isResoution ? (
                <ResoutionCenterForm
                  onTicketCreated={order =>
                    this.setState({order, isResoution: false})
                  }
                  onProblemForm={isResoution => this.setState({isResoution})}
                  order={order}
                />
              ) : null}
              {!order.isResoution &&
              !order.isMarkedByBuyer &&
              !this.state.isResoution ? (
                <OrderCompletedDesc
                  OnCompletedOrder={data => this._onHandleConfirmOrder(data)}
                  onProblemForm={isResoution => this.setState({isResoution})}
                  onFeedbackComplete={data => this.setState({order: data})}
                  order={order}
                  offerId={this.state.offerId}
                  navigate={this.props.navigation.navigate}
                />
              ) : null}
              {order.isDelivered && order.isMarkedByBuyer ? (
                <OrderCompleted order={order} />
              ) : null}
            </View>
          </ScrollView>
        </View>
      );
    }
  }
}
