import React, {Component} from 'react';
import {View, ScrollView, BackHandler, Alert} from 'react-native';
import TravellerOrderDetails from './Traveller/TravellerOrderDetails';
import StepIndecator from './StepIndecator';

import TravellerOrderCompletedDesc from './Traveller/TravellerOrderCompletedDesc';
import TravellerOrderCompleted from './Traveller/TravellerOrderCompleted';

import OrderSubmitting from '../../../Common/OrderSubmitting';
import styles from '../../../../../assets/css/style';
import axios from 'axios';

export default class ConfirmOrderTraveller extends Component {
  constructor(props) {
    super(props);
    this.state = {
      order: {},
      slug: null,
      offerId: null,
      isLoading: true,
      step: 2,
      isResoution: false,
    };
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });

    const slug = this.props.navigation.getParam('slug');
    const offerId = this.props.navigation.getParam('offerId');
    this.setState({slug, offerId});
    this._order(slug, offerId);
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  async _order(slug, offerId) {
    this.setState({
      isLoading: true,
    });

    var url;
    if (offerId) {
      url = 'paylater/traveller/payment/' + slug + '/' + offerId;
    } else {
      url = 'traveller/payment/' + slug;
    }

    try {
      let response = await axios.get(url);
      this.setState({
        order: response.data.data,
        step: response.data.data.isDelivered ? 4 : 3,
        isResoution: response.data.data.isResoution,
        isLoading: false,
      });
    } catch (error) {
      // if (rror.request.response) {
      //      console.log(JSON.parse(error.request.response))
      // }else{
      //     console.log(error);
      // }

      await Alert.alert('Opps!', 'No order data found!');
      this.props.navigation.navigate('Home');
    }
  }

  _onHandleConfirmOrder(data) {
    this.setState({
      step: data.isDelivered ? 4 : 3,
      order: data,
    });
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      var order = this.state.order;
      var element;
      if (order.isDelivered && order.isMarkedByTraveller) {
        element = <TravellerOrderCompleted order={order} />;
      } else {
        element = (
          <TravellerOrderCompletedDesc
            onFeedbackComplete={data => this.setState({order: data})}
            order={order}
            navigate={this.props.navigation.navigate}
            offerId={this.state.offerId}
          />
        );
      }
      return (
        <View style={styles.container}>
          <ScrollView style={{width: '100%'}}>
            <StepIndecator step={this.state.step} />
            <TravellerOrderDetails order={order} />

            <View style={{width: '100%'}}>{element}</View>
          </ScrollView>
        </View>
      );
    }
  }
}
