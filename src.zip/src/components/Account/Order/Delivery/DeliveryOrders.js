import React from 'react'
import { BackHandler ,Dimensions, View} from 'react-native'
import { createMaterialTopTabNavigator, createAppContainer} from 'react-navigation'

import OrderSubmitting from '../../../Common/OrderSubmitting'
import { connect } from 'react-redux'
import filter from 'lodash/filter'
import axios from 'axios'
import NonScreenHeader from '../../../Menu/NonScreenHeader'

import DeliveredOrders  from './Partial/DeliveredOrders'
import RequestedOrders  from './Partial/RequestedOrders'
import ToDeliveryOrders  from './Partial/ToDeliveryOrders'


const fontsizerwidth = Dimensions.get('window').width

const fontSizer = (screenWidth) => {
    if(screenWidth > 400){
      return 12;
    }else if(screenWidth > 360){
      return 11;
    }
    else if(screenWidth > 250){
        return 10;
      }else { 
      return 9;
    }
}

  
class DeliveryOrders extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            navigation: this.props.navigation,
            orders: [],
            requestedOrders: [],
            toDeliveryOrders: [],
            deliveredOrders: [],
            trip_data: null,
            allorders: [],
            isLoading: true,
            refreshing:false,
            tripId: null,
            notify:null
        }
    }

    static navigationOptions = ({ navigation }) => {
        return {
            header: <NonScreenHeader notHome={true} title="Delivery Orders" navigate={navigation}/>
        }
    }

    
    

    async _filterOrder(allorders) {
        try {
           
            let requestedOrders =  await filter(allorders, (order) =>  {
                return !order.isCanceled && !order.isDeleted && !order.paid
            })

            let toDeliveryOrders =  await filter(allorders, (order) =>  {
                return order.paid &&  !order.isDelivered
            })


            let deliveredOrders = await filter(allorders, (order) =>  {
                return order.paid &&  order.isDelivered
            })

            this.setState({
                requestedOrders,
                toDeliveryOrders,
                deliveredOrders,
                isLoading:false
            })
        } catch (error) {
            this.setState({
                isLoading:false
            })
        }
    }



    async _orders(tripid, notify) {
     
        try {
            var url
			if (notify === 'notify') {
				url = 'trips/orders/'+tripid + '/notify'
			}else{
				url = 'trips/orders/'+tripid
			}
           
            let response = await axios.get(url)
            
            await this.setState({
                allorders:response.data[0],
                trip_data: response.data[1]
            })
           
            this._filterOrder(response.data[0])

        } catch (error) {
            // console.log(error)
            this.setState({
                isLoading: false,
                refreshing:false
            })
        }
    }

    async componentDidMount() {

        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })

        let tripId = await this.props.navigation.getParam('tripId')
        let notify = await this.props.navigation.getParam('notify')
        await this.setState({
            tripId, notify
        })
        this._orders(tripId, notify)
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }
  
    render() {
        
        if (this.state.isLoading) {
            return (
                <OrderSubmitting />
            )
        } else {
        
            return (
                <View style={{flex:1}}>
                    <Tabs screenProps={
                            {
                                push: this.props.navigation.push, 
                                requestedOrders:this.state.requestedOrders,
                                toDeliveryOrders:this.state.toDeliveryOrders,
                                deliveredOrders:this.state.deliveredOrders,
                                trip_data: this.state.trip_data,
                                tripId:this.state.tripId,
                                notify:this.state.notify

                            }
                        } 
                    />
                </View>

            )
        }
    }
}




const Tabs =  createAppContainer(createMaterialTopTabNavigator(
    {
        RequestedOrders: {
            screen: RequestedOrders,
            navigationOptions:{
              tabBarLabel:'Requested'
            }
        },


        ToDeliveryOrders: {
            screen: ToDeliveryOrders,
            navigationOptions:{
                tabBarLabel:'To Delivery'
            }
        },

        DeliveredOrders: {
            screen: DeliveredOrders,
            navigationOptions:{
                tabBarLabel:'Delivered'
            }
        },
    },{
        tabBarOptions: {
            style: {
                backgroundColor: '#660165',
                marginBottom:15,
            },
            labelStyle: {
                fontSize: fontSizer(fontsizerwidth),
                fontFamily:'Montserrat-Bold',
                // fontWeight:"800",
                // borderBottomColor:'#fff'
            },
            activeTintColor: '#ffff',
            inactiveTintColor: 'gray',
            indicatorStyle:{
                borderBottomColor: '#ffffff',
                borderBottomWidth: 4,

            },
        }
    }
))




export default connect(null, null)(DeliveryOrders)
