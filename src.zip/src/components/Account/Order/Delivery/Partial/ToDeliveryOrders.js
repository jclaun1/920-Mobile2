import React from 'react'
import DeliveryOrdersComponent from './DeliveryOrdersComponent'
import {connect}  from 'react-redux'

class ToDeliveryOrders extends React.Component {

    render() {

        return (
            <DeliveryOrdersComponent step={2} push={this.props.screenProps.push} screenProps={this.props.screenProps} navigation={this.props.navigation} orders={this.props.screenProps.toDeliveryOrders}/>
        )
        
    }
}


export default connect(null, null)(ToDeliveryOrders)
