import React from 'react'

import { Text, View, Image, TouchableOpacity, Dimensions, ScrollView, BackHandler, RefreshControl } from 'react-native'
import styles from '../../../../../../assets/css/style'
import Carousel from 'react-native-snap-carousel'
import filter from 'lodash/filter'
import axios from 'axios'
import {connect}  from 'react-redux'

class DeliveryOrdersComponent extends React.Component {
    
    constructor(props) {
        super(props)
        this.state = {
            orders: props.orders,
            refreshing:false,
            trip_data:props.screenProps.trip_data,
            step: props.step,
            activeSlide:0,
            requestedOrders: [],
            toDeliveryOrders: [],
            deliveredOrders: [],
            viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height
            }
        }
    }

     _stepCond() {
        if (this.state.step == 1) {
             this.setState({
                orders: this.state.requestedOrders,
                refreshing:false
            })
            
        }

        if (this.state.step == 2) {
             this.setState({
                orders: this.state.toDeliveryOrders,
                refreshing:false
            })
            
        }

        if (this.state.step == 3) {
             this.setState({
                orders: this.state.deliveredOrders,
                refreshing:false
            })
            
        }

        
    }

    async _filterOrder(allorders) {
       
        try {
           
            var requestedOrders =  await filter(allorders, (order) =>  {
                return !order.isCanceled && !order.isDeleted && !order.paid
            })

            var toDeliveryOrders =  await filter(allorders, (order) =>  {
                return order.paid &&  !order.isDelivered
            })


            var deliveredOrders = await filter(allorders, (order) =>  {
                return order.paid &&  order.isDelivered
            })
           

            await this.setState({
                requestedOrders,
                toDeliveryOrders,
                deliveredOrders
            })
            this._stepCond()
        } catch (error) {
            this.setState({
                refreshing:false
            })
        }
    }



    async _order(tripid, notify) {
     
        this.setState({
            refreshing: true
        })
        
        try {
            var url
			if (notify === 'notify') {
				url = 'trips/orders/'+tripid + '/notify'
			}else{
				url = 'trips/orders/'+tripid
			}

            let response = await axios.get(url)
            await this.setState({
                trip_data: response.data[1]
            })

            this._filterOrder(response.data[0])

        } catch (error) {
            // console.log(error)
            this.setState({
                refreshing:false
            })
        }
    }

    componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    componentWillUnmount() {
        BackHandler.addEventListener('hardwareBackPress',()=>{
            this.props.navigation.goBack(null)
            return true
        })
    }

    _renderItem = (item, index) => {
        var order = item.item
       
        
        return (<View style={[styles.orderitemcard, styles.shadow]}>
                <View style={{ marginBottom: 10, marginTop:5,}}>
                    <TouchableOpacity  onPress={() => this.props.push('OrderPost', { slug: order.slug })}>
                        <Text style={{ color: '#660165', fontSize: 16,fontFamily:'Montserrat-semiBold',  }}>{order.name_item}</Text>
                    </TouchableOpacity>
                </View>

                <Image style={styles.fitImage} source={{ uri: order.images[0] }} resizeMode='contain' style={{ height: 200, }} />
                <View style={styles.adressbox}>
                    <View style={styles.addresslistbox}>
                        <View style={{width:95,}}>
                            <Text style={styles.addresstitel}>Delivery To  </Text>
                        </View>
                        <View style={{flex:5}}>
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_to_no_limit}</Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <View style={{width:115,}}> 
                            <Text style={styles.addresstitel}>Delivery From  </Text>
                        </View>
                        <View style={{flex:5}}> 
                            <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_from_no_limit} </Text>
                        </View>
                    </View>
                    <View style={styles.addresslistbox}>
                        <Text style={styles.addresstitel}>Before  </Text>
                        <Text style={[styles.addresstitel, styles.colorpurple,styles.ordertextwrap]}>{order.delivery_date}</Text>
                    </View>
                </View>

                <View style={styles.pricebox}>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Item Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}> {this.props.currency} {order.price_item}</Text>
                    </View>
                    <View style={[styles.pricemain, styles.borderRightleft]}>
                        <Text style={styles.pricetitel}>Travellar Price</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{this.props.currency} {order.traveller_fee}</Text>
                    </View>
                    <View style={styles.pricemain}>
                        <Text style={styles.pricetitel}>Quantity</Text>
                        <Text style={[styles.pricetitel, styles.colorpurple]}>{order.quantity}</Text>
                    </View>
                </View>

                <View style={styles.offercontainer}>
                    <TouchableOpacity onPress={() => this.props.push('AllOffers', { slug: order.slug })}>
                        <Text style={[styles.offer, styles.bggreen]}> {order.countOffer} Offer</Text>
                    </TouchableOpacity>
                </View>

            </View>
        )
    }

    render() {
      
        return (

            <View style={styles.container}
                onLayout={() => {
                    this.setState({
                        viewport: {
                            width: Dimensions.get('window').width,
                            height: Dimensions.get('window').height
                        }
                    });
                }}>
                <ScrollView 
                    refreshControl={
                    <RefreshControl
                    refreshing={this.state.refreshing}
                    onRefresh={() => this._order(this.props.screenProps.tripId, this.props.screenProps.notify)}
                    style={{backgroundColor: 'transparent'}}
                    />}>

                    {
                        this.state.trip_data ? <View style={styles.offercontainer}>
                        
                            <Text style={{fontSize:16,fontFamily:'Montserrat-SemiBold',color:'#000',}}> {this.state.trip_data.from} -  {this.state.trip_data.to}</Text>
                       
                        </View>: null
                    }

                    <Carousel
                        ref={(c) => { this._carousel = c; }}
                        data={this.state.orders}
                        renderItem={this._renderItem}
                        sliderWidth={this.state.viewport.width}
                        itemWidth={this.state.viewport.width}
                        onSnapToItem={(index) => this.setState({ activeSlide: index })}
                    />
                </ScrollView>
            </View >

        )
        
    }
}

const mapStateToProps = state => {
    return {
        currency: state.auth.currency
    }
}


export default connect(mapStateToProps, null)(DeliveryOrdersComponent)
