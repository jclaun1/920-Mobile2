import React from 'react'
import DeliveryOrdersComponent from './DeliveryOrdersComponent'
import {connect}  from 'react-redux'

class RequestedOrders extends React.Component {

    render() {

        return (
            <DeliveryOrdersComponent step={1} push={this.props.screenProps.push} screenProps={this.props.screenProps} navigation={this.props.navigation} orders={this.props.screenProps.requestedOrders}/>
        )
        
    }
}

export default connect(null, null)(RequestedOrders)
