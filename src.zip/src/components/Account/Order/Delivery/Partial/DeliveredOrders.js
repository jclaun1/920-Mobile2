import React from 'react'
import DeliveryOrdersComponent from './DeliveryOrdersComponent'
import {connect}  from 'react-redux'

class DeliveredOrders extends React.Component {

    render() {
        
        return (
            <DeliveryOrdersComponent step={3} push={this.props.screenProps.push} screenProps={this.props.screenProps} navigation={this.props.navigation} orders={this.props.screenProps.deliveredOrders}/>
        )
        
    }
}

export default connect(null, null)(DeliveredOrders)
