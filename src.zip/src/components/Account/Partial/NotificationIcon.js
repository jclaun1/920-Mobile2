import React from 'react';
import {View,Text} from 'react-native'
import  FontAwesome  from 'react-native-vector-icons/FontAwesome'
import {connect}  from 'react-redux'
import styles from '../../../../assets/css/style'

class NotificationIcon extends React.Component {

    render() {
        return (
            <View>
                <View style={{marginTop:4}}> 
                    <FontAwesome name='bell' color={this.props.tintColor} size={25}/>
                    {
                        this.props.notificationCount ? 
                        <Text style={styles.labelinbox}>
                            {this.props.notificationCount}
                        </Text> : null
                    }
                </View>
            </View>
        )
    }
}

const mapStateToProps = state => {
    return {
        notificationCount:state.auth.notification_count
    }
  }

export default connect(mapStateToProps, null)(NotificationIcon)
