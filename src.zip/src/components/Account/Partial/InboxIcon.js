import React from 'react';
import {View,Text} from 'react-native'
import  FontAwesome  from 'react-native-vector-icons/FontAwesome'
import {connect}  from 'react-redux'
import styles from '../../../../assets/css/style'


class InboxIcon extends React.Component {
   
    render() {
        return (
            <View >
               <View style={{marginTop:4}}>
                    <FontAwesome name='envelope' color={this.props.tintColor} size={25}/> 
                    {
                        this.props.inboxCount ? 
                        <Text style={styles.labelinbox}>{this.props.inboxCount}
                        </Text> : null
                    }
                </View>       
            </View>
        )
    }
}

const mapStateToProps = state => {
    return {
        inboxCount:state.auth.inbox_count
    }
  }

export default connect(mapStateToProps, null)(InboxIcon)
