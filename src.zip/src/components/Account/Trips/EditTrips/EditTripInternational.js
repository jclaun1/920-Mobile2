import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Modal,
  Alert,
  StatusBar,
} from 'react-native';
import GooglePlaces from '../../../Common/GooglePlaces';
import styles from '../../../../../assets/css/style';
import {connect} from 'react-redux';
import moment from 'moment';
import {DatePicker} from 'native-base';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import axios from 'axios';

class EditTripInternational extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isNotification: true,
      trip: props.trip,
      isLoading: true,
      visible: false,
      selectedCountry: {},
      fromShow: false,
      toShow: false,
      defaultDateP: '',

      isAdded: false,
      travel_date: '',

      address_from: '',
      address_to: '',

      country_from: '',
      country_to: '',
      lang_from: '',
      lang_to: '',
      lat_from: '',
      lat_to: '',
      country: '',
      country_code: '',
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
    this._issamecountry = this._issamecountry.bind(this);
  }

  _assign_data() {
    let data = this.state.trip;
    this.setState({
      address_from: data.travel_from,
      address_to: data.travel_to,
      travel_date: moment(data.travel_date, 'YYYY-MM-DD H:mm:ss').format(
        'DD/MM/YYYY',
      ),
      defaultDateP: moment(
        this.state.trip.travel_date,
        'YYYY-MM-DD H:mm:ss',
      ).format('YYYY, MM, DD'),
      country_from: data.country_from,
      country_to: data.country_to,
      lang_from: data.lang_from,
      lang_to: data.lang_to,
      lat_from: data.lat_from,
      lat_to: data.lat_to,
      country: data.country,
      country_code: data.country_code,
      isNotification: data.isNotify ? true : false,
      isLoading: false,
    });
  }

  handlerSwitchToggle = () => {
    this.setState({
      isNotification: !this.state.isNotification,
    });
  };

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  async _issamecountry(forplace) {
    try {
      await Alert.alert(
        'Opps!',
        'Hey :) Please choose the two different countries',
      );
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        address_from: data.formatted_address,
        country_from:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(1);
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        address_to: data.formatted_address,
        country_to:
          data.address_components[data.address_components.length - 1].long_name,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(0);
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleSubmit() {
    if (this.state.isAdded) {
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    if (this.state.country_from === this.state.country_to) {
      this._issamecountry(0);
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = {
        travel_from: this.state.address_from,
        travel_to: this.state.address_to,
        country_from: this.state.country_from,
        country: this.state.country_from,
        country_code: this.state.country_code,
        country_to: this.state.country_to,
        lang_from: this.state.lang_from,
        lang_to: this.state.lang_to,
        lat_from: this.state.lat_from,
        lat_to: this.state.lat_to,
        travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
          'YYYY-MM-DD H:mm:ss',
        ),
        notify: this.state.isNotification ? 1 : 0,
      };

      let response = await axios.post(
        'trip/international/edit/' + this.state.trip.id,
        data,
      );

      await this.setState({
        isAdded: true,
        isLoading: false,
      });

      this.props.onClose(response.data.data);
    } catch (error) {
      this.setState({
        isLoading: false,
      });
      await Alert.alert('Opps!', 'Somthing went wrong');
    }
  }

  componentDidMount() {
    this._assign_data();
  }

  render() {
    const pagestyle = StyleSheet.create({
      toggel: {
        height: 25,
        width: 28,
        borderRadius: 50,
        backgroundColor: '#fff',
      },
      toggelnotify: {
        left: this.state.isNotification ? 30 : 0,
      },
      switch: {
        height: 25,
        width: 60,
        borderRadius: 50,
      },
      switchnotify: {
        backgroundColor: this.state.isNotification ? '#660165' : '#ccc',
      },
    });
    var isShow = this.props.isShowInternational;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <Modal
          animationType="slide"
          transparent={false}
          visible={isShow}
          onRequestClose={() => {
            this.props.onClose(false);
          }}>
          <ScrollView>
            <View style={styles.popupContainer}>
              <StatusBar hidden={true} />
              <Text
                style={{
                  fontSize: 22,
                  fontFamily: 'Montserrat-semiBold',
                  textAlign: 'center',
                  marginBottom: 10,
                  color: '#660165',
                }}>
                Edit International Trip
              </Text>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  defaultText={this.state.address_from}
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From city/country"
                />
              </View>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  defaultText={this.state.address_to}
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To city/country"
                />
              </View>

              <View style={styles.datepiker}>
                <DatePicker
                  defaultDate={new Date(this.state.defaultDateP)}
                  minimumDate={new Date()}
                  locale={'en'}
                  timeZoneOffsetInMinutes={undefined}
                  modalTransparent={false}
                  animationType={'fade'}
                  androidMode={'default'}
                  placeholder="DD/MM/YYY"
                  textStyle={{color: '#878787'}}
                  placeHolderTextStyle={{color: '#878787'}}
                  onDateChange={this._handleDatePicked}
                />
              </View>

              <View style={styles.toggelswitchmain}>
                <Text>GET NOTIFIED ABOUT NEW ORDERS </Text>
                <View style={[pagestyle.switch, pagestyle.switchnotify]}>
                  <TouchableOpacity
                    onPress={this.handlerSwitchToggle}
                    style={[pagestyle.toggel, pagestyle.toggelnotify]}>
                    <Text>{this.state.isNotification ? '' : ''}</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleSubmit()}>
                  <Text style={styles.Searchbtn}>Update</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.props.onClose(false)}>
                  <Text style={styles.Searchbtn}>cancel</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </Modal>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(EditTripInternational);
