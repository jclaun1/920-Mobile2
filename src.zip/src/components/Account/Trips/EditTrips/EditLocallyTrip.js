import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Modal,
  Alert,
  StatusBar,
} from 'react-native';
import styles from '../../../../../assets/css/style';
import {DatePicker, Picker, Icon} from 'native-base';
import GooglePlaces from '../../../Common/GooglePlaces';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import moment from 'moment';
import {connect} from 'react-redux';
import axios from 'axios';

class EditLocallyTrip extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isNotification: true,
      trip: props.trip,
      isLoading: true,
      visible: false,

      fromShow: false,
      toShow: false,
      localCityShow: false,
      defaultDateP: '',

      isAdded: false,
      travel_date: '',

      address_from: '',
      address_to: '',

      country_from: '',
      country_to: '',
      lang_from: '',
      lang_to: '',
      lat_from: '',
      lat_to: '',
      country: '',
      country_code: '',

      city: '',
      citydetails: {},
      hour: '03',
      minute: '15',
      convention: 'PM',
    };
  }

  handlerSwitchToggle = () => {
    this.setState({
      isNotification: !this.state.isNotification,
    });
  };

  _assign_data(data) {
    this.setState({
      address_from: data.travel_from,
      address_to: data.travel_to,
      travel_date: moment(data.travel_date, 'YYYY-MM-DD H:mm:ss').format(
        'DD/MM/YYYY',
      ),
      defaultDateP: moment(data.travel_date, 'YYYY-MM-DD H:mm:ss').format(
        'YYYY, MM, DD',
      ),
      country: data.country,
      country_code: data.country_code,
      city: data.city_name,
      citydetails: {lat: data.city_lat, lang: data.city_lang},
      lang_from: data.lang_from,
      lang_to: data.lang_to,
      lat_from: data.lat_from,
      lat_to: data.lat_to,
      hour: data.hour,
      minute: data.minute,
      convention: data.convention,
      isNotification: data.isNotify ? true : false,
      isLoading: false,
    });
  }

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  _hourManage(value) {
    this.setState({
      hour: value,
    });
  }

  _minuteManage(value) {
    this.setState({
      minute: value,
    });
  }

  _conventionManage(value) {
    this.setState({
      convention: value,
    });
  }

  async _handleLocalCity(data) {
    try {
      await this.setState({
        citydetails: {
          lang: data.geometry.location.lng,
          lat: data.geometry.location.lat,
        },
        country:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        city: data.formatted_address,
        localCityShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        address_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleSubmit() {
    if (this.state.isAdded) {
      return;
    }

    if (!this.state.country_code) {
      Alert.alert('Oops!', 'enter local city');
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = {
        travel_from: this.state.address_from,
        travel_to: this.state.address_to,
        country: this.state.country,
        country_code: this.state.country_code,
        city: this.state.city,
        city_lat: this.state.citydetails.lat,
        city_lang: this.state.citydetails.lang,
        lang_from: this.state.lang_from,
        lang_to: this.state.lang_to,
        lat_from: this.state.lat_from,
        lat_to: this.state.lat_to,
        travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
          'YYYY-MM-DD H:mm:ss',
        ),
        hour: this.state.hour,
        minute: this.state.minute,
        convention: this.state.convention,
        notify: this.state.isNotification ? 1 : 0,
      };

      let response = await axios.post(
        'trip/local/edit/' + this.state.trip.id,
        data,
      );

      await this.setState({
        isAdded: true,
        isLoading: false,
      });

      this.props.onClose(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
      await Alert.alert('Opps!', 'Somthing went wrong!');
    }
  }

  componentDidMount() {
    this._assign_data(this.state.trip);
  }

  render() {
    const pagestyle = StyleSheet.create({
      toggel: {
        height: 25,
        width: 28,
        borderRadius: 50,
        backgroundColor: '#fff',
      },
      toggelnotify: {
        left: this.state.isNotification ? 30 : 0,
      },
      switch: {
        height: 25,
        width: 60,
        borderRadius: 50,
      },
      switchnotify: {
        backgroundColor: this.state.isNotification ? '#660165' : '#ccc',
      },
    });

    var hours = [];
    var minutes = [];

    minutes.push(<Picker.Item key="00" label="00" value="00" />);

    for (let index = 1; index < 25; index++) {
      var hourel = index < 10 ? '0' + index : String(index);
      hours.push(<Picker.Item key={index} label={hourel} value={hourel} />);
    }

    for (let indexel = 1; indexel < 55; indexel++) {
      indexel = indexel + 4;
      var minuteel = indexel < 10 ? '0' + indexel : String(indexel);

      minutes.push(
        <Picker.Item key={indexel} label={minuteel} value={minuteel} />,
      );
    }

    var isShow = this.props.isShowLocal;
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <Modal
          animationType="slide"
          transparent={false}
          visible={isShow}
          onRequestClose={() => {
            this.props.onClose(false);
          }}>
          <ScrollView>
            <View style={styles.popupContainer}>
              <StatusBar hidden={true} />
              <Text
                style={{
                  fontSize: 22,
                  fontFamily: 'Montserrat-semiBold',
                  textAlign: 'center',
                  marginBottom: 10,
                  color: '#660165',
                }}>
                Edit Locally Trip
              </Text>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  defaultText={this.state.city}
                  listDisplayed={this.state.localCityShow}
                  onSelectAddress={this._handleLocalCity}
                  placeHolder="Choose Local City"
                />
              </View>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  defaultText={this.state.address_from}
                  cityDetails={this.state.citydetails}
                  countryCode={this.state.country_code}
                  isLocal={true}
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From Locality"
                />
              </View>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  defaultText={this.state.address_to}
                  cityDetails={this.state.citydetails}
                  countryCode={this.state.country_code}
                  isLocal={true}
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To Locality"
                />
              </View>

              <View style={styles.datepiker}>
                <DatePicker
                  defaultDate={new Date(this.state.defaultDateP)}
                  minimumDate={new Date()}
                  locale={'en'}
                  timeZoneOffsetInMinutes={undefined}
                  modalTransparent={false}
                  animationType={'fade'}
                  androidMode={'default'}
                  placeholder="DD/MM/YYY"
                  textStyle={{color: '#878787'}}
                  placeHolderTextStyle={{color: '#878787'}}
                  onDateChange={this._handleDatePicked}
                />
              </View>

              <View style={styles.fromgroup}>
                <View>
                  <Text
                    style={{fontSize: 16, fontWeight: '600', color: '#000'}}>
                    By What Time You Will Reach There
                  </Text>
                </View>

                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginVertical: 10,
                  }}>
                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select hour"
                      iosIcon={<Icon name="ios-arrow-down-outline" />}
                      style={{width: undefined}}
                      selectedValue={this.state.hour}
                      onValueChange={this._hourManage.bind(this)}>
                      {hours}
                    </Picker>
                  </View>

                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select minute"
                      iosIcon={<Icon name="ios-arrow-down-outline" />}
                      style={{width: undefined}}
                      selectedValue={this.state.minute}
                      onValueChange={this._minuteManage.bind(this)}>
                      {minutes}
                    </Picker>
                  </View>

                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select convention"
                      iosIcon={<Icon name="ios-arrow-down-outline" />}
                      style={{width: undefined}}
                      selectedValue={this.state.convention}
                      onValueChange={this._conventionManage.bind(this)}>
                      <Picker.Item label="AM" value="AM" />
                      <Picker.Item label="PM" value="PM" />
                    </Picker>
                  </View>
                </View>
              </View>
              <View style={styles.toggelswitchmain}>
                <Text>GET NOTIFIED ABOUT NEW ORDERS </Text>
                <View style={[pagestyle.switch, pagestyle.switchnotify]}>
                  <TouchableOpacity
                    onPress={this.handlerSwitchToggle}
                    style={[pagestyle.toggel, pagestyle.toggelnotify]}>
                    <Text>{this.state.isNotification ? '' : ''}</Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleSubmit()}>
                  <Text style={styles.Searchbtn}>Update</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.props.onClose(false)}>
                  <Text style={styles.Searchbtn}>cancel</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </Modal>
      );
    }
  }
}

export default connect(
  null,
  null,
)(EditLocallyTrip);
