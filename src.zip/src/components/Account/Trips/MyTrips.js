import React from 'react';
import {View} from 'react-native';
import {
  createMaterialTopTabNavigator,
  createAppContainer,
} from 'react-navigation';
import Past from './Partial/Past';
import Upcomming from './Partial/Upcomming';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {connect} from 'react-redux';
import moment from 'moment';
import axios from 'axios';
import {
  ALL_TRIPS,
  PAST_TRIPS,
  UPCOMMING_TRIPS,
} from '../../../redux/actions/types';
import NewHeader from '../../Menu/NewHeader';
import orderBy from 'lodash/orderBy';

class MyTrips extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      past_lists: [],
      upcomming_trips: [],
      trips: [],
      alltrips: [],
      isLoading: false,
      refreshing: false,
    };
  }

  static navigationOptions = ({navigation}) => {
    return {
      header: (
        <NewHeader
          isAddtrip={true}
          isHome={false}
          title="My Trips"
          navigate={navigation}
        />
      ),
    };
  };

  componentDidMount() {
    this.mytrips(0);
  }

  _showTripOrderBy(trips) {
    trips = orderBy(
      trips,
      function(o) {
        return new moment(o.travel_date, 'DD/MM/YYYY').format('YYYYMMDD');
      },
      ['asc'],
    );
    return trips;
  }

  async _spliting_trips(trips) {
    try {
      let past_lists = await this._showTripOrderBy(
        await trips.filter(val => {
          let traveldate_past = moment(val.travel_date, 'DD/MM/YYYY').format(
            'YYYY-MM-DD',
          );
          return (
            val.isCanceled ||
            (moment(traveldate_past).isBefore(moment().format('YYYY-MM-DD')) &&
              !val.isDeleted)
          );
        }),
      );

      let upcomming_trips = await this._showTripOrderBy(
        await trips.filter(val => {
          let traveldate_up = moment(val.travel_date, 'DD/MM/YYYY').format(
            'YYYY-MM-DD',
          );
          return (
            !val.isCanceled &&
            moment(traveldate_up).isSameOrAfter(
              moment().format('YYYY-MM-DD'),
            ) &&
            !val.isDeleted
          );
        }),
      );

      await this.props.sendPastTrips(past_lists);
      await this.props.sendUpcommingTrips(upcomming_trips);
      this.setState({
        past_lists,
        upcomming_trips,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async mytrips(type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }
    try {
      let response = await axios.get('/my/trips');
      this.setState({
        alltrips: response.data.data,
      });

      this.props.sendAllTrips(response.data.data);
      await this._spliting_trips(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        refreshing: false,
      });
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={{flex: 1}}>
          <Tabs
            screenProps={{
              push: this.props.navigation.push,
              past_lists: this.state.past_lists,
              upcomming_trips: this.state.upcomming_trips,
            }}
          />
        </View>
      );
    }
  }
}

const Tabs = createAppContainer(
  createMaterialTopTabNavigator(
    {
      UpcommingTrip: {
        screen: Upcomming,
        navigationOptions: {
          tabBarLabel: 'Upcomming',
        },
      },

      PastTrip: {
        screen: Past,
        navigationOptions: {
          tabBarLabel: 'Past',
        },
      },
    },
    {
      tabBarOptions: {
        style: {
          backgroundColor: '#660165',
          marginBottom: 30,
        },
        labelStyle: {
          fontSize: 12,
          // fontFamily:"Montserrat-bold",
          fontWeight: '800',
          // borderBottomColor:'#fff'
        },
        activeTintColor: '#ffff',
        inactiveTintColor: 'gray',
        indicatorStyle: {
          borderBottomColor: '#ffffff',
          borderBottomWidth: 4,
        },
      },
    },
  ),
);

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    sendAllTrips: trips => {
      dispatch({
        type: ALL_TRIPS,
        payload: trips,
      });
    },
    sendPastTrips: trips => {
      dispatch({
        type: PAST_TRIPS,
        payload: trips,
      });
    },
    sendUpcommingTrips: trips => {
      dispatch({
        type: UPCOMMING_TRIPS,
        payload: trips,
      });
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(MyTrips);
