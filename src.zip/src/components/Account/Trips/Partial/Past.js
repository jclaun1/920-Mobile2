import React from 'react';
import TripsComponent from './TripsComponent';
import {connect} from 'react-redux';

class Past extends React.Component {
  render() {
    if (this.props.pastTrips.length > 0) {
      return (
        <TripsComponent
          step={2}
          push={this.props.screenProps.push}
          navigation={this.props.navigation}
          trips={this.props.pastTrips}
        />
      );
    }

    return (
      <View style={styles.fromgroup}>
        <Text
          style={{
            textAlign: 'center',
            fontSize: 18,
            color: 'black',
            marginLeft: 10,
            fontFamily: 'Montserrat-Regular',
          }}>
          No past trips
        </Text>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    pastTrips: state.auth.pastTrips,
  };
};

export default connect(
  mapStateToProps,
  null,
)(Past);
