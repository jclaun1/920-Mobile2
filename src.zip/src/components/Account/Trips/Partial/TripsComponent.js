import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Alert,
  RefreshControl,
} from 'react-native';
import {
  ALL_TRIPS,
  PAST_TRIPS,
  UPCOMMING_TRIPS,
} from '../../../../redux/actions/types';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../../assets/css/style';
import EditTripInternational from '../EditTrips/EditTripInternational';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import EditdomesticTrip from '../EditTrips/EditdomesticTrip';
import EditLocallyTrip from '../EditTrips/EditLocallyTrip';
import {connect} from 'react-redux';
import {STORAGE_URL} from '../../../../config/env';
import Carousel from 'react-native-snap-carousel';
import axios from 'axios';
import orderBy from 'lodash/orderBy';
import moment from 'moment';

// const sliderWidth = Dimensions.get('window').width
// const itemWidth = sliderWidth

class TripsComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      trips: props.trips,
      past_lists: props.pastTrips,
      upcomming_trips: props.upCommingTrips,
      alltrips: props.alltrips,
      isLoading: false,
      refreshing: false,
      showModal: false,
      step: props.step,
      edit_1: false,
      edit_2: false,
      edit_3: false,
      trip: {},
      editIndex: null,
      activeSlide: 0,
      viewport: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
      },
    };
  }

  _showTripOrderBy(trips) {
    trips = orderBy(
      trips,
      function(o) {
        return new moment(o.travel_date, 'DD/MM/YYYY').format('YYYYMMDD');
      },
      ['desc'],
    );
    return trips;
  }

  async _spliting_trips(trips) {
    try {
      var past_lists = await this._showTripOrderBy(
        await trips.filter(val => {
          var traveldate_past = moment(val.travel_date, 'DD/MM/YYYY').format(
            'YYYY-MM-DD',
          );
          return (
            val.isCanceled ||
            (moment(traveldate_past).isBefore(moment().format('YYYY-MM-DD')) &&
              !val.isDeleted)
          );
        }),
      );

      var upcomming_trips = await this._showTripOrderBy(
        await trips.filter(val => {
          var traveldate_up = moment(val.travel_date, 'DD/MM/YYYY').format(
            'YYYY-MM-DD',
          );
          return (
            !val.isCanceled &&
            moment(traveldate_up).isSameOrAfter(
              moment().format('YYYY-MM-DD'),
            ) &&
            !val.isDeleted
          );
        }),
      );

      await this.props.sendPastTrips(past_lists);
      await this.props.sendUpcommingTrips(upcomming_trips);
      await this.props.sendAllTrips(trips);

      if (this.state.step == 1) {
        await this.setState({
          past_lists,
          upcomming_trips,
          trips: upcomming_trips,
          isLoading: false,
          refreshing: false,
        });
      } else {
        await this.setState({
          past_lists,
          upcomming_trips,
          trips: past_lists,
          isLoading: false,
          refreshing: false,
        });
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _editForm(type) {
    try {
      if (type === 1) {
        await this.setState({
          edit_1: true,
          edit_2: false,
          edit_3: false,
        });
      } else if (type === 2) {
        await this.setState({
          edit_1: false,
          edit_2: true,
          edit_3: false,
        });
      } else {
        await this.setState({
          edit_1: false,
          edit_2: false,
          edit_3: true,
        });
      }
    } catch (error) {
      // console.log(error)
      await this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
      });
    }
  }

  _filterOrderById(id, trips) {
    var index = trips.findIndex(trip => trip.id == id);
    if (index > -1) {
      return index;
    } else {
      return null;
    }
  }

  async _deleteCancleHandle(type, id) {
    this.setState({
      isLoading: true,
    });

    try {
      var index = null;
      var newarray = [...this.state.upcomming_trips];
      var pastrips = [...this.state.past_lists];
      if (type) {
        await axios.post('my/cancel/trip/' + id);
        index = await this._filterOrderById(id, this.state.upcomming_trips);
        pastrips.unshift(newarray[index]);
        newarray.splice(index, 1);

        await this.props.sendPastTrips(pastrips);
        await this.props.sendUpcommingTrips(newarray);

        await this.setState({
          past_lists: pastrips,
          upcomming_trips: newarray,
          trips: newarray,
          isLoading: false,
        });
        Alert.alert('Success', 'Successfully canceled trip.');
      } else {
        await axios.post('my/delete/trip/' + id);
        index = await this._filterOrderById(id, this.state.past_lists);
        await pastrips.splice(index, 1);

        await this.props.sendPastTrips(pastrips);
        await this.setState({
          past_lists: pastrips,
          trips: pastrips,
          isLoading: false,
        });

        Alert.alert('Success', 'Successfully deleted trip.');
      }
    } catch (error) {
      // console.log(error)

      await this.setState({
        isLoading: false,
      });

      Alert.alert('Opps!', 'Somthing went wrong.');
    }
  }

  _deleteCancleForm(type, id) {
    Alert.alert(
      'Are you sure?',
      type
        ? 'Are you sure want to cancel this trip, you can reactivate any time.'
        : 'Are you sure want to delete this trip.',
      [
        {text: 'Cancel', onPress: () => console.log('saved'), style: 'cancel'},
        {text: 'Okay', onPress: () => this._deleteCancleHandle(type, id)},
      ],
      {cancelable: false},
    );
  }

  async _handleEditResposne(data) {
    if (data) {
      await this.state.alltrips.splice(this.state.editIndex, 1);
      await this.state.alltrips.push(data);
      await Alert.alert('Success', 'Successfully trip updated.');
      this._spliting_trips(this.state.alltrips);
      this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
      });
    } else {
      this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
      });
    }
  }

  async _tripCall(id) {
    this.setState({
      isLoading: true,
    });
    try {
      let index = await this._filterOrderById(id, this.state.alltrips);
      let response = await axios.get('edit/trip/' + id);

      await this.setState({
        trip: response.data[1],
        editIndex: index,
      });

      await this._editForm(response.data[0]);

      await this.setState({
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)

      await this.setState({
        isLoading: false,
      });
      Alert.alert('Opps!', 'Somthing went wrong.');
    }
  }

  async mytrips(type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }
    try {
      let response = await axios.get('/my/trips');
      await this.setState({
        alltrips: response.data.data,
      });

      this.props.sendAllTrips(response.data.data);

      await this._spliting_trips(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        refreshing: false,
      });
    }
  }

  _editDeleteCancleButton(trip) {
    var cancleComponent = null;

    if (trip.order == 0) {
      cancleComponent = (
        <TouchableOpacity
          onPress={() =>
            this._deleteCancleForm(this.state.step == 1 ? 1 : 0, trip.id)
          }>
          <Text style={[styles.offer, styles.bgred]}>
            <FontAwesome
              name={this.state.step == 1 ? 'times' : 'trash-o'}
              size={18}
              style={{}}
            />{' '}
            {this.state.step == 1 ? 'Cancel' : 'Delete'}{' '}
          </Text>
        </TouchableOpacity>
      );
    }

    if (this.state.step == 1) {
      if (trip.order == 0) {
        return (
          <View style={styles.offercontainer}>
            <TouchableOpacity onPress={() => this._tripCall(trip.id)}>
              <Text style={[styles.offer, styles.bgyellow]}>
                <FontAwesome name="pencil" size={18} style={{}} /> Edit
              </Text>
            </TouchableOpacity>
            {cancleComponent}
          </View>
        );
      } else {
        return null;
      }
    } else {
      return (
        <View style={styles.offercontainer}>
          <TouchableOpacity onPress={() => this._tripCall(trip.id)}>
            <Text style={[styles.offer, styles.bgyellow]}>
              <FontAwesome name="refresh" size={18} style={{}} /> Edit &
              Reactivate
            </Text>
          </TouchableOpacity>
          {cancleComponent}
        </View>
      );
    }
  }

  _renderItem = (item, index) => {
    var trip = item.item;
    return (
      <View style={[styles.card, styles.shadow]}>
        <View style={{marginBottom: 10}}>
          <Text
            style={{
              fontSize: 17,
              color: '#000',
              fontFamily: 'Montserrat-semiBold',
              marginBottom: 5,
            }}>
            {trip.travel_from} - {trip.travel_to}
          </Text>
        </View>

        <Image
          style={styles.fitImage}
          source={{uri: STORAGE_URL + 'static/assets/images/trip.png'}}
          style={{height: 200}}
        />
        <View style={styles.adressbox}>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Traveling Date</Text>
            <Text style={[styles.addresstitel]}>{trip.traveldateF}</Text>
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Order</Text>
            {trip.order > 0 ? (
              <TouchableOpacity
                onPress={() =>
                  this.props.push('DeliveryOrders', {tripId: trip.id})
                }>
                <Text style={[styles.offer, styles.bggreen]}>{trip.order}</Text>
              </TouchableOpacity>
            ) : (
              <Text style={[styles.addresstitel]}>0</Text>
            )}
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>To Deliver</Text>
            {trip.orderGet > 0 ? (
              <TouchableOpacity
                onPress={() =>
                  this.props.push('DeliveryOrders', {tripId: trip.id})
                }>
                <Text style={[styles.offer, styles.bggreen]}>
                  {trip.orderGet}
                </Text>
              </TouchableOpacity>
            ) : (
              <Text style={[styles.addresstitel]}>0</Text>
            )}
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Earning</Text>
            <Text style={[styles.addresstitel]}>{trip.earned}</Text>
          </View>
        </View>

        {this._editDeleteCancleButton(trip)}
      </View>
    );
  };

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={() => this.mytrips(1)}
              style={{backgroundColor: 'transparent'}}
            />
          }>
          {this.state.edit_1 ? (
            <EditTripInternational
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowInternational={this.state.edit_1}
            />
          ) : null}
          {this.state.edit_2 ? (
            <EditdomesticTrip
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowDomestic={this.state.edit_2}
            />
          ) : null}
          {this.state.edit_3 ? (
            <EditLocallyTrip
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowLocal={this.state.edit_3}
            />
          ) : null}

          <View
            style={styles.container}
            onLayout={() => {
              this.setState({
                viewport: {
                  width: Dimensions.get('window').width,
                  height: Dimensions.get('window').height,
                },
              });
            }}>
            <Carousel
              ref={c => {
                this._carousel = c;
              }}
              data={this.state.trips}
              renderItem={this._renderItem}
              sliderWidth={this.state.viewport.width}
              itemWidth={this.state.viewport.width}
              onSnapToItem={index => this.setState({activeSlide: index})}
            />
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
    alltrips: state.auth.myTrips,
    pastTrips: state.auth.pastTrips,
    upCommingTrips: state.auth.upCommingTrips,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    sendAllTrips: trips => {
      dispatch({
        type: ALL_TRIPS,
        payload: trips,
      });
    },
    sendPastTrips: trips => {
      dispatch({
        type: PAST_TRIPS,
        payload: trips,
      });
    },
    sendUpcommingTrips: trips => {
      dispatch({
        type: UPCOMMING_TRIPS,
        payload: trips,
      });
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(TripsComponent);
