import React from 'react';
import TripsComponent from './TripsComponent';
import {View, Text} from 'react-native';
import {connect} from 'react-redux';
import styles from '../../../../../assets/css/style';

class Upcomming extends React.Component {
  render() {
    if (this.props.upCommingTrips.length > 0) {
      return (
        <TripsComponent
          step={1}
          push={this.props.screenProps.push}
          navigation={this.props.navigation}
          trips={this.props.upCommingTrips}
        />
      );
    }

    return (
      <View style={styles.fromgroup}>
        <Text
          style={{
            textAlign: 'center',
            fontSize: 18,
            color: 'black',
            marginLeft: 10,
            fontFamily: 'Montserrat-Regular',
          }}>
          No up comming trips
        </Text>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    upCommingTrips: state.auth.upCommingTrips,
  };
};

export default connect(
  mapStateToProps,
  null,
)(Upcomming);
