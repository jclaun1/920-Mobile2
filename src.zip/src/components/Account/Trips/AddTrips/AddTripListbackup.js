import React from 'react';
import {Text, View, ScrollView, TouchableOpacity} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../../../assets/css/style';
import {createMaterialTopTabNavigator} from 'react-navigation';
import AddTripInternational from './AddTripInternational';
import AddTripDomestic from './AddTripDomestic';
import AddTripLocal from './AddTripLocal';
import {connect} from 'react-redux';

class AddTripList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      step: 1,
    };
  }

  _addTripComponent() {
    if (this.state.step == 1) {
      return <AddTripInternational navigation={this.props.navigation} />;
    } else if (this.state.step == 2) {
      return <AddTripDomestic navigation={this.props.navigation} />;
    } else {
      return <AddTripLocal navigation={this.props.navigation} />;
    }
  }

  async componentWillMount() {
    await AsyncStorage.removeItem('submitdata');
  }

  render() {
    return (
      <ScrollView>
        <View style={styles.container}>
          <Text style={styles.allheading}>ADD YOUR TRIP</Text>
          <View style={styles.triptabgpmain}>
            <TouchableOpacity style={styles.triplisttabcolumntuch}>
              <Text
                onPress={() => this.setState({step: 1})}
                style={[
                  styles.triplisttabcolumn,
                  styles.bdrright,
                  this.state.step == 1 ? styles.triplisttabcolumnactive : null,
                ]}>
                International
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.triplisttabcolumntuch}>
              <Text
                onPress={() => this.setState({step: 2})}
                style={[
                  styles.triplisttabcolumn,
                  styles.bdrright,
                  this.state.step == 2 ? styles.triplisttabcolumnactive : null,
                ]}>
                Domestic
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.triplisttabcolumntuch}>
              <Text
                onPress={() => this.setState({step: 3})}
                style={[
                  styles.triplisttabcolumn,
                  styles.bdrright,
                  this.state.step == 3 ? styles.triplisttabcolumnactive : null,
                ]}>
                Local
              </Text>
            </TouchableOpacity>
          </View>
          {this._addTripComponent()}
        </View>
      </ScrollView>
    );
  }
}

const Tabs = createMaterialTopTabNavigator(
  {
    AddTripInternational: {
      screen: AddTripInternational,
      navigationOptions: {
        tabBarLabel: 'International',
      },
    },

    AddTripDomestic: {
      screen: AddTripDomestic,
      navigationOptions: {
        tabBarLabel: 'Domestic',
      },
    },

    AddTripLocal: {
      screen: AddTripLocal,
      navigationOptions: {
        tabBarLabel: 'Local',
      },
    },
  },
  {
    tabBarOptions: {
      style: {
        backgroundColor: '#660165',
      },
      labelStyle: {
        fontSize: 12,
        fontWeight: '500',
      },
      activeTintColor: '#ffff',
      inactiveTintColor: 'gray',
    },
  },
);

export default connect(
  null,
  null,
)(AddTripList);
