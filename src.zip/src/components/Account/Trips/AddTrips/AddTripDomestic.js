import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../../../assets/css/style';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import ModalFilterPicker from 'react-native-modal-filter-picker';
import GooglePlaces from '../../../Common/GooglePlaces';
import {DatePicker} from 'native-base';
import {connect} from 'react-redux';
import moment from 'moment';
import axios from 'axios';
import isEmpty from 'lodash/isEmpty';

class AddTripDomestic extends React.Component {
  constructor() {
    super();
    this.state = {
      isNotification: true,
      isLoading: true,
      visible: false,
      selectedCountry: {},
      fromShow: false,
      toShow: false,

      isAdded: false,
      travel_date: moment().format('DD/MM/YYYY'),

      address_from: '',
      country_from: '',
      country_code: '',
      lang_from: null,
      lat_from: null,
      state_from: '',

      address_to: '',
      country_to: '',
      lang_to: null,
      lat_to: null,
      state_to: '',

      country_list: [],
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
  }

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  async _handleFrom(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_from: data.formatted_address,
        country_from:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        state_from: state,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_to: data.formatted_address,
        country_to:
          data.address_components[data.address_components.length - 1].long_name,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        state_to: state,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  async _countryListCall() {
    try {
      var countryDatas = await AsyncStorage.getItem('countryDatas');
      var response;
      if (countryDatas) {
        response = JSON.parse(countryDatas);
      } else {
        let responseData = await axios.get('country/list');

        await AsyncStorage.setItem(
          'countryDatas',
          JSON.stringify(responseData.data),
        );
        response = responseData.data;
      }
      let responses = response;
      let countryList = [];
      await responses.forEach(element => {
        countryList.push({key: element.value, label: element.text});
      });

      await this.setState({
        country_list: countryList,
        isLoading: false,
      });
    } catch (error) {
      console.log(error);
      this.setState({
        isLoading: false,
      });
    }
  }

  _filterResult(indexkey) {
    const result = this.state.country_list.find(
      element => element.key === indexkey,
    );
    return result;
  }

  _onSelect = async picked => {
    try {
      let result = await this._filterResult(picked);
      this.setState({
        selectedCountry: {code: picked, name: result.label},
        visible: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        visible: false,
      });
    }
  };

  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      travel_to: this.state.address_to,
      country: this.state.selectedCountry.name,
      country_code: this.state.selectedCountry.code,
      state_from: this.state.state_from,
      state_to: this.state.state_to,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      notify: this.state.isNotification ? 1 : 0,
      isMobile: true,
    };
    return data;
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        {text: 'Okay', onPress: () => this.props.screenProps('EmailPhone')},
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
      ],
      {cancelable: false},
    );
  }

  async _checkPhone() {
    var data = await this._searchdata();

    var string = {
      items: data,
      isShop: 0,
      isOffer: 0,
      ShopType: 3,
      url: 'add/trip/domestic',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition();
        return false;
      }
    }

    return true;
  }

  async _handleSubmit() {
    if (this.state.isAdded) {
      return;
    }

    if (!this.state.selectedCountry.code) {
      Alert.alert('Oops!', 'select country');
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    let isAllow = await this._checkPhone();

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = this._searchdata();

      await axios.post('add/trip/domestic', data);

      this.setState({
        isAdded: true,
        isLoading: false,
      });

      Alert.alert('Success', 'Successfully trip added.');
      // console.log(response)
    } catch (error) {
      console.log(error);
      his.setState({
        isLoading: false,
      });
      Alert.alert('Success', 'server error.');
    }
  }

  handlerSwitchToggle = () => {
    this.setState({
      isNotification: !this.state.isNotification,
    });
  };

  componentDidMount() {
    console.log('jjhhhh');

    this._countryListCall();
  }

  render() {
    const pagestyle = StyleSheet.create({
      toggel: {
        height: 25,
        width: 28,
        borderRadius: 50,
        backgroundColor: '#fff',
      },
      toggelnotify: {
        left: this.state.isNotification ? 30 : 0,
      },
      switch: {
        height: 25,
        width: 60,
        borderRadius: 50,
      },
      switchnotify: {
        backgroundColor: this.state.isNotification ? '#660165' : '#ccc',
      },
    });

    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView>
          <View style={styles.container}>
            <View style={[styles.addTripbox, styles.shadow]}>
              <Text
                style={{
                  fontSize: 22,
                  fontFamily: 'Montserrat-semiBold',
                  textAlign: 'center',
                  marginBottom: 10,
                  color: '#660165',
                }}>
                Add trip
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  marginBottom: 10,
                  fontFamily: 'Montserrat-regular',
                }}>
                With a trip added, you can make multiple offers and make more
                money.
              </Text>

              <View style={styles.fromgroup} />
              <TouchableOpacity
                onPress={() => this.setState({visible: true})}
                style={styles.gpcountery}>
                <Text
                  style={{
                    fontSize: 16,
                    color: '#5d5d5d',
                    textAlign: 'left',
                    width: '100%',
                    paddingLeft: 25,
                  }}>
                  {this.state.selectedCountry.name
                    ? this.state.selectedCountry.name
                    : 'Country'}
                </Text>
              </TouchableOpacity>

              <ModalFilterPicker
                visible={this.state.visible}
                onSelect={this._onSelect}
                onCancel={() => this.setState({visible: false})}
                options={this.state.country_list}
              />

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  countryCode={this.state.selectedCountry.code}
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From city"
                />
              </View>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  countryCode={this.state.selectedCountry.code}
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To city"
                />
              </View>

              <View style={styles.datepiker}>
                <DatePicker
                  defaultDate={new Date()}
                  minimumDate={new Date()}
                  locale={'en'}
                  timeZoneOffsetInMinutes={undefined}
                  modalTransparent={false}
                  animationType={'fade'}
                  androidMode={'default'}
                  placeholder="DD/MM/YYY"
                  textStyle={{color: '#878787'}}
                  placeHolderTextStyle={{color: '#878787'}}
                  onDateChange={this._handleDatePicked}
                  style={{borderWidth: 1}}
                />
              </View>

              <View style={styles.toggelswitchmain}>
                <Text>GET NOTIFIED ABOUT NEW ORDERS</Text>
                <View style={[pagestyle.switch, pagestyle.switchnotify]}>
                  <TouchableOpacity
                    onPress={this.handlerSwitchToggle}
                    style={[pagestyle.toggel, pagestyle.toggelnotify]}>
                    <Text>{this.state.isNotification ? '' : ''}</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleSubmit()}>
                  <Text style={styles.Searchbtn}>Add</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(AddTripDomestic);
