import React from 'react';
import {View, Dimensions} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {
  createMaterialTopTabNavigator,
  createAppContainer,
} from 'react-navigation';
import AddTripInternational from './AddTripInternational';
import AddTripDomestic from './AddTripDomestic';
import AddTripLocal from './AddTripLocal';
import NonScreenHeader from '../../../Menu/NonScreenHeader';
import {connect} from 'react-redux';
const fontsizerwidth = Dimensions.get('screen').width;

const fontSizer = screenWidth => {
  if (screenWidth > 400) {
    return 11;
  } else if (screenWidth > 360) {
    return 10;
  } else if (screenWidth > 250) {
    return 9;
  } else {
    return 8;
  }
};
class AddTripList extends React.Component {
  async componentDidMount() {
    await AsyncStorage.removeItem('submitdata');
  }

  static navigationOptions = ({navigation}) => {
    return {
      header: (
        <NonScreenHeader
          notHome={true}
          title="Add Trip List"
          navigate={navigation}
        />
      ),
    };
  };

  render() {
    return (
      <View style={{flex: 1}}>
        <Tabs screenProps={this.props.navigation.push} />
      </View>
    );
  }
}

const Tabs = createAppContainer(
  createMaterialTopTabNavigator(
    {
      AddTripInternational: {
        screen: AddTripInternational,
        navigationOptions: {
          tabBarLabel: 'International',
        },
      },

      AddTripDomestic: {
        screen: AddTripDomestic,
        navigationOptions: {
          tabBarLabel: 'Domestic',
        },
      },

      AddTripLocal: {
        screen: AddTripLocal,
        navigationOptions: {
          tabBarLabel: 'Local',
        },
      },
    },
    {
      tabBarOptions: {
        style: {
          backgroundColor: '#660165',
          marginBottom: 30,
        },
        labelStyle: {
          fontSize: fontSizer(fontsizerwidth),
          fontFamily: 'Montserrat-Bold',
        },
        activeTintColor: '#ffff',
        inactiveTintColor: 'gray',
        indicatorStyle: {
          borderBottomColor: '#ffffff',
          borderBottomWidth: 4,
        },
      },
    },
  ),
);

export default connect(
  null,
  null,
)(AddTripList);
