import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../../../assets/css/style';
import GooglePlaces from '../../../Common/GooglePlaces';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import moment from 'moment';
import {DatePicker, Picker, Icon} from 'native-base';
import {connect} from 'react-redux';
import axios from 'axios';
import isEmpty from 'lodash/isEmpty';
class AddTripLocal extends React.Component {
  constructor() {
    super();
    this.state = {
      isNotification: true,
      isLoading: false,
      fromShow: true,
      toShow: true,
      localCityShow: true,

      isAdded: false,
      travel_date: '',

      address_from: '',
      lang_from: null,
      lat_from: null,
      state_from: '',

      address_to: '',
      country_to: '',
      lang_to: null,
      lat_to: null,
      state_to: '',

      citydetails: {},
      city: '',
      country_code: '',
      country: '',
      hour: '03',
      minute: '15',
      convention: 'PM',
    };

    this._handleLocalCity = this._handleLocalCity.bind(this);
    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
  }

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  _hourManage(value) {
    this.setState({
      hour: value,
    });
  }

  _minuteManage(value) {
    this.setState({
      minute: value,
    });
  }

  _conventionManage(value) {
    this.setState({
      convention: value,
    });
  }

  async _handleLocalCity(data) {
    try {
      await this.setState({
        citydetails: {
          lang: data.geometry.location.lng,
          lat: data.geometry.location.lat,
        },
        country:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        city: data.formatted_address,
        localCityShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        address_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      travel_to: this.state.address_to,
      country: this.state.country,
      country_code: this.state.country_code,
      city: this.state.city,
      city_lat: this.state.citydetails.lat,
      city_lang: this.state.citydetails.lang,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      hour: this.state.hour,
      minute: this.state.minute,
      convention: this.state.convention,
      notify: this.state.isNotification ? 1 : 0,
    };
    return data;
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        {text: 'Okay', onPress: () => this.props.screenProps('EmailPhone')},
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
      ],
      {cancelable: false},
    );
  }

  async _checkPhone() {
    var data = await this._searchdata();

    var string = {
      items: data,
      isShop: 0,
      isOffer: 0,
      ShopType: 3,
      url: 'add/trip/locally',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition();
        return false;
      }
    }

    return true;
  }

  async _handleSubmit() {
    if (this.state.isAdded) {
      return;
    }

    if (!this.state.country_code) {
      Alert.alert('Oops!', 'enter local city');
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    let isAllow = await this._checkPhone();

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = this._searchdata();

      await axios.post('add/trip/locally', data);

      this.setState({
        isAdded: true,
        isLoading: false,
      });

      Alert.alert('Success', 'Successfully trip added.');
    } catch (error) {
      // console.log(error)
      console.log(error);
      his.setState({
        isLoading: false,
      });
      Alert.alert('Success', 'server error.');
    }
  }

  handlerSwitchToggle = () => {
    this.setState({
      isNotification: !this.state.isNotification,
    });
  };

  _fromToElement() {
    if (this.state.citydetails) {
      return (
        <View>
          <GooglePlaces
            cityDetails={this.state.citydetails}
            countryCode={this.state.country_code}
            isLocal={true}
            listDisplayed={this.state.fromShow}
            onSelectAddress={this._handleFrom}
            placeHolder="From Locality"
          />
          <GooglePlaces
            cityDetails={this.state.citydetails}
            countryCode={this.state.country_code}
            isLocal={true}
            listDisplayed={this.state.toShow}
            onSelectAddress={this._handleTo}
            placeHolder="To Locality"
          />
        </View>
      );
    } else {
      return (
        <View>
          {' '}
          <View style={styles.fromgroup}>
            <TextInput
              style={styles.inputbox}
              placeholder="From Locality"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
            />
          </View>
          <View style={styles.fromgroup}>
            <TextInput
              style={styles.inputbox}
              placeholder="To Locality"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
            />
          </View>
        </View>
      );
    }
  }

  render() {
    const pagestyle = StyleSheet.create({
      toggel: {
        height: 25,
        width: 28,
        borderRadius: 50,
        backgroundColor: '#fff',
      },
      toggelnotify: {
        left: this.state.isNotification ? 30 : 0,
      },
      switch: {
        height: 25,
        width: 60,
        borderRadius: 50,
      },
      switchnotify: {
        backgroundColor: this.state.isNotification ? '#660165' : '#ccc',
      },
    });
    var hours = [];
    var minutes = [];

    minutes.push(<Picker.Item key="00" label="00" value="00" />);

    for (let index = 1; index < 25; index++) {
      var hourel = index < 10 ? '0' + index : String(index);
      hours.push(<Picker.Item key={index} label={hourel} value={hourel} />);
    }

    for (let indexel = 1; indexel < 55; indexel++) {
      indexel = indexel + 4;
      var minuteel = indexel < 10 ? '0' + indexel : String(indexel);

      minutes.push(
        <Picker.Item key={indexel} label={minuteel} value={minuteel} />,
      );
    }

    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView>
          <View style={styles.container}>
            <View style={[styles.addTripbox, styles.shadow]}>
              <Text
                style={{
                  fontSize: 22,
                  fontFamily: 'Montserrat-semiBold',
                  textAlign: 'center',
                  marginBottom: 10,
                  color: '#660165',
                }}>
                Add trip
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  marginBottom: 10,
                  fontFamily: 'Montserrat-regular',
                }}>
                With a trip added, you can make multiple offers and make more
                money.
              </Text>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  listDisplayed={this.state.localCityShow}
                  onSelectAddress={this._handleLocalCity}
                  placeHolder="Choose Local City"
                />
              </View>
              <View style={styles.googlefromGp}>
                <GooglePlaces
                  cityDetails={this.state.citydetails}
                  countryCode={this.state.country_code}
                  isLocal={true}
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From Locality"
                />
              </View>
              <View style={styles.googlefromGp}>
                <GooglePlaces
                  cityDetails={this.state.citydetails}
                  countryCode={this.state.country_code}
                  isLocal={true}
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To Locality"
                />
              </View>
              {/* {this._fromToElement()} */}
              <View style={styles.datepiker}>
                <DatePicker
                  defaultDate={new Date()}
                  minimumDate={new Date()}
                  locale={'en'}
                  timeZoneOffsetInMinutes={undefined}
                  modalTransparent={false}
                  animationType={'fade'}
                  androidMode={'default'}
                  placeholder="DD/MM/YYY"
                  textStyle={{color: '#878787'}}
                  placeHolderTextStyle={{color: '#878787'}}
                  onDateChange={this._handleDatePicked}
                />
              </View>

              <View style={styles.fromgroup}>
                <View>
                  <Text
                    style={{
                      fontSize: 15,
                      fontFamily: 'Montserrat-SemiBold',
                      color: '#000',
                    }}>
                    By What Time You Will Reach There
                  </Text>
                </View>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginVertical: 10,
                  }}>
                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select hour"
                      iosIcon={<Icon name="md-arrow-down" />}
                      style={{width: undefined}}
                      selectedValue={this.state.hour}
                      onValueChange={this._hourManage.bind(this)}>
                      {hours}
                    </Picker>
                  </View>
                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select minute"
                      iosIcon={<Icon name="md-arrow-down" />}
                      style={{width: undefined}}
                      selectedValue={this.state.minute}
                      onValueChange={this._minuteManage.bind(this)}>
                      {minutes}
                    </Picker>
                  </View>
                  <View style={styles.timepiker}>
                    <Picker
                      mode="dropdown"
                      iosHeader="Select convention"
                      iosIcon={<Icon name="md-arrow-down" />}
                      style={{width: undefined}}
                      selectedValue={this.state.convention}
                      onValueChange={this._conventionManage.bind(this)}>
                      <Picker.Item label="AM" value="AM" />
                      <Picker.Item label="PM" value="PM" />
                    </Picker>
                  </View>
                </View>
              </View>

              <View style={styles.toggelswitchmain}>
                <Text>GET NOTIFIED ABOUT NEW ORDERS</Text>
                <View style={[pagestyle.switch, pagestyle.switchnotify]}>
                  <TouchableOpacity
                    onPress={this.handlerSwitchToggle}
                    style={[pagestyle.toggel, pagestyle.toggelnotify]}>
                    <Text>{this.state.isNotification ? '' : ''}</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleSubmit()}>
                  <Text style={styles.Searchbtn}>Add</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(AddTripLocal);
