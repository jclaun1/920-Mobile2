import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import GooglePlaces from '../../../Common/GooglePlaces';
import styles from '../../../../../assets/css/style';
import OrderSubmitting from '../../../Common/OrderSubmitting';
import moment from 'moment';
import {DatePicker} from 'native-base';
import {connect} from 'react-redux';
import axios from 'axios';
import isEmpty from 'lodash/isEmpty';

class AddTripInternational extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isDateTimePickerVisible: false,
      isNotification: true,
      isLoading: false,
      isAdded: false,
      travel_date: '',

      address_from: '',
      country_from: '',
      country_code: '',
      lang_from: null,
      lat_from: null,

      address_to: '',
      country_to: '',
      lang_to: null,
      lat_to: null,

      fromShow: true,
      toShow: true,
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
    this._issamecountry = this._issamecountry.bind(this);
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  handlerSwitchToggle = () => {
    this.setState({
      isNotification: !this.state.isNotification,
    });
  };

  _showDateTimePicker = () => this.setState({isDateTimePickerVisible: true});

  _hideDateTimePicker = () => this.setState({isDateTimePickerVisible: false});

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
    this._hideDateTimePicker();
  };

  async _issamecountry(forplace) {
    try {
      await Alert.alert(
        'Opps!',
        'Hey :) Please choose the two different countries',
      );
    } catch (error) {
      // console.log(error);
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        address_from: data.formatted_address,
        country_from:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(1);
      }
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        address_to: data.formatted_address,
        country_to:
          data.address_components[data.address_components.length - 1].long_name,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(0);
      }
    } catch (error) {
      // console.log(error)
    }
  }

  _searchdata() {
    const data = {
      travel_from: this.state.address_from,
      travel_to: this.state.address_to,
      country_from: this.state.country_from,
      country_to: this.state.country_to,
      country: this.state.country_from,
      country_code: this.state.country_code,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      notify: this.state.isNotification ? 1 : 0,
      isMobile: true,
    };
    return data;
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        {text: 'Okay', onPress: () => this.props.screenProps('EmailPhone')},
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
      ],
      {cancelable: false},
    );
  }

  async _checkPhone() {
    var data = await this._searchdata();

    var string = {
      items: data,
      isShop: 0,
      isOffer: 0,
      ShopType: 3,
      url: 'add/trip/international',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition();
        return false;
      }
    }

    return true;
  }

  async _handleSubmit() {
    if (this.state.isAdded) {
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    if (this.state.country_from === this.state.country_to) {
      this._issamecountry(0);
      return;
    }
    // console.log(this.state.country_from, this.state.country_to)
    // return

    let isAllow = await this._checkPhone();

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = await this._searchdata();
      await axios.post('add/trip/international', data);
      this.setState({
        isAdded: true,
        isLoading: false,
      });

      Alert.alert('Success', 'Successfully trip added.');
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
      Alert.alert('Opps!', 'somthing went wrong');
    }
  }

  render() {
    const pagestyle = StyleSheet.create({
      toggel: {
        height: 25,
        width: 28,
        borderRadius: 50,
        backgroundColor: '#fff',
      },
      toggelnotify: {
        left: this.state.isNotification ? 30 : 0,
      },
      switch: {
        height: 25,
        width: 60,
        borderRadius: 50,
      },
      switchnotify: {
        backgroundColor: this.state.isNotification ? '#660165' : '#ccc',
      },
    });

    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView>
          <View style={styles.container}>
            <View style={[styles.addTripbox, styles.shadow]}>
              {/* <Text style={{ fontSize: 22,fontFamily:'Montserrat-semiBold',textAlign: 'center', marginBottom: 10, color: '#660165', }}>Add trip</Text> */}
              <Text
                style={{
                  textAlign: 'center',
                  marginBottom: 10,
                  fontFamily: 'Montserrat-regular',
                }}>
                With a trip added, you can make multiple offers and make more
                money.
              </Text>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From city/country"
                />
              </View>

              <View style={styles.googlefromGp}>
                <GooglePlaces
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To city/country"
                />
              </View>

              <View style={styles.datepiker}>
                <DatePicker
                  defaultDate={new Date()}
                  minimumDate={new Date()}
                  locale={'en'}
                  timeZoneOffsetInMinutes={undefined}
                  modalTransparent={false}
                  animationType={'fade'}
                  androidMode={'default'}
                  placeholder="DD/MM/YYY"
                  textStyle={{color: '#878787'}}
                  placeHolderTextStyle={{color: '#878787'}}
                  onDateChange={this._handleDatePicked}
                  style={{borderWidth: 1}}
                />
              </View>

              <View style={styles.toggelswitchmain}>
                <Text>GET NOTIFIED ABOUT NEW ORDERS</Text>
                <View style={[pagestyle.switch, pagestyle.switchnotify]}>
                  <TouchableOpacity
                    onPress={this.handlerSwitchToggle}
                    style={[pagestyle.toggel, pagestyle.toggelnotify]}>
                    <Text>{this.state.isNotification ? '' : ''}</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this._handleSubmit()}>
                  <Text style={styles.Searchbtn}>Add</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(AddTripInternational);
