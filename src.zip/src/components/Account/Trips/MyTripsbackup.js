import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Alert,
  RefreshControl,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from '../../../../assets/css/style';
import EditTripInternational from './EditTrips/EditTripInternational';
import EditdomesticTrip from './EditTrips/EditdomesticTrip';
import EditLocallyTrip from './EditTrips/EditLocallyTrip';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {connect} from 'react-redux';
import {STORAGE_URL} from '../../../config/env';
import Carousel from 'react-native-snap-carousel';
import moment from 'moment';
import axios from 'axios';

import NewHeader from '../../Menu/NewHeader';

const sliderWidth = Dimensions.get('window').width;
const itemWidth = sliderWidth;
import _ from 'lodash';

class MyTrips extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      past_lists: [],
      upcomming_trips: [],
      trips: [],
      alltrips: [],
      isLoading: false,
      refreshing: false,
      showModal: false,
      step: 1,
      edit_1: false,
      edit_2: false,
      edit_3: false,
      trip: {},
      editIndex: null,
      activeSlide: 0,
    };
  }

  static navigationOptions = ({navigation}) => {
    return {
      header: (
        <NewHeader
          isAddtrip={true}
          isHome={true}
          title="My Trips"
          navigate={navigation}
        />
      ),
    };
  };

  componentWillMount() {
    this.mytrips(0);
  }

  async _stepFun(step) {
    await this.setState({
      isLoading: true,
    });

    try {
      if (step == 1) {
        await this.setState({
          step: step,
          trips: this.state.upcomming_trips,
          isLoading: false,
        });
      } else {
        await this.setState({
          step: step,
          trips: this.state.past_lists,
          isLoading: false,
        });
      }
    } catch (error) {
      this.setState({
        isLoading: false,
      });
      // console.log(error)
    }
  }

  _showTripOrderBy(trips) {
    trips = _.orderBy(
      trips,
      function(o) {
        return new moment(o.travel_date, 'DD/MM/YYYY').format('YYYYMMDD');
      },
      ['desc'],
    );
    return trips;
  }

  async _spliting_trips(trips, type) {
    try {
      await this.setState({
        past_lists: this._showTripOrderBy(
          trips.filter(val => {
            var traveldate_past = moment(val.travel_date, 'DD/MM/YYYY').format(
              'YYYY-MM-DD',
            );
            return (
              val.isCanceled ||
              (moment(traveldate_past).isBefore(
                moment().format('YYYY-MM-DD'),
              ) &&
                !val.isDeleted)
            );
          }),
        ),

        upcomming_trips: this._showTripOrderBy(
          trips.filter(val => {
            var traveldate_up = moment(val.travel_date, 'DD/MM/YYYY').format(
              'YYYY-MM-DD',
            );
            return (
              !val.isCanceled &&
              moment(traveldate_up).isSameOrAfter(
                moment().format('YYYY-MM-DD'),
              ) &&
              !val.isDeleted
            );
          }),
        ),
      });
      this._stepFun(type ? type : 1);
    } catch (error) {
      // console.log(error)
    }
  }

  async mytrips(type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }
    try {
      let response = await axios.get('/my/trips');
      await this.setState({
        alltrips: response.data.data,
        refreshing: false,
      });

      await this._spliting_trips(response.data.data);
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        refreshing: false,
      });
    }
  }

  async _editForm(type) {
    try {
      if (type === 1) {
        await this.setState({
          edit_1: true,
          edit_2: false,
          edit_3: false,
        });
      } else if (type === 2) {
        await this.setState({
          edit_1: false,
          edit_2: true,
          edit_3: false,
        });
      } else {
        await this.setState({
          edit_1: false,
          edit_2: false,
          edit_3: true,
        });
      }
    } catch (error) {
      // console.log(error)
      await this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
      });
    }
  }

  _filterOrderById(id, trips) {
    var index = trips.findIndex(trip => trip.id == id);
    if (index > -1) {
      return index;
    } else {
      return null;
    }
  }

  async _deleteCancleHandle(type, id) {
    this.setState({
      isLoading: true,
    });

    try {
      var index = null;
      var newarray = [...this.state.upcomming_trips];
      var pastrips = [...this.state.past_lists];
      if (type) {
        let response = await axios.post('my/cancel/trip/' + id);
        index = await this._filterOrderById(id, this.state.upcomming_trips);
        pastrips.unshift(newarray[index]);
        newarray.splice(index, 1);
        await this.setState({
          past_lists: pastrips,
          upcomming_trips: newarray,
          trips: newarray,
          isLoading: false,
        });
        Alert.alert('Success', 'Successfully canceled trip.');
      } else {
        let response = await axios.post('my/delete/trip/' + id);
        index = await this._filterOrderById(id, this.state.past_lists);
        await pastrips.splice(index, 1);
        await this.setState({
          past_lists: pastrips,
          trips: pastrips,
          isLoading: false,
        });

        Alert.alert('Success', 'Successfully deleted trip.');
      }
    } catch (error) {
      // console.log(error)

      await this.setState({
        isLoading: false,
      });

      Alert.alert('Opps!', 'Somthing went wrong.');
    }
  }

  _deleteCancleForm(type, id) {
    Alert.alert(
      'Are you sure?',
      type
        ? 'Are you sure want to cancel this trip, you can reactivate any time.'
        : 'Are you sure want to delete this trip.',
      [
        {text: 'Cancel', onPress: () => console.log('saved'), style: 'cancel'},
        {text: 'Okay', onPress: () => this._deleteCancleHandle(type, id)},
      ],
      {cancelable: false},
    );
  }

  async _handleEditResposne(data) {
    if (data) {
      await this.state.alltrips.splice(this.state.editIndex, 1);
      await this.state.alltrips.push(data);
      await Alert.alert('Success', 'Successfully trip updated.');
      this._spliting_trips(this.state.alltrips, this.state.step);
      this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
        step: this.state.step,
      });
    } else {
      this.setState({
        edit_1: false,
        edit_2: false,
        edit_3: false,
        step: this.state.step,
      });
    }
  }

  async _tripCall(id) {
    this.setState({
      isLoading: true,
    });
    try {
      let index = await this._filterOrderById(id, this.state.alltrips);
      let response = await axios.get('edit/trip/' + id);

      await this.setState({
        trip: response.data[1],
        editIndex: index,
      });

      await this._editForm(response.data[0]);

      await this.setState({
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)

      await this.setState({
        isLoading: false,
      });
      Alert.alert('Opps!', 'Somthing went wrong.');
    }
  }

  _editDeleteCancleButton(trip) {
    var cancleComponent = null;

    if (trip.order == 0) {
      cancleComponent = (
        <TouchableOpacity
          onPress={() =>
            this._deleteCancleForm(this.state.step == 1 ? 1 : 0, trip.id)
          }>
          <Text style={[styles.offer, styles.bgred]}>
            <FontAwesome
              name={this.state.step == 1 ? 'times' : 'trash-o'}
              size={18}
              style={{}}
            />{' '}
            {this.state.step == 1 ? 'Cancel' : 'Delete'}{' '}
          </Text>
        </TouchableOpacity>
      );
    }

    if (this.state.step == 1) {
      if (trip.order == 0) {
        return (
          <View style={styles.offercontainer}>
            <TouchableOpacity onPress={() => this._tripCall(trip.id)}>
              <Text style={[styles.offer, styles.bgyellow]}>
                <FontAwesome name="pencil" size={18} style={{}} /> Edit
              </Text>
            </TouchableOpacity>
            {cancleComponent}
          </View>
        );
      } else {
        return null;
      }
    } else {
      return (
        <View style={styles.offercontainer}>
          <TouchableOpacity onPress={() => this._tripCall(trip.id)}>
            <Text style={[styles.offer, styles.bgyellow]}>
              <FontAwesome name="refresh" size={18} style={{}} /> Edit &
              Reactivate
            </Text>
          </TouchableOpacity>
          {cancleComponent}
        </View>
      );
    }
  }

  _renderItem = (item, index) => {
    var trip = item.item;
    return (
      <View style={[styles.card, styles.shadow]}>
        <View style={{marginBottom: 10}}>
          <Text
            style={{
              fontSize: 17,
              color: '#000',
              fontFamily: 'Montserrat-semiBold',
              marginBottom: 5,
            }}>
            {trip.travel_from} - {trip.travel_to}
          </Text>
        </View>

        <Image
          style={styles.fitImage}
          source={{uri: STORAGE_URL + 'static/assets/images/trip.png'}}
          style={{height: 200}}
        />
        <View style={styles.adressbox}>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Traveling Date</Text>
            <Text style={[styles.addresstitel]}>{trip.traveldateF}</Text>
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Order</Text>
            <Text style={[styles.addresstitel]}>{trip.order}</Text>
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>To Deliver</Text>
            <Text style={[styles.addresstitel]}>{trip.orderGet}</Text>
          </View>
          <View style={styles.tripaddresslistbox}>
            <Text style={styles.addresstitel}>Earning</Text>
            <Text style={[styles.addresstitel]}>{trip.earned}</Text>
          </View>
        </View>

        {this._editDeleteCancleButton(trip)}
      </View>
    );
  };

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={() => this.mytrips(1)}
              style={{backgroundColor: 'transparent'}}
            />
          }>
          {this.state.edit_1 ? (
            <EditTripInternational
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowInternational={this.state.edit_1}
            />
          ) : null}
          {this.state.edit_2 ? (
            <EditdomesticTrip
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowDomestic={this.state.edit_2}
            />
          ) : null}
          {this.state.edit_3 ? (
            <EditLocallyTrip
              trip={this.state.trip}
              onClose={data => this._handleEditResposne(data)}
              isShowLocal={this.state.edit_3}
            />
          ) : null}

          <View style={styles.container}>
            <View
              style={{
                width: '99%',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexDirection: 'row',
                marginBottom: 10,
                marginTop: 10,
                marginHorizontal: 10,
              }}>
              <Text
                style={{
                  fontSize: 20,
                  color: '#660165',
                  fontFamily: 'Montserrat-semiBold',
                }}>
                Your Trips
              </Text>
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('AddTripList')}>
                <Text style={styles.addtrippbtn}>Add Trip</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.triptabgpmain}>
              <TouchableOpacity
                style={[
                  styles.triptabcolumntuch,
                  styles.bdrright,
                  this.state.step == 1 ? styles.triptabcolumntuchactiv : null,
                ]}
                onPress={() => this._stepFun(1)}>
                <Text
                  style={[
                    styles.triptabcolumn,
                    this.state.step == 1 ? styles.triptabcolumnactive : null,
                  ]}
                  onPress={() => this._stepFun(1)}>
                  Upcoming Trips
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.triptabcolumntuch,
                  styles.bdrright,
                  this.state.step == 2 ? styles.triptabcolumntuchactiv : null,
                ]}
                onPress={() => this._stepFun(2)}>
                <Text
                  style={[
                    styles.triptabcolumn,
                    this.state.step == 2 ? styles.triptabcolumnactive : null,
                  ]}
                  onPress={() => this._stepFun(2)}>
                  Past Trips
                </Text>
              </TouchableOpacity>
            </View>

            <Carousel
              ref={c => {
                this._carousel = c;
              }}
              data={this.state.trips}
              renderItem={this._renderItem}
              sliderWidth={sliderWidth}
              itemWidth={itemWidth}
              onSnapToItem={index => this.setState({activeSlide: index})}
            />
          </View>
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(MyTrips);
