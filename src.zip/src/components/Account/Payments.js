import React from 'react';
import { Text, View, ScrollView, RefreshControl, Image } from 'react-native'
import styles from '../../../assets/css/style'
import OrderSubmitting from '../Common/OrderSubmitting'
import { connect } from 'react-redux'
import axios from 'axios'
import InvoiceDetails from './Payments/InvoiceDetails'
import NewHeader from '../Menu/NewHeader'

class Payments extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      isLoading: true,
      refreshing: false,
      isModal: false,
      payment: {},
      payments: []
    }

    this.mypayments(0)
  }

  static navigationOptions = ({ navigation }) => {
    return {
      header: <NewHeader isHome={false} title="My Payments" navigate={navigation} />
    }
  }

  _showDetails(payment) {
    this.setState({
      payment,
      isModal: true
    })
  }

  async mypayments(type) {
    if (type) {
      this.setState({
        refreshing: true,
      })
    } else {
      // this.setState({
      //     isLoading: true
      // })
    }
    try {
      let response = await axios.get('my/payments')

      await this.setState({
        payments: response.data.data,
        isLoading: false,
        refreshing: false
      })

    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
        refreshing: false
      })
    }
  }

  status(status) {
    if (status == 1) {
      return 'No action'
    }

    if (status == 2) {
      return 'Canceled'
    }

    if (status == 3) {
      return 'Not completed'
    }

    if (status == 4) {
      return 'Success'
    }
  }

  action(payment) {
    if (payment.status == 1 || payment.status == 2 || payment.status == 3) {
      // return '/check-out/' + payment.slug+'/'+payment.offer_id
      return this.props.navigation.navigate('CheckOut', { slug: payment.order_slug, offerId: payment.offer_id })
    }
    return this.props.navigation.navigate('OrderConfirm', { slug: payment.slug })
  }

  render() {
    if (this.state.isLoading && !this.state.isModal) {
      return (
        <OrderSubmitting />
      )
    } else if (!this.state.isLoading && this.state.isModal) {
      return (
        <InvoiceDetails isModal={this.state.isModal} payment={this.state.payment} currency={this.props.currency} onClose={() => this.setState({ isModal: false })} />
      )
    } else {
      return (
        <View style={styles.container}>

          <View style={[styles.card, styles.shadow]}>

            <View style={styles.paymentsaction}>
              <Text style={[styles.paymentrole, styles.fontbold]}>Invoice</Text>
              <Text style={[styles.paymentrole, styles.fontbold]}>Status</Text>
              <Text style={[styles.paymentrole, styles.fontbold]}>Action</Text>
            </View>

            <ScrollView
              refreshControl={
                <RefreshControl
                  refreshing={this.state.refreshing}
                  onRefresh={() => this.mypayments(1)}
                  style={{ backgroundColor: 'transparent' }}
                />}>
              {
                this.state.payments.length > 0 ? this.state.payments.map((payment, index) => {
                  return (
                    <View style={styles.paymentsaction} key={index}>
                      <Image
                        source={require('../../../assets/images/ic_bill.png')}
                        style={{
                          height: 40, width: 40, marginLeft: 15, resizeMode: 'cover',
                          alignSelf: 'center'
                        }}
                      />
                      <View style={[styles.paymentrole,{flex:2,marginLeft:10,justifyContent:'center',marginRight:10}]}>
                        <Text onPress={() => this._showDetails(payment)} style={[styles.paymentrole, styles.linkcolor]}>
                          {payment.invoiceID}
                        </Text>
                        <Text style={styles.paymentrole}>{this.status(payment.status)}</Text>
                      </View>

                      {/* <TouchableOpacity onPress={() => this.action(payment)}> */}
                      <Text onPress={() => this.action(payment)} style={[styles.paymentrole, styles.linkcolor]}>Action</Text>
                      {/* </TouchableOpacity> */}
                    </View>
                  )
                }) : <View style={styles.fromgroup}>
                    <Text style={{
                      textAlign: 'center',
                      fontSize: 18, color: 'black', marginLeft: 10,
                      fontFamily: 'OpenSans-Regular',
                    }}>
                      No  payment found
                        </Text>
                  </View>
              }
            </ScrollView>

          </View>

        </View>
      )
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency
  }
}

export default connect(mapStateToProps, null)(Payments)
