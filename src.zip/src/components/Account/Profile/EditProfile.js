import React from 'react';
import {
  Text,
  View,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  StatusBar,
} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import OrderSubmitting from '../../Common/OrderSubmitting';
import {Card, Avatar} from 'react-native-elements';
import {STORAGE_URL} from '../../../config/env';
import styles from '../../../../assets/css/style';
import {connect} from 'react-redux';
import ImagePicker from 'react-native-image-picker';

import axios from 'axios';
class EditProfile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      first_name: '',
      last_name: '',
      bio: '',
      avatar: '',
      isLoading: true,
    };
  }

  static navigationOptions = {
    headerStyle: {
      backgroundColor: '#660165',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  componentDidMount() {
    if (this.props.user) {
      this.setState({
        first_name: this.props.user.first_name,
        last_name: this.props.user.last_name,
        avatar: this.props.user.avatar,
        isLoading: false,
      });
    } else {
      this.setState({
        isLoading: true,
      });
    }
  }

  async _updateAvatar(file) {
    this.setState({
      isLoading: true,
    });
    try {
      let response = await axios.post('update/avatar', {
        image: file,
        isMobile: true,
      });
      this.props.updateUserData(response.data.data);
      this.avatar = response.data.data.avatar;
      this.setState({
        avatar: response.data.data.avatar,
        isLoading: false,
      });
      Alert.alert('Success!', 'Successfully profile picture updated!');
    } catch (error) {
      console.log(error);

      Alert.alert('Opps!', 'Somthing went wrong!');
      this.setState({
        isLoading: false,
      });
    }
  }

  async _chooseImage() {
    var options = {
      maxWidth: 1000,
      maxHeight: 1000,
      mediaType: 'photo',
      allowsEditing: true,
    };

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        this._updateAvatar(response.data);
      }
    });
  }

  async updateProfile() {
    this.setState({
      isLoading: true,
    });
    try {
      const data = {
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        bio: this.state.bio,
      };

      let response = await axios.post('/update/profile', data);

      this.props.updateUserData(response.data.data);
      this.setState({
        isLoading: false,
      });

      Alert.alert('Success!', 'Successfully profile updated!');
    } catch (error) {
      console.log(error);
      Alert.alert('Opps!', 'Somthing went wrong!');
      this.setState({
        isLoading: false,
      });
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <ScrollView>
          <StatusBar backgroundColor="#660165" barStyle="light-content" />

          <View style={styles.container}>
            <View style={[styles.card, styles.shadow]}>
              <View style={styles.userprofile}>
                <Card>
                  <Avatar
                    xlarge
                    rounded
                    source={{
                      uri: this.state.avatar
                        ? this.state.avatar
                        : STORAGE_URL +
                          'static/assets/images/profile-up-img.png',
                    }}
                    activeOpacity={0.7}
                  />
                  <TouchableOpacity onPress={() => this._chooseImage()}>
                    <MaterialIcons
                      name="edit"
                      size={22}
                      Style={styles.editicon}
                    />
                  </TouchableOpacity>
                </Card>
              </View>

              <View style={styles.fromgroup}>
                <View>
                  <Text style={styles.inputlabel}>First Name</Text>
                </View>
                <TextInput
                  style={styles.inputbox}
                  placeholderTextColor="#878787"
                  underlineColorAndroid="rgba(0, 0, 0,0)"
                  value={this.state.first_name}
                  onChangeText={first_name => this.setState({first_name})}
                />
              </View>
              <View style={styles.fromgroup}>
                <View>
                  <Text style={styles.inputlabel}>Last Name</Text>
                </View>
                <TextInput
                  style={styles.inputbox}
                  placeholderTextColor="#878787"
                  underlineColorAndroid="rgba(0, 0, 0,0)"
                  value={this.state.last_name}
                  onChangeText={last_name => this.setState({last_name})}
                />
              </View>
              <View style={styles.fromgroup}>
                <View>
                  <Text style={styles.inputlabel}>Bio</Text>
                </View>
                <TextInput
                  style={styles.inputbox}
                  placeholderTextColor="#878787"
                  underlineColorAndroid="rgba(0, 0, 0,0)"
                  value={this.state.bio}
                  onChangeText={bio => this.setState({bio})}
                />
              </View>
              <View style={styles.fromgroup}>
                <TouchableOpacity onPress={() => this.updateProfile()}>
                  <Text style={styles.Searchbtn}>Save Changes</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </ScrollView>
      );
    }
  }
}

const mapDispatchToProps = dispatch => ({
  updateUserData: user => {
    dispatch({
      type: 'USER_SUCCESS',
      payload: user,
    });
  },
});

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(EditProfile);
