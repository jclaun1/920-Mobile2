import React from 'react';
import { Text, View, ScrollView, TouchableOpacity, Alert, Image } from 'react-native';
import OrderSubmitting from '../../Common/OrderSubmitting';
import GooglePlaces from '../../Common/GooglePlaces';
import ModalFilterPicker from 'react-native-modal-filter-picker';
import styles from '../../../../assets/css/style';
import OrderItem from '../../Order/OrderItem';
import TripItem from '../../Trip/TripItem';
import { connect } from 'react-redux';
import { DatePicker } from 'native-base';
import moment from 'moment';
import axios from 'axios';
import FlyButton from '../../Common/FlyButton';

class SearchDomestic extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      orders: [],
      trips: [],
      isLoading: true,
      visible: false,

      country_list: [],
      selectedCountry: { code: '', name: '' },
      searchText: '',
      address_from: '',
      lang_from: null,
      lat_from: null,
      lang_to: null,
      lat_to: null,
      address_to: '',
      travel_date: moment().format('DD/MM/YYYY'),
      toShow: false,
      fromShow: false,
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);

    this.recent_trips_orders();
    this._countryListCall();
  }

  async recent_trips_orders() {
    try {
      let response = await axios.get('orders/trips/2/recent');

      await this.setState({
        orders: response.data[0],
        trips: response.data[1],
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _handleSubmit(push) {
    if (!this.state.selectedCountry.code) {
      Alert.alert('Oops!', 'select country');
      return;
    }

    if (!this.state.address_from) {
      Alert.alert('Oops!', 'enter travel from address');
      return;
    }

    if (!this.state.address_to) {
      Alert.alert('Oops!', 'enter travel to address');
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      const data = {
        travel_from: this.state.address_from,
        travel_to: this.state.address_to,
        country: this.state.selectedCountry.name,
        country_code: this.state.selectedCountry.code,
        lang_from: this.state.lang_from,
        lang_to: this.state.lang_to,
        lat_from: this.state.lat_from,
        lat_to: this.state.lat_to,
        state_from: this.state.state_from,
        state_to: this.state.state_to,
        travel_date: moment(this.state.travel_date, 'DD/MM/YYYY').format(
          'YYYY-MM-DD H:mm:ss',
        ),
        isMobile: true,
      };

      let response = await axios.post('trip/search/domestic', data);

      await this.setState({
        isLoading: false,
      });

      push('FindOrderDomestically', { id: response.data[0].id });
    } catch (error) {
      // console.log(error)
      await this.setState({
        isLoading: false,
      });
      await Alert.alert('Oops!', 'somthing went wrong');
    }
  }

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  async _handleFrom(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_from: data.formatted_address,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        state_from: state,
        fromShow: false,
      });
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      let state = await this._findStates(data.address_components);
      await this.setState({
        address_to: data.formatted_address,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        state_to: state,
        toShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _handleDatePicked = async date => {
    await this.setState({
      travel_date: moment(date).format('DD/MM/YYYY'),
    });
  };

  async _countryListCall() {
    try {
      let response = await axios.get('country/list');
      let responses = response.data;

      var countryList = [];
      await responses.forEach(element => {
        countryList.push({ key: element.value, label: element.text });
      });

      await this.setState({
        country_list: countryList,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  _filterResult(indexkey) {
    const result = this.state.country_list.find(
      element => element.key === indexkey,
    );
    return result;
  }

  _onSelect = async picked => {
    try {
      let result = await this._filterResult(picked);
      this.setState({
        selectedCountry: { code: picked, name: result.label },
        visible: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        visible: false,
      });
    }
  };

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={[styles.containerbox, {}]}>
          <ScrollView>
            <View style={[styles.searchordercard,]}>
              {/* <Text style={styles.loginlogo}>Travelling Domestically </Text> */}
              <View style={[styles.fromgroup, {
                flexDirection: 'row', orderTopWidth: 0,
                borderBottomWidth: 1,
                borderLeftWidth: 0,
                borderColor: '#D8D8D8'
              }]}>
                <Image
                  source={require('../../../../assets/images/ic_pick_location.png')}
                  style={{
                    height: 20, width: 20, resizeMode: 'cover',
                    alignSelf: 'center'
                  }}
                />
                {/* <View>
                  
                  <Text style={styles.inputlabel}>select country</Text>
                </View> */}
                <TouchableOpacity
                  onPress={() => this.setState({ visible: true })}
                  style={[styles.gpcountery,{marginTop:5}]}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: '#D8D8D8',
                      textAlign: 'left',
                      width: '100%',
                      paddingLeft: 25,
                    }}>
                    {this.state.selectedCountry.name
                      ? this.state.selectedCountry.name
                      : 'Select Country'}
                  </Text>
                </TouchableOpacity>
              </View>

              <ModalFilterPicker
                visible={this.state.visible}
                onSelect={this._onSelect}
                onCancel={() => this.setState({ visible: false })}
                options={this.state.country_list}
              />

              <View style={styles.fromgroup}>
            
                <GooglePlaces
                  countryCode={this.state.selectedCountry.code}
                  listDisplayed={this.state.fromShow}
                  onSelectAddress={this._handleFrom}
                  placeHolder="From Domestic city"
                />
              </View>

              <View style={styles.fromgroup}>
              
                <GooglePlaces
                  countryCode={this.state.selectedCountry.code}
                  listDisplayed={this.state.toShow}
                  onSelectAddress={this._handleTo}
                  placeHolder="To Domestic city"
                />
              </View>



              <View style={styles.fromgroup}>
                <View>
                  <Text style={styles.inputlabel}>Date</Text>
                </View>

                <View style={[styles.datepiker, { height: 60 }]}>

                  <Image
                    source={require('../../../../assets/images/ic_calendar.png')}
                    style={{
                      height: 20, width: 20, resizeMode: 'cover',
                      alignSelf: 'center', marginRight: 25
                    }}
                  />
                  <View style={{ height: 25, marginTop: 10 }}>
                    <DatePicker
                      defaultDate={new Date()}
                      minimumDate={new Date()}
                      locale={'en'}
                      timeZoneOffsetInMinutes={undefined}
                      modalTransparent={false}
                      animationType={'fade'}
                      androidMode={'default'}
                      placeholder="DD/MM/YYY"
                      textStyle={{ color: '#878787' }}
                      placeHolderTextStyle={{ color: '#878787' }}
                      onDateChange={this._handleDatePicked}
                      style={{ borderWidth: 1, marginTop: 10, }}
                    />


                  </View>

                </View>
              </View>

              <View style={styles.fromgroup}>
              <View style={[{
                width: 200, height: '37%', alignSelf: 'center', justifyContent: 'flex-end',
              }]}>
                <FlyButton
                  onPress={() =>
                    this._handleSubmit(this.props.screenProps.push)
                  }
                  title="Search"
                  style={{ alignSelf: 'center', }}
                  color="#4A0B49"
                />
                </View>
                {/* <TouchableOpacity
                  onPress={() =>
                    this._handleSubmit(this.props.screenProps.push)
                  }>
                  <Text style={styles.Searchbtn}>Search</Text>
                </TouchableOpacity> */}
              </View>
            </View>

            <OrderItem
              currency={this.props.currency}
              orders={this.state.orders}
              push={this.props.screenProps.push}
            />
            <TripItem
              currency={this.props.currency}
              trips={this.state.trips}
              push={this.props.screenProps.push}
            />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
  };
};

export default connect(
  mapStateToProps,
  null,
)(SearchDomestic);
