import React, { Component } from 'react';
import { View, Dimensions, TouchableOpacity, Animated, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { ScrollableTabView } from '@valdio/react-native-scrollable-tabview'
import TabBar from "react-native-underline-tabbar";

import NewHeader from '../Menu/NewHeader';
import {
  createMaterialTopTabNavigator,
  createAppContainer,
} from 'react-navigation';
import SearchInternational from './Search/SearchInternational';
import SearchDomestic from './Search/SearchDomestic';
import SearchLocal from './Search/SearchLocal';
const fontsizerwidth = Dimensions.get('window').width;

const fontSizer = screenWidth => {
  if (screenWidth > 400) {
    return 11;
  } else if (screenWidth > 360) {
    return 10;
  } else if (screenWidth > 250) {
    return 9;
  } else {
    return 8;
  }
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
    fontSize: 28,
  },
});

const Page = ({ label, text = '' }) => (
  <View style={styles.container}>
    <Text style={styles.welcome}>
      {label}
    </Text>
    <Text style={styles.instructions}>
      {text}
    </Text>
  </View>
);


const Tab = ({ tab, page, isTabActive, onPressHandler, onTabLayout, styles }) => {
  const { label, icon } = tab;
  const style = {
    marginHorizontal: 20,
    paddingVertical: 10,
  };
  const containerStyle = {
    paddingVertical: 3,
    paddingHorizontal: 5,
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: styles.backgroundColor,
    borderWidth: 1,
    opacity: styles.opacity,
    transform: [{ scale: styles.opacity }],
  };
  // console.log('style background',styles.ba)
  const textStyle = {
    color: styles.textColor,
    fontWeight: '600',
  };
  const iconStyle = {
    tintColor: styles.textColor,
    resizeMode: 'contain',
    width: 22,
    height: 22,
    marginLeft: 10,
  };
  return (
    <TouchableOpacity style={style} onPress={onPressHandler} onLayout={onTabLayout} key={page}>
      <Animated.View style={containerStyle}>
        <Animated.Text style={textStyle}>{label}</Animated.Text>
      </Animated.View>
    </TouchableOpacity>
  );
};
class TravelOption extends Component {
  constructor(props) {
    super(props);
  }
  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Travel',
      header: <NewHeader type="2" title="Travel" navigate={navigation} />,
    };
  };

  async componentDidMount() {
    await AsyncStorage.removeItem('submitdata');
  }


  _scrollX = new Animated.Value(0);

  interpolators = Array.from({ length: 6 }, (_, i) => i).map(idx => ({
    scale: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: [1, 1.2, 1],
      extrapolate: 'clamp',
    }),
    opacity: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: [0.9, 1, 0.9],
      extrapolate: 'clamp',
    }),
    textColor: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: ['#000', '#650764', '#000'],
    }),
    backgroundColor: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: ['#fff', '#650764', '#fff'],
      extrapolate: 'clamp',
    }),
  }));
  render() {
   
    return (


      <ScrollableTabView
        underlineHeight={0}
        screenProps={this.props}
        onScroll={(x) => this._scrollX.setValue(x)} 
        style={{ width: Dimensions.get('window').width, height: Dimensions.get('window').height }}
        renderTabBar={() => <TabBar
          tabBarStyle={{ backgroundColor: "#fff", borderTopColor: '#d2d2d2', borderWidth: 0 }}
          underlineColor="#fff"
          renderTab={(tab, page, isTabActive, onPressHandler, onTabLayout) => (
            <Tab
              key={page}
              tab={tab}
              page={page}
              isTabActive={isTabActive}
              onPressHandler={onPressHandler}
              onTabLayout={onTabLayout}
              styles={this.interpolators[page]}
            
            />
            
          )}
          onScroll={(x) => this._scrollX.setValue(x)} />}
      >

        <SearchInternational screenProps={this.props}
          tabLabel={{ label: "International" }} />
        <SearchDomestic screenProps={this.props}
          tabLabel={{ label: "Domestic" }} />
        <SearchLocal screenProps={this.props}
          tabLabel={{ label: "Local" }} />
      </ScrollableTabView>
      // {/* <Tabs screenProps={{push: this.props.navigation.push}} /> */}

    );
  }
}

const Tabs = createAppContainer(
  createMaterialTopTabNavigator(
    {
      TravelInternational: {
        screen: SearchInternational,
        navigationOptions: {
          tabBarLabel: 'International',
        },
      },

      TravelDomestic: {
        screen: SearchDomestic,
        navigationOptions: {
          tabBarLabel: 'Domestic',
        },
      },

      TravelLocal: {
        screen: SearchLocal,
        navigationOptions: {
          tabBarLabel: 'Local',
        },
      },
    },
    {
      tabBarOptions: {
        style: {
          backgroundColor: '#ffffff',
          marginBottom: 30,
        },
        labelStyle: {
          fontSize: fontSizer(fontsizerwidth),
          fontFamily: 'OpenSans-Bold',
        },
        activeTintColor: '#610760',
        inactiveTintColor: '#ABB0B7',

        indicatorStyle: {
          borderBottomColor: '#ffffff',
          borderBottomWidth: 0,
          height: 0,
        },
      },
    },
  ),
);

export default TravelOption;
