import React, { Component } from 'react';
import NewHeader from '../Menu/NewHeader';
import { View, Dimensions,Animated, StyleSheet ,TouchableOpacity, } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { ScrollableTabView } from '@valdio/react-native-scrollable-tabview'
import TabBar from "react-native-underline-tabbar";

import ShopGlobally from './ShopGlobally';
// import ShopDomesticllyLocally from './ShopDomesticllyLocally'
import ShopDomesticlly from './ShopDomesticlly';
import ShopLocally from './ShopLocally';

// import BuyFoodDomesticllyLocally from './BuyFoodDomesticllyLocally'

import {
  createMaterialTopTabNavigator,
  createStackNavigator,
  createAppContainer,
} from 'react-navigation';
const fontsizerwidth = Dimensions.get('window').width;

const fontSizer = screenWidth => {
  if (screenWidth > 400) {
    return 11;
  } else if (screenWidth > 360) {
    return 10;
  } else if (screenWidth > 250) {
    return 9;
  } else {
    return 8;
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
    fontSize: 28,
  },
});

const Page = ({ label, text = '' }) => (
  <View style={styles.container}>
    <Text style={styles.welcome}>
      {label}
    </Text>
    <Text style={styles.instructions}>
      {text}
    </Text>
  </View>
);


const Tab = ({ tab, page, isTabActive, onPressHandler, onTabLayout, styles }) => {
  const { label, icon } = tab;
  const style = {
    marginHorizontal: 20,
    paddingVertical: 10,
  };
  const containerStyle = {
    paddingVertical: 3,
    paddingHorizontal: 5,
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: styles.backgroundColor,
    borderWidth: 1,
    opacity: styles.opacity,
    transform: [{ scale: styles.opacity }],
  };
  // console.log('style background',styles.ba)
  const textStyle = {
    color: styles.textColor,
    fontWeight: '600',
  };
  const iconStyle = {
    tintColor: styles.textColor,
    resizeMode: 'contain',
    width: 22,
    height: 22,
    marginLeft: 10,
  };
  return (
    <TouchableOpacity style={style} onPress={onPressHandler} onLayout={onTabLayout} key={page}>
      <Animated.View style={containerStyle}>
        <Animated.Text style={textStyle}>{label}</Animated.Text>
      </Animated.View>
    </TouchableOpacity>
  );
};
class ShopOption extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tripId: null,
      type: null,
    };

    this._componentWillLoad();
  }

  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Messages',
      header: <NewHeader type="2" title="Shop" navigate={navigation} />,
    };
  };

  async _componentWillLoad() {
    await AsyncStorage.removeItem('submitdata');
    this.setState({
      tripId: this.props.navigation.getParam('tripId'),
      type: this.props.navigation.getParam('type'),
    });
  }

  _scrollX = new Animated.Value(0);

  interpolators = Array.from({ length: 6 }, (_, i) => i).map(idx => ({
    scale: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: [1, 1.2, 1],
      extrapolate: 'clamp',
    }),
    opacity: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: [0.9, 1, 0.9],
      extrapolate: 'clamp',
    }),
    textColor: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: ['#000', '#650764', '#000'],
    }),
    backgroundColor: this._scrollX.interpolate({
      inputRange: [idx - 1, idx, idx + 1],
      outputRange: ['#fff', '#650764', '#fff'],
      extrapolate: 'clamp',
    }),
  }));
  render() {
    return (
      <View style={{ flex: 1,width: Dimensions.get('window').width }}>

        <ScrollableTabView
          underlineHeight={0}
          screenProps={this.props}
          onScroll={(x) => this._scrollX.setValue(x)}
          style={{ width: Dimensions.get('window').width, height: Dimensions.get('window').height }}
          renderTabBar={() => <TabBar
            tabBarStyle={{ backgroundColor: "#fff", borderTopColor: '#d2d2d2', borderWidth: 0 }}
            underlineColor="#fff"
            renderTab={(tab, page, isTabActive, onPressHandler, onTabLayout) => (
              <Tab
                key={page}
                tab={tab}
                page={page}
                isTabActive={isTabActive}
                onPressHandler={onPressHandler}
                onTabLayout={onTabLayout}
                styles={this.interpolators[page]}

              />

            )}
            onScroll={(x) => this._scrollX.setValue(x)} />}
        >

          <ShopGlobally screenProps={this.props}
            tabLabel={{ label: "Global" }} />
          <ShopDomesticlly screenProps={this.props}
            tabLabel={{ label: "Domestic" }} />
          <ShopLocally screenProps={this.props}
            tabLabel={{ label: "Local" }} />
        </ScrollableTabView>
        {/* <Tabs
          onChangeState={() => this.setState({tripId: null, type: null})}
          screenProps={{
            push: this.props.navigation.push,
            tripId: this.state.tripId,
            type: this.state.type,
          }}
        /> */}
      </View>
    );
  }
}

// ShopGlobally,
//             navigationOptions:{
//                 tabBarLabel:'Globally'
//             }
const Tabs = createAppContainer(
  createMaterialTopTabNavigator(
    {
      ShopGlobally: {
        screen: createStackNavigator({
          ShopGlobally: {
            screen: ShopGlobally,
            navigationOptions: {
              header: null,
            },
          },
        }),
        navigationOptions: {
          tabBarLabel: 'Globally',
        },
      },

      ShopDomesticlly: {
        screen: createStackNavigator({
          ShopDomesticlly: {
            screen: ShopDomesticlly,
            navigationOptions: {
              header: null,
            },
          },
        }),
        navigationOptions: {
          tabBarLabel: 'Domestically',
        },
      },

      ShopLocally: {
        screen: createStackNavigator({
          ShopLocally: {
            screen: ShopLocally,
            navigationOptions: {
              header: null,
            },
          },
        }),
        navigationOptions: {
          tabBarLabel: 'Locally',
        },
      },

      // BuyFoodDomesticllyLocally: {
      //     screen: BuyFoodDomesticllyLocally,
      //     navigationOptions:{
      //         tabBarLabel:'Food Domestically & Locally'
      //     }
      // }
    },
    {
      tabBarOptions: {
        style: {
          backgroundColor: '#660165',
          marginBottom: 30,
        },
        labelStyle: {
          fontSize: fontSizer(fontsizerwidth),
          fontFamily: 'Montserrat-Bold',
        },
        activeTintColor: '#ffff',
        inactiveTintColor: 'gray',
        indicatorStyle: {
          borderBottomColor: '#ffffff',
          borderBottomWidth: 4,
        },
      },
    },
  ),
);

export default ShopOption;
