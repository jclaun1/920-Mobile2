import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import styles from '../../../assets/css/style';
import OrderSubmitting from '../Common/OrderSubmitting';
import ImageViewer from '../Common/ImageViewer';
import ModalFilterPicker from 'react-native-modal-filter-picker';
import GooglePlaces from '../Common/GooglePlaces';
import TripItem from '../Trip/TripItem';
import { connect } from 'react-redux';
import { DatePicker, CheckBox, Picker, Icon } from 'native-base';
import ImagePicker from 'react-native-image-picker';
import moment from 'moment';
import axios from 'axios';
import isEmpty from 'lodash/isEmpty';
import Warning from './Warning';
import InputFields from '../Common/InputFields';

class ShopDomesticllyLocally extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      trips: [],
      isLoading: false,
      quantity: 1,
      step: 1,
      visible: false,
      isDomestic: false,
      fromShow: false,
      toShow: false,
      localCityShow: false,
      navigation: props.navigation,
      country_list: [],

      selectedCountry: { code: '', name: '' },
      citydetails: { lang: '', lat: '' },
      showTotal: '',
      showServiceFee: '',

      city: '',
      state_to: '',
      state_from: '',
      tripId: null,
      name_item: '',
      description: '',
      link_item: '',
      price_item: '',
      traveller_fee: '',
      delivery_from: '',
      delivery_to: '',
      delivery_domestic: '',
      delivery_date: '',
      additional_note: '',
      isAccepted: false,
      trvale_item_price: 0,
      service_fee: 0,
      total: 0,
      item_images: [],
      item_image_uris: [],
      orderlink: '',
      link: '',
      isByLink: false,

      hour: '03',
      minute: '15',
      convention: 'PM',

      imageViewUrl: null,
      isShowModal: false,

      isWarning: false,
      isPaylater: false,
    };

    this._handleLocalCity = this._handleLocalCity.bind(this);
    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);

    this._componentWillLoad();
  }

  _pickImage = () => {
    var options = {
      maxWidth: 1000,
      maxHeight: 1000,
      mediaType: 'photo',
    };

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else if (this.state.item_image_uris.length >= 3) {
        return;
      } else {
        var uris = this.state.item_image_uris;

        uris.unshift({ uri: response.uri, base64: response.data });
        this.setState({
          item_image_uris: uris,
        });
      }
    });
  };

  _removeImage = async index => {
    try {
      var urisD = this.state.item_image_uris;
      await urisD.splice(index, 1);
      this.setState({
        item_image_uris: urisD,
      });
    } catch (error) {
      // console.log(error)
    }
  };

  _findStates(places) {
    let lengthP = places.length;

    if (lengthP == 1) {
      return places[0].long_name;
    }

    if (lengthP == 2) {
      return places[1].long_name;
    }

    if (lengthP > 2) {
      return places[lengthP - 2].long_name;
    }
  }

  _increaseQuantity() {
    var qant = this.state.quantity + 1;
    if (qant < 11) {
      this.setState({
        quantity: qant,
      });
      this._servicefeeTotal();
    }
    return;
  }

  _decreaseQuantity() {
    var qantneg = this.state.quantity - 1;
    if (qantneg > 0) {
      this.setState({
        quantity: qantneg,
      });
      this._servicefeeTotal();
    }
    return;
  }

  _setState(type, value) {
    let isValid = Math.sign(value);

    if (isValid < 0 || isNaN(isValid)) {
      return;
    }
    if (type == 'price') {
      this.setState({
        price_item: value,
      });
    } else {
      this.setState({
        traveller_fee: value,
      });
    }
    this._servicefeeTotal();
  }

  async _servicefeeTotal() {
    var price_item = this.state.price_item;
    var traveller_fee = this.state.traveller_fee;
    var travele_item_price = 0;
    var servicefee = 0;

    travele_item_price =
      (await parseFloat(price_item)) * this.state.quantity +
      parseFloat(traveller_fee);

    var servicefee = (await travele_item_price) * 0.08;

    if (this.props.currency !== '₹') {
      servicefee = servicefee + 0.3;
    }
    var gst = (await servicefee) * 0.18 + parseFloat(traveller_fee) * 0.18;

    var serviceFeeState =
      (await parseFloat(Math.round(servicefee * 100) / 100)) +
      parseFloat(Math.round(gst * 100) / 100);

    var showServiceFee = (await Math.round(serviceFeeState * 100)) / 100;

    var totalState = (await travele_item_price) + serviceFeeState;
    var showTotal = (await Math.round(totalState * 100)) / 100;

    this.setState({
      service_fee: serviceFeeState,
      total: totalState,
      showTotal: showTotal,
      showServiceFee: showServiceFee,
    });
    return;
  }

  async _handleLocalCity(data) {
    try {
      await this.setState({
        citydetails: {
          lang: data.geometry.location.lng,
          lat: data.geometry.location.lat,
        },
        selectedCountry: {
          code:
            data.address_components[data.address_components.length - 1]
              .short_name,
          name:
            data.address_components[data.address_components.length - 1]
              .long_name,
        },
        city: data.formatted_address,
        localCityShow: false,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      if (this.state.isDomestic) {
        let state = await this._findStates(data.address_components);
        await this.setState({
          delivery_from: data.formatted_address,
          lang_from: data.geometry.location.lng,
          lat_from: data.geometry.location.lat,
          state_from: state,
          country_from:
            data.address_components[data.address_components.length - 1]
              .long_name,
          fromShow: false,
        });
      } else {
        await this.setState({
          delivery_from: data.formatted_address,
          lang_from: data.geometry.location.lng,
          lat_from: data.geometry.location.lat,
          fromShow: false,
        });
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      if (this.state.isDomestic) {
        let state = await this._findStates(data.address_components);
        await this.setState({
          delivery_to: data.formatted_address,
          lang_to: data.geometry.location.lng,
          lat_to: data.geometry.location.lat,
          state_to: state,
          country_to:
            data.address_components[data.address_components.length - 1]
              .long_name,
          toShow: false,
        });
      } else {
        await this.setState({
          delivery_to: data.formatted_address,
          lang_to: data.geometry.location.lng,
          lat_to: data.geometry.location.lat,
          toShow: false,
        });
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _extract() {
    if (!this.state.link) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      let response = await axios.post('get/link-page', { link: this.state.link });
      var data = response.data.data;

      var images = [];
      this.setState({
        item_images: [],
      });
      if (data.image) {
        images.unshift({ uri: data.image, base64: data.image });
      }

      this.setState({
        name_item: data.title,
        description: data.description,
        price_item: data.price,
        item_image_uris: images,
        link_item: this.state.link,
        isByLink: false,
        isLoading: false,
        link: '',
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  _handleDatePicked = async date => {
    await this.setState({
      delivery_date: moment(date).format('DD/MM/YYYY'),
      defaultDateData: new Date(
        moment(date).format('YYYY'),
        moment(date).format('MM'),
        moment(date).format('DD'),
      ),
    });
  };

  _hourManage(value) {
    this.setState({
      hour: value,
    });
  }

  _minuteManage(value) {
    this.setState({
      minute: value,
    });
  }

  _conventionManage(value) {
    this.setState({
      convention: value,
    });
  }

  _filterResult(indexkey) {
    const result = this.state.country_list.find(
      element => element.key === indexkey,
    );
    return result;
  }

  _changeDateFor(date) {
    return moment(date, 'DD/MM/YYYY').format('DD MMM, YYYY');
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _onSelect = async picked => {
    try {
      let result = await this._filterResult(picked);
      this.setState({
        selectedCountry: { code: picked, name: result.label },
        visible: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        visible: false,
      });
    }
  };

  async _tripCall(id) {
    try {
      let response = await axios.get('trip/' + id);

      var isDomestic;
      if (response.data.data.travel_type == 2) {
        isDomestic = true;
      } else {
        isDomestic = false;
      }
      var tripData = response.data.data;

      var dateData = moment(tripData.travel_date, 'DD/MM/YYYY').toDate();
      await this.setState({
        tripData,
        tripId: tripData.id,
        delivery_from: tripData.travel_from,
        delivery_to: tripData.travel_to,
        selectedCountry: {
          code: tripData.country_code,
          name: tripData.country,
        },
        defaultDateData: dateData,
        city: tripData.city_name,
        lang_from: tripData.lang_from,
        lang_to: tripData.lang_to,
        lat_from: tripData.lat_from,
        lat_to: tripData.lat_to,
        state_from: tripData.state_from,
        state_to: tripData.state_to,
        delivery_date: tripData.travel_date,

        citydetails: {
          lat: tripData.city_lat,
          lang: tripData.city_lang,
        },
        isDomestic,

        hour: tripData.hour,
        minute: tripData.minute,
        convention: tripData.convention,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  async recent_trips() {
    this.setState({
      isLoading: true,
    });
    try {
      let response = await axios.get('trips/2/recent/3');
      var tripId = await this.props.navigation.getParam('tripId');
      if (tripId) {
        await this._tripCall(tripId);
      } else {
        await this.setState({ defaultDateData: new Date() });
      }

      await this.setState({
        trips: response.data.data,
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _countryListCall() {
    this.setState({
      isLoading: true,
    });

    try {
      let response = await axios.get('country/list');
      let responses = response.data;

      var countryList = [];
      await responses.forEach(element => {
        countryList.push({ key: element.value, label: element.text });
      });

      await this.setState({
        country_list: countryList,
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  isValid(data) {
    var isValidData = true;
    for (let i = 0; i < Object.keys(data).length; i++) {
      if (!data[Object.keys(data)[i]]) {
        this[Object.keys(data)[i]].focus();
        isValidData = false;
        break;
      }
    }
    return isValidData;
  }

  isfirstStepcompleted() {
    let data = {
      name_item: this.state.name_item,
      description: this.state.description,
      price_item: this.state.price_item,
      traveller_fee: this.state.traveller_fee,
    };

    if (!this.isValid(data)) {
      return false;
    }

    return true;
  }

  _next = key => {
    if (key == 2) {
      if (this.state.item_image_uris.length == 0) {
        alert('select atleast one image');
        return;
      }

      if (!this.isfirstStepcompleted()) {
        return;
      }
    }

    if (key == 3) {
      if (!this.state.delivery_from) {
        Alert.alert('Oops!', 'enter delivery from address');
        return;
      }

      if (!this.state.delivery_to) {
        Alert.alert('Oops!', 'enter delivery to address');
        return;
      }

      if (!this.state.delivery_date) {
        Alert.alert('Oops!', 'enter delivery date');
        return;
      }
    }
    this.scroller.scrollTo({ x: 0, y: 0, animated: true });
    if (this.state.step) {
      this.setState({
        step: key,
      });
    }
  };

  async _data() {
    var imagesBase64 = [];

    await this.state.item_image_uris.forEach(element => {
      imagesBase64.push(element.base64);
    });

    const data = {
      delivery_from: this.state.delivery_from,
      delivery_to: this.state.delivery_to,
      country: this.state.selectedCountry.name,
      country_code: this.state.selectedCountry.code,
      city: this.state.city,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      state_from: this.state.state_from,
      state_to: this.state.state_to,
      delivery_date: moment(this.state.delivery_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),
      item_images: imagesBase64,
      price_item: this.state.price_item,
      traveller_fee: this.state.traveller_fee,
      service_fee: this.state.service_fee,
      name_item: this.state.name_item,
      link_item: this.state.link_item,
      description: this.state.description,
      additional_note: this.state.additional_note,
      quantity: this.state.quantity,
      tripId: this.state.tripId,

      city_lat: this.state.citydetails.lat,
      city_lang: this.state.citydetails.lang,
      hour: this.state.hour,
      minute: this.state.minute,
      convention: this.state.convention,
      isMobile: true,
      isPayLater: this.state.isPaylater,
    };

    var url = null;

    if (this.state.isDomestic) {
      url = 'shop/domestic';
    } else {
      url = 'shop/locally';
    }

    return [data, url];
  }

  _addTripCondition(push) {
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        { text: 'Okay', onPress: () => push('EmailPhone') },
        { text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel' },
      ],
      { cancelable: false },
    );
  }

  async _checkPhone(push) {
    var data = await this._data();

    var string = {
      items: data[0],
      isShop: 1,
      ShopType: this.state.isDomestic ? 2 : 3,
      url: data[1],
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));
    if (await isEmpty(this.props.user)) {
      push('Login');
      return false;
    }

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition(push);
        return false;
      }
    }

    return true;
  }

  _submitpost_paylater(isSubmit) {
    this.setState({
      isWarning: false,
    });

    if (isSubmit) {
      this._submitpost(this.props.screenProps.push);
    } else {
      return;
    }
  }

  async _submitpost_warning() {
    if (!this.state.isAccepted) {
      await Alert.alert('Oops!', 'First Accept Terms And Conditions.');
      return;
    } else {
      this.setState({
        isWarning: true,
      });
    }
  }

  async _submitpost(push) {
    var isAllow = await this._checkPhone(push);

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      if (!this.state.isAccepted) {
        await Alert.alert('First Accept Terms And Conditions.');
        this.setState({
          isLoading: false,
        });
        return;
      }

      var dataspost = await this._data();

      let response = await axios.post(dataspost[1], dataspost[0]);
      push('OrderPost', { slug: response.data.data.slug });
      this.setState({
        isLoading: false,
      });
    } catch (error) {
      // if (error.request) {
      //     console.log(error.request.response)
      // }else{
      //     console.log(error)
      // }
      await Alert.alert('Opps!', 'Somthing wrong!');
      this.setState({
        isLoading: false,
      });
    }
  }

  async _componentWillLoad() {
    await AsyncStorage.removeItem('submitdata');
    // const { status_roll } = await Permissions.askAsync(Permissions.CAMERA_ROLL)
    this.recent_trips();
    this._countryListCall();
  }

  handleClick = () => {
    Linking.canOpenURL('https://flypur.com/privacy').then(supported => {
      if (supported) {
        Linking.openURL('https://flypur.com/privacy');
      } else {
        console.log("Don't know how to open URI: ");
      }
    });
  };

  _domesticLocalElement() {
    if (this.state.isDomestic) {
      return (
        <View style={styles.fromgroup}>
          <TouchableOpacity
            onPress={() => this.setState({ visible: true })}
            style={styles.gpcountery}>
            <Text
              style={{
                fontSize: 16,
                color: '#5d5d5d',
                textAlign: 'left',
                width: '100%',
                paddingLeft: 25,
              }}>
              {this.state.selectedCountry.name
                ? this.state.selectedCountry.name
                : 'Country'}
            </Text>
          </TouchableOpacity>
          <ModalFilterPicker
            visible={this.state.visible}
            onSelect={this._onSelect}
            onCancel={() => this.setState({ visible: false })}
            options={this.state.country_list}
          />

          <View style={styles.googlefromGp}>
            <GooglePlaces
              defaultText={this.state.delivery_from}
              countryCode={this.state.selectedCountry.code}
              listDisplayed={this.state.fromShow}
              onSelectAddress={this._handleFrom}
              placeHolder="From city"
            />
          </View>

          <View style={styles.googlefromGp}>
            <GooglePlaces
              defaultText={this.state.delivery_to}
              countryCode={this.state.selectedCountry.code}
              listDisplayed={this.state.toShow}
              onSelectAddress={this._handleTo}
              placeHolder="To city"
            />
          </View>
        </View>
      );
    } else {
      return (
        <View style={styles.fromgroup}>
          <View style={styles.googlefromGp}>
            <GooglePlaces
              listDisplayed={this.state.localCityShow}
              defaultText={this.state.city}
              onSelectAddress={this._handleLocalCity}
              placeHolder="Choose Local City"
            />
          </View>
          <View style={styles.googlefromGp}>
            <GooglePlaces
              cityDetails={this.state.citydetails}
              defaultText={this.state.delivery_from}
              countryCode={this.state.selectedCountry.code}
              isLocal={true}
              listDisplayed={this.state.fromShow}
              onSelectAddress={this._handleFrom}
              placeHolder="From Locality"
            />
          </View>
          <View style={styles.googlefromGp}>
            <GooglePlaces
              cityDetails={this.state.citydetails}
              defaultText={this.state.delivery_to}
              countryCode={this.state.selectedCountry.code}
              isLocal={true}
              listDisplayed={this.state.toShow}
              onSelectAddress={this._handleTo}
              placeHolder="To Locality"
            />
          </View>
        </View>
      );
    }
  }

  _hourMinute() {
    if (!this.state.isDomestic) {
      var hours = [];
      var minutes = [];

      minutes.push(<Picker.Item key="00" label="00" value="00" />);

      for (let index = 1; index < 25; index++) {
        var hourel = index < 10 ? '0' + index : String(index);
        hours.push(<Picker.Item key={index} label={hourel} value={hourel} />);
      }

      for (let indexel = 1; indexel < 55; indexel++) {
        indexel = indexel + 4;
        var minuteel = indexel < 10 ? '0' + indexel : String(indexel);

        minutes.push(
          <Picker.Item key={indexel} label={minuteel} value={minuteel} />,
        );
      }

      return (
        <View style={{ width: '100%' }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#000' }}>
            By What Time You Will Reach There
          </Text>
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginVertical: 10,
            }}>
            <View style={styles.timepiker}>
              <Picker
                mode="dropdown"
                iosHeader="Select hour"
                iosIcon={<Icon name="md-arrow-down" />}
                style={{ width: undefined }}
                selectedValue={this.state.hour}
                onValueChange={this._hourManage.bind(this)}>
                {hours}
              </Picker>
            </View>

            <View style={styles.timepiker}>
              <Picker
                mode="dropdown"
                iosHeader="Select minute"
                iosIcon={<Icon name="md-arrow-down" />}
                style={{ width: undefined }}
                selectedValue={this.state.minute}
                onValueChange={this._minuteManage.bind(this)}>
                {minutes}
              </Picker>
            </View>

            <View style={styles.timepiker}>
              <Picker
                mode="dropdown"
                iosHeader="Select convention"
                iosIcon={<Icon name="md-arrow-down" />}
                style={{ width: undefined }}
                selectedValue={this.state.convention}
                onValueChange={this._conventionManage.bind(this)}>
                <Picker.Item label="AM" value="AM" />
                <Picker.Item label="PM" value="PM" />
              </Picker>
            </View>
          </View>
        </View>
      );
    } else {
      return null;
    }
  }

  _extractLinkElement() {
    return (
      <View style={[styles.searchordercard, styles.shadow]}>
        <View style={styles.fromgroup}>
          <Text style={styles.tell_us}>Tell us about your items.</Text>
          <View style={styles.fromgoup}>
            <TextInput
              style={styles.inputbox}
              placeholder="Past Your Link here"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              value={this.state.link.toString()}
              returnKeyType="done"
              onChangeText={link => this.setState({ link: link.toString() })}
            />
          </View>
          <View style={styles.fromgoup}>
            <TouchableOpacity onPress={() => this._extract()}>
              <Text style={styles.Searchbtn}>Submit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.fromgoup}>
            <TouchableOpacity onPress={() => this.setState({ isByLink: false })}>
              <Text style={styles.Searchbtn}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  _formElement(images) {
    return (
      <View style={[styles.searchordercard]}>
        <View style={styles.fromgroup}>
          <Text style={styles.tell_us}>Tell us about your items.</Text>
          <TouchableOpacity onPress={() => this.setState({ isByLink: true })}>
            <Text
              style={{
                fontSize: 18,
                color: '#660165',
                fontWeight: '600',
                marginVertical: 10,
                fontFamily: 'OpenSans-SemiBold',
              }}>
              Create your order from link.
            </Text>
          </TouchableOpacity>
          <Text
            style={{
              fontSize: 14,
              color: '#2d2d2d',
              fontFamily: 'OpenSans-Regular',
            }}>
            Images Of The Porduct (Atleast One Required)
          </Text>
        </View>

        <View style={styles.fromgroup}>
          <TouchableOpacity
            onPress={() => this._pickImage()}
            style={styles.cameraupload}>
            <FontAwesome name="camera" size={25} style={{ color: '#610760' }} />
            <Text
              style={{
                textAlign: 'center',
                fontSize: 18,
                color: '#610760',
                marginLeft: 10,
                fontFamily: 'OpenSans-Regular',
              }}>
              {this.state.item_image_uris.length > 0
                ? 'Upload More Item Images'
                : 'Upload Item Images'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.grideimageshop}>
          {images.length > 0 ? images : null}
        </View>

        <View style={styles.fromgroup}>

          <InputFields
            placeholder="Name of item"
            onChangeText={name_item => this.setState({ name_item })}
            value={this.state.name_item}
            ref={input => {
              this.name_item = input;
            }}
            returnKeyType="next"
            multiline={true}
          />
          {/* <View>
            <Text style={styles.inputlabel}>Name of item:</Text>
          </View>
          <TextInput
            style={styles.inputbox}
            placeholder=""
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={name_item => this.setState({ name_item })}
            value={this.state.name_item}
            ref={input => {
              this.name_item = input;
            }}
            returnKeyType="next"
            multiline={true}
          /> */}
        </View>
        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Description:</Text>
          </View>
          <TextInput
            style={styles.inputdescription}
            placeholder="Describe your item (e.g. color, size)"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={description => this.setState({ description })}
            value={this.state.description}
            ref={input => {
              this.description = input;
            }}
            returnKeyType="next"
            multiline={true}
          />
        </View>

        <View style={styles.fromgroup}>
        <InputFields
            placeholder="Link of product:"
            onChangeText={link_item => this.setState({ link_item })}
            value={this.state.link_item}
            multiline={true}
            returnKeyType="next"
          />
          {/* <View>
            <Text style={styles.inputlabel}>Link of product:</Text>
          </View>
          <TextInput
            style={styles.inputbox}
            placeholder="Web link to the item (optional)"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={link_item => this.setState({ link_item })}
            value={this.state.link_item}
            multiline={true}
            returnKeyType="next"
          /> */}
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>
              Price of the item({this.props.currency}):
            </Text>
          </View>
          <TextInput
            style={styles.inputbox}
            placeholder="Enter item price (inc. all Tax)"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            keyboardType="numeric"
            onChangeText={price_item => this._setState('price', price_item)}
            value={this.state.price_item.toString()}
            ref={input => {
              this.price_item = input;
            }}
            returnKeyType="next"
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>
              Traveller Fee({this.props.currency}):
            </Text>
          </View>
          <TextInput
            style={styles.inputbox}
            placeholder="Traveller Fee:"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            keyboardType="numeric"
            onChangeText={traveller_fee =>
              this._setState('traveller', traveller_fee)
            }
            value={this.state.traveller_fee.toString()}
            ref={input => {
              this.traveller_fee = input;
            }}
            returnKeyType="done"
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Quantity</Text>
          </View>
          <View style={styles.quantatybtn}>
            <Text
              style={styles.increment}
              onPress={() => this._decreaseQuantity()}>
              <FontAwesome name="minus" size={16} style={styles.colorwhite} />
            </Text>
            <Text style={[styles.increment, styles.incrementcount]}>
              {this.state.quantity}
            </Text>
            <Text
              style={styles.increment}
              onPress={() => this._increaseQuantity()}>
              <FontAwesome name="plus" size={16} style={styles.colorwhite} />
            </Text>
          </View>
        </View>

        <View style={styles.fromgroup}>
          <TouchableOpacity onPress={() => this._next(2)}>
            <Text style={styles.Searchbtn}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  elementOrder(push) {
    if (this.state.step == 1) {
      var images = [];
      var items = [1, 2, 3];
      if (this.state.item_image_uris.length > 0) {
        this.state.item_image_uris.forEach((image, index) => {
          var compo = (
            <View style={styles.gridimg} key={index}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({ imageViewUrl: image.uri, isShowModal: true })
                }>
                <Image
                  source={{
                    uri: image.uri,
                  }}
                  resizeMode="cover"
                  style={{ height: 105, width: 105 }}
                />
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.imggride_remove_btn}
                onPress={() => this._removeImage(index)}>
                <Entypo name="cross" size={30} style={{ color: '#660165' }} />
              </TouchableOpacity>
            </View>
          );
          images.push(compo);
        });
      }
      return !this.state.isByLink
        ? this._formElement(images)
        : this._extractLinkElement();
    } else if (this.state.step == 2) {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={{ width: '100%', marginVertical: 5 }}>
            <Text
              style={{
                fontSize: 16,
                color: '#660165',
                fontFamily: 'OpenSans-semiBold',
                marginBottom: 5,
              }}>
              Where you will take the delivery of your item?
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: '#2d2d2d',
                fontFamily: 'OpenSans-Regular',
                lineHeight: 22,
              }}>
              Provide Us The Detail And Name Of The City Where You Want Ot Take
              The Delivery Of Your Order. You And The Traveller Will Decide The
              Address Or Teh Meeting Point Mutually. So We Need To Know The
              Details Of The Delivery City Now Itself.
            </Text>
            {/* <Text style={{ fontSize: 17, color: '#660165',fontFamily:'OpenSans-Bold',  marginTop:5, }}>Make Your Choice</Text> */}
          </View>

          {/* <View style={styles.makeyourchoice}>
                    <Text style={[styles.makechoicebtn, this.state.isDomestic ? styles.makechoicebtnactive : null]}
                        onPress={() => this.state.tripId ? this.setState({ isDomestic: this.state.isDomestic }) :
                         this.setState({ isDomestic: true })}>Domestic
                    </Text>
                    <Text style={[styles.makechoicebtn, , !this.state.isDomestic ? styles.makechoicebtnactive : null]}
                     onPress={() => this.state.tripId ? this.setState({ isDomestic: this.state.isDomestic }) :
                     this.setState({ isDomestic: false })}>Local
                    </Text>
                </View> */}

          {this._domesticLocalElement()}

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                By What Date You Want The Delivery
              </Text>
            </View>
            <View style={styles.datepiker}>
              <DatePicker
                defaultDate={this.state.defaultDateData}
                minimumDate={new Date()}
                locale={'en'}
                timeZoneOffsetInMinutes={undefined}
                modalTransparent={false}
                animationType={'fade'}
                androidMode={'default'}
                placeholder="DD/MM/YYY"
                textStyle={{ color: '#878787' }}
                placeHolderTextStyle={{ color: '#878787' }}
                onDateChange={this._handleDatePicked}
                style={{ borderWidth: 1 }}
              />
            </View>
          </View>

          {this._hourMinute()}

          <View style={styles.fromgroup}>
          <InputFields
            placeholder="Additional Note To Traveller(Optional)"
            value={this.state.additional_note}
            onChangeText={additional_note => this.setState({ additional_note })}
            multiline={true}
            returnKeyType="next"
          />
            {/* <View>
              <Text style={styles.inputlabel}>
                Additional Note To Traveller(Optional)
              </Text>
            </View>
            <TextInput
              style={styles.inputdescription}
              placeholder="Type your message here...."
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              value={this.state.additional_note}
              onChangeText={additional_note => this.setState({ additional_note })}
              multiline={true}
            /> */}
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity onPress={() => this._next(3)}>
              <Text style={styles.Searchbtn}>Next</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(1)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={styles.fromgroup}>
            <Text style={styles.review_final}>
              Review before final submission.
            </Text>
          </View>
          <View
            style={{
              height: 300,
              width: '99%',
              alignItems: 'center',
              overflow: 'hidden',
              borderWidth: 2,
              borderColor: '#fff',
            }}>
            <Image
              style={styles.fitImage}
              source={{ uri: this.state.item_image_uris[0].uri }}
              style={{ width: 400, height: 300 }}
              resizeMode="contain"
            />
          </View>
          <View style={styles.fromgroup}>
            <Text style={styles.productname}>{this.state.name_item}</Text>
            <View style={styles.adressbox}>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling From : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_from}{' '}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling To : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_to}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Delivery Date: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this._changeDateFor(this.state.delivery_date)}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Quantity: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.quantity}
                </Text>
              </View>
            </View>
          </View>
          <View style={[styles.fromgroup, styles.borderBottom]}>
            <Text style={styles.below_approximate}>
              Below Is The Approximate Price Summary For Your Order Delivery.
            </Text>
          </View>

          <View style={[styles.fromgroup, styles.borderBottom]}>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Item Price</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.price_item}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Traveller Fee</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.traveller_fee}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Quantity</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.state.quantity}
              </Text>
            </View>
            {this.state.isPaylater ? null : (
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Service Fee</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {this.state.showServiceFee}
                </Text>
              </View>
            )}
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Total Amount</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency}{' '}
                {this.state.isPaylater
                  ? parseFloat(this.state.price_item) * this.state.quantity +
                  parseFloat(this.state.traveller_fee)
                  : this.state.showTotal}
              </Text>
            </View>
          </View>

          {/* pay later */}

          {/* <View style={styles.paylater}>
                    <CheckBox checked={this.state.isPaylater} onPress={() => this.setState({ isPaylater: !this.state.isPaylater})} />
                    <View style={{marginLeft:25,}}>
                        <Text style={{fontFamily:'OpenSans-Medium',fontSize:14 }}>Pay Later</Text>
                    </View>
                </View> */}
          {/* Terms Conditions */}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'flex-start',
              width: '100%',
            }}>
            <CheckBox
              checked={this.state.isAccepted}
              onPress={() =>
                this.setState({ isAccepted: !this.state.isAccepted })
              }
            />
            <View
              style={{
                marginLeft: 25,
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
              <Text style={{ fontFamily: 'OpenSans-Medium', fontSize: 14 }}>
                By Submitting The Order, I Agree To
              </Text>
              <TouchableOpacity onPress={() => this.handleClick()}>
                <Text
                  style={{
                    color: '#660165',
                    fontSize: 17,
                    fontFamily: 'OpenSans-Medium',
                  }}>
                  Terms And Conditions.
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity
              onPress={() =>
                this.state.isPaylater
                  ? this._submitpost_warning()
                  : this._submitpost(push)
              }>
              <Text style={styles.Searchbtn}>Submit My Order</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(2)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={styles.containerbox}>
          {this.state.isWarning ? (
            <Warning onCloseDes={data => this._submitpost_paylater(data)} />
          ) : null}
          <ImageViewer
            isShowModal={this.state.isShowModal}
            imageUrl={this.state.imageViewUrl}
            onClose={() =>
              this.setState({ isShowModal: false, imageViewUrl: null })
            }
          />
          <ScrollView
            ref={scroller => {
              this.scroller = scroller;
            }}>
            {this.elementOrder(this.props.screenProps.push)}
            <TripItem
              currency={this.props.currency}
              trips={this.state.trips}
              push={this.props.screenProps.push}
            />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(ShopDomesticllyLocally);
