import React from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
  BackHandler,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import OrderSubmitting from '../Common/OrderSubmitting';
import ImageViewer from '../Common/ImageViewer';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import ImagePicker from 'react-native-image-picker';
import styles from '../../../assets/css/style';
import {DatePicker, CheckBox} from 'native-base';
import GooglePlaces from '../Common/GooglePlaces';
import TripItem from '../Trip/TripItem';
import {connect} from 'react-redux';
import moment from 'moment';
import axios from 'axios';
import isEmpty from 'lodash/isEmpty';
import Warning from './Warning';

class ShopGlobaly extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      trips: [],
      isLoading: false,
      quantity: 1,
      step: 1,
      country_from: '',
      country_to: '',
      country_code: '',
      tripId: null,
      tripData: null,
      name_item: '',
      description: '',
      link_item: '',
      price_item: '',
      traveller_fee: '',
      delivery_from: '',
      delivery_to: '',
      delivery_date: '',
      additional_note: '',
      isAccepted: false,
      travele_item_price: 0,
      service_fee: 0,
      total: 0,
      item_images: [],
      item_image_uris: [],
      currency: '',
      isByLink: false,
      link: '',
      isLoaded: false,
      navigation: props.navigation,
      fromShow: false,
      toShow: false,
      showTotal: 0,
      showServiceFee: 0,

      lang_from: '',
      lat_from: '',
      lang_to: '',
      lat_to: '',

      isFromFocused: true,
      isToFocused: false,
      imageViewUrl: null,
      isShowModal: false,
      isSubmitting: false,

      isWarning: false,
      isPaylater: false,
    };

    this._handleFrom = this._handleFrom.bind(this);
    this._handleTo = this._handleTo.bind(this);
    this._issamecountry = this._issamecountry.bind(this);

    this._componentWillLoad();
  }

  _pickImage = () => {
    var options = {
      maxWidth: 1000,
      maxHeight: 1000,
      mediaType: 'photo',
    };

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else if (this.state.item_image_uris.length >= 3) {
        return;
      } else {
        var uris = this.state.item_image_uris;
        uris.unshift({uri: response.uri, base64: response.data});
        this.setState({
          item_image_uris: uris,
        });
      }
    });
  };

  _removeImage = async index => {
    try {
      var urisD = this.state.item_image_uris;
      await urisD.splice(index, 1);
      this.setState({
        item_image_uris: urisD,
      });
    } catch (error) {
      // console.log(error)
    }
  };

  _handleDatePicked = async date => {
    await this.setState({
      delivery_date: moment(date).format('DD/MM/YYYY'),
      defaultDateData: new Date(
        moment(date).format('YYYY'),
        moment(date).format('MM'),
        moment(date).format('DD'),
      ),
    });
  };

  async _recent_trips(tripId, type) {
    this.setState({
      isLoading: true,
    });
    try {
      let response = await axios.get('trips/1/recent');
      // var tripId = await this.props.navigation.getParam('tripId')

      if (tripId && type == 1) {
        await this._tripCall(tripId);
      } else {
        await this.setState({defaultDateData: new Date()});
      }

      this.setState({
        trips: response.data.data,
        tripId,
        isLoading: false,
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _tripCall(id) {
    try {
      let response = await axios.get('trip/' + id);
      var tripData = response.data.data;

      var dateData = moment(tripData.travel_date, 'DD/MM/YYYY').toDate();
      this.setState({
        tripData,
        delivery_from: tripData.travel_from,
        lang_from: tripData.lang_from,
        lat_from: tripData.lat_from,
        lang_to: tripData.lang_to,
        lat_to: tripData.lat_to,
        defaultDateData: dateData,
        country_from: tripData.country_from,
        delivery_to: tripData.travel_to,
        country_to: tripData.country_to,
        delivery_date: tripData.travel_date,
        country_code: tripData.country_code,
      });
    } catch (error) {
      // console.log(error)
    }
  }

  isValid(data) {
    var isValidData = true;
    for (let i = 0; i < Object.keys(data).length; i++) {
      if (!data[Object.keys(data)[i]]) {
        this[Object.keys(data)[i]].focus();
        isValidData = false;
        break;
      }
    }
    return isValidData;
  }

  isfirstStepcompleted() {
    let data = {
      name_item: this.state.name_item,
      description: this.state.description,
      price_item: this.state.price_item,
      traveller_fee: this.state.traveller_fee,
    };

    if (!this.isValid(data)) {
      return false;
    }

    return true;
  }

  _next = key => {
    if (key == 2) {
      if (this.state.item_image_uris.length == 0) {
        alert('select atleast one image');
        return;
      }

      if (!this.isfirstStepcompleted()) {
        return;
      }
    }

    if (key == 3) {
      if (!this.state.delivery_from) {
        Alert.alert('Oops!', 'enter delivery from address');
        return;
      }

      if (!this.state.delivery_to) {
        Alert.alert('Oops!', 'enter delivery to address');
        return;
      }

      if (this.state.country_from == this.state.country_to) {
        Alert.alert(
          'Oops!',
          'delivery from country and delivery to country can not be same',
        );
        return;
      }

      if (!this.state.delivery_date) {
        Alert.alert('Oops!', 'enter delivery date');
        return;
      }
    }

    this.scroller.scrollTo({x: 0, y: 0, animated: true});
    if (this.state.step) {
      this.setState({
        step: key,
      });
    }
  };

  _increaseQuantity() {
    var qant = this.state.quantity + 1;
    if (qant < 11) {
      this.setState({
        quantity: qant,
      });
      this._servicefeeTotal();
    }
    return;
  }

  _decreaseQuantity() {
    let qantneg = this.state.quantity - 1;
    if (qantneg > 0) {
      this.setState({
        quantity: qantneg,
      });
      this._servicefeeTotal();
    }
    return;
  }

  _changeDateFor(date) {
    return moment(date, 'DD/MM/YYYY').format('DD MMM, YYYY');
  }

  async _emtyStorage() {
    await AsyncStorage.removeItem('submitdata');
    return;
  }

  _addTripCondition() {
    this.setState({
      isSubmitting: false,
    });
    Alert.alert(
      'Verify your phone number!',
      'In order to access the full features of flypur, please verify your phone number.',
      [
        {
          text: 'Okay',
          onPress: () => this.props.screenProps.push('EmailPhone'),
        },
        {text: 'Cancel', onPress: () => this._emtyStorage(), style: 'cancel'},
      ],
      {cancelable: false},
    );
  }

  async _data() {
    let imagesBase64 = [];
    await this.state.item_image_uris.forEach(element => {
      imagesBase64.push(element.base64);
    });

    const data = {
      delivery_from: this.state.delivery_from,
      delivery_to: this.state.delivery_to,
      country_from: this.state.country_from,
      country_code: this.state.country_code,
      country: this.state.country_to,
      country_to: this.state.country_to,
      lang_from: this.state.lang_from,
      lang_to: this.state.lang_to,
      lat_from: this.state.lat_from,
      lat_to: this.state.lat_to,
      delivery_date: moment(this.state.delivery_date, 'DD/MM/YYYY').format(
        'YYYY-MM-DD H:mm:ss',
      ),

      item_images: imagesBase64,
      price_item: this.state.price_item,
      traveller_fee: this.state.traveller_fee,
      service_fee: this.state.service_fee,
      name_item: this.state.name_item,

      link_item: this.state.link_item,
      description: this.state.description,
      additional_note: this.state.additional_note,
      quantity: this.state.quantity,
      tripId: this.state.tripId,
      isMobile: true,
      isPayLater: this.state.isPaylater,
    };

    return data;
  }

  async _checkPhone() {
    var data = await this._data();

    var string = {
      items: data,
      isShop: 1,
      ShopType: 1,
      url: 'shop/globally',
    };

    await AsyncStorage.setItem('submitdata', JSON.stringify(string));

    if (await isEmpty(this.props.user)) {
      this.props.screenProps.push('Login');
      return false;
    }

    if (await !isEmpty(this.props.user)) {
      if (!this.props.user.isPhoneVerified) {
        this._addTripCondition();
        return false;
      }
    }

    return true;
  }

  _submitpost_paylater(isSubmit) {
    this.setState({
      isWarning: false,
    });

    if (isSubmit) {
      this._submitpost(this.props.screenProps.push);
    } else {
      return;
    }
  }

  async _submitpost_warning() {
    if (!this.state.isAccepted) {
      await Alert.alert('Oops!', 'First Accept Terms And Conditions.');
      return;
    } else {
      this.setState({
        isWarning: true,
      });
    }
  }

  async _submitpost(push) {
    if (!this.state.isAccepted) {
      await Alert.alert('Oops!', 'First Accept Terms And Conditions.');
      return;
    }

    this.setState({
      isSubmitting: true,
    });

    var isAllow = await this._checkPhone();

    if (!isAllow) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      let data = await this._data();
      let response = await axios.post('shop/globally', data);
      push('OrderPost', {slug: response.data.data.slug});
      this.setState({
        isLoading: false,
        isSubmitting: false,
      });
    } catch (error) {
      console.log(error);
      await Alert.alert('Opps!', 'Somthing went wrong!');
      this.setState({
        isLoading: false,
        isSubmitting: false,
      });
    }
  }

  _setState(type, value) {
    let isValid = Math.sign(value);

    if (isValid < 0 || isNaN(isValid)) {
      return;
    }
    if (type == 'price') {
      this.setState({
        price_item: value,
      });
    } else {
      this.setState({
        traveller_fee: value,
      });
    }
    this._servicefeeTotal();
  }

  async _servicefeeTotal() {
    var price_item = this.state.price_item;
    var traveller_fee = this.state.traveller_fee;
    var travele_item_price = 0;
    var servicefee = 0;

    travele_item_price =
      (await parseFloat(price_item)) * this.state.quantity +
      parseFloat(traveller_fee);
    var servicefee = (await travele_item_price) * 0.08;

    if (this.props.currency !== '₹') {
      servicefee = servicefee + 0.3;
    }
    var gst = (await servicefee) * 0.18 + parseFloat(traveller_fee) * 0.18;

    var serviceFeeState =
      (await parseFloat(Math.round(servicefee * 100) / 100)) +
      parseFloat(Math.round(gst * 100) / 100);

    var showServiceFee = (await Math.round(serviceFeeState * 100)) / 100;

    var totalState = (await travele_item_price) + serviceFeeState;
    var showTotal = (await Math.round(totalState * 100)) / 100;

    this.setState({
      service_fee: serviceFeeState,
      total: totalState,
      showTotal: showTotal,
      showServiceFee: showServiceFee,
    });
    return;
  }

  async _issamecountry(forplace) {
    try {
      if (forplace) {
        await this.setState({
          isFromFocused: true,
          isToFocused: false,
        });
      } else {
        await this.setState({
          isFromFocused: false,
          isToFocused: true,
        });
      }

      await Alert.alert(
        'Opps!',
        'Hey :) Please choose the two different countries',
      );
    } catch (error) {
      // console.log(error)
    }
  }

  async _handleFrom(data) {
    try {
      await this.setState({
        delivery_from: data.formatted_address,
        country_from:
          data.address_components[data.address_components.length - 1].long_name,
        country_code:
          data.address_components[data.address_components.length - 1]
            .short_name,
        lang_from: data.geometry.location.lng,
        lat_from: data.geometry.location.lat,
        fromShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(1);
      }
    } catch (error) {
      //    console.log(error)
    }
  }

  async _handleTo(data) {
    try {
      await this.setState({
        delivery_to: data.formatted_address,
        country_to:
          data.address_components[data.address_components.length - 1].long_name,
        lang_to: data.geometry.location.lng,
        lat_to: data.geometry.location.lat,
        toShow: false,
      });

      if (this.state.country_from === this.state.country_to) {
        await this._issamecountry(0);
      }
    } catch (error) {
      // console.log(error)
    }
  }

  async _extract() {
    if (!this.state.link) {
      return;
    }

    this.setState({
      isLoading: true,
    });

    try {
      let response = await axios.post('get/link-page', {link: this.state.link});
      var data = response.data.data;

      var images = [];
      this.setState({
        item_images: [],
      });
      if (data.image) {
        images.unshift({uri: data.image, base64: data.image});
      }

      this.setState({
        name_item: data.title,
        description: data.description,
        price_item: data.price,
        item_image_uris: images,
        link_item: this.state.link,
        isByLink: false,
        isLoading: false,
        link: '',
      });
    } catch (error) {
      // console.log(error)
      this.setState({
        isLoading: false,
      });
    }
  }

  async _componentWillLoad() {
    await AsyncStorage.removeItem('submitdata');
    var tripId = this.props.screenProps.tripId;
    var type = this.props.screenProps.type;

    if (tripId && type == 2) {
      this.props.navigation.push('ShopDomesticllyLocally', {tripId});
    } else {
      this._recent_trips(tripId, type);
    }
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
      isSubmitting: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  handleClick = () => {
    Linking.canOpenURL('https://flypur.com/privacy').then(supported => {
      if (supported) {
        Linking.openURL('https://flypur.com/privacy');
      } else {
        console.log("Don't know how to open URI: ");
      }
    });
  };

  _extractLinkElement() {
    return (
      <View style={[styles.searchordercard, styles.shadow]}>
        <View style={styles.fromgroup}>
          <Text style={styles.tell_us}>Tell us about your items.</Text>

          <View style={styles.fromgoup}>
            <TextInput
              style={styles.inputbox}
              placeholder="Past Your Link here"
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              value={this.state.link}
              onChangeText={link => this.setState({link: link.toString()})}
              returnKeyType="done"
            />
          </View>
          <View style={styles.fromgoup}>
            <TouchableOpacity onPress={() => this._extract()}>
              <Text style={styles.Searchbtn}>Submit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.fromgoup}>
            <TouchableOpacity onPress={() => this.setState({isByLink: false})}>
              <Text style={styles.Searchbtn}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  _formElement(images) {
    return (
      <View style={[styles.searchordercard, ]}>
        <View style={styles.fromgroup}>
          <Text style={styles.tell_us}>Tell us about your items.</Text>

          <TouchableOpacity onPress={() => this.setState({isByLink: true})}>
            <Text
              style={{
                fontSize: 18,
                color: '#660165',
                fontWeight: '600',
                marginVertical: 10,
                fontFamily: 'OpenSans-SemiBold',
              }}>
              Create your order from link.
            </Text>
          </TouchableOpacity>

          <Text
            style={{
              fontSize: 14,
              color: '#2d2d2d',
              fontFamily: 'OpenSans-Regular',
            }}>
            Images Of The Porduct (Atleast One Required)
          </Text>
        </View>

        <View style={styles.fromgroup}>
          <TouchableOpacity
            onPress={() => this._pickImage()}
            style={styles.cameraupload}>
            <FontAwesome name="camera" size={25} style={{color: '#610760'}} />
            <Text
              style={{
                textAlign: 'center',
                fontSize: 18,
                color: '#610760',
                marginLeft: 10,
                fontFamily: 'OpenSans-Regular',
              }}>
              {this.state.item_image_uris.length > 0
                ? 'Upload More Item Images'
                : 'Upload Item Images'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.grideimageshop}>
          {images.length > 0 ? images : null}
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Name of item:</Text>
          </View>
          <TextInput
            style={styles.inputbox}
            ref="nameItem"
            placeholder=""
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={name_item => this.setState({name_item})}
            value={this.state.name_item}
            ref={input => {
              this.name_item = input;
            }}
            returnKeyType="next"
            multiline={true}
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Description:</Text>
          </View>
          <TextInput
            style={styles.inputdescription}
            ref="Description"
            placeholder="Describe your item (e.g. color, size)"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={description => this.setState({description})}
            value={this.state.description}
            ref={input => {
              this.description = input;
            }}
            returnKeyType="next"
            multiline={true}
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Link of product:</Text>
          </View>
          <TextInput
            style={styles.inputbox}
            ref="linkItem"
            placeholder="Web link to the item (optional)"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            onChangeText={link_item => this.setState({link_item})}
            returnKeyType="next"
            value={this.state.link_item}
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>
              Price of the item({this.props.currency}):
            </Text>
          </View>
          <TextInput
            style={styles.inputbox}
            placeholder="Enter item price (inc. all Tax)"
            ref="priceItem"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            keyboardType="numeric"
            onChangeText={price_item => {
              this._setState('price', price_item);
            }}
            value={this.state.price_item.toString()}
            returnKeyType="next"
            ref={input => {
              this.price_item = input;
            }}
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>
              Traveller Fee({this.props.currency}):
            </Text>
          </View>
          <TextInput
            style={styles.inputbox}
            ref="travellerFee"
            placeholder="Traveller Fee:"
            placeholderTextColor="#878787"
            underlineColorAndroid="rgba(0, 0, 0,0)"
            keyboardType="numeric"
            onChangeText={traveller_fee => {
              this._setState('traveller', traveller_fee);
            }}
            value={this.state.traveller_fee}
            returnKeyType="done"
            ref={input => {
              this.traveller_fee = input;
            }}
          />
        </View>

        <View style={styles.fromgroup}>
          <View>
            <Text style={styles.inputlabel}>Quantity</Text>
          </View>
          <View style={styles.quantatybtn}>
            <Text
              style={styles.increment}
              onPress={() => this._decreaseQuantity()}>
              <FontAwesome name="minus" size={16} style={styles.colorwhite} />
            </Text>
            <Text style={[styles.increment, styles.incrementcount]}>
              {this.state.quantity}
            </Text>
            <Text
              style={styles.increment}
              onPress={() => this._increaseQuantity()}>
              <FontAwesome name="plus" size={16} style={styles.colorwhite} />
            </Text>
          </View>
        </View>

        <View style={styles.fromgroup}>
          <TouchableOpacity onPress={() => this._next(2)}>
            <Text style={styles.Searchbtn}>Next</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  elementOrder(push) {
    if (this.state.step == 1) {
      var images = [];
      if (this.state.item_image_uris.length > 0) {
        this.state.item_image_uris.forEach((image, index) => {
          var compo = (
            <View style={styles.gridimg} key={index}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({imageViewUrl: image.uri, isShowModal: true})
                }>
                <Image
                  source={{uri: image.uri}}
                  resizeMode="cover"
                  style={{height: 105, width: 105}}
                />
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.imggride_remove_btn}
                onPress={() => this._removeImage(index)}>
                <Entypo name="cross" size={30} style={{color: '#660165'}} />
              </TouchableOpacity>
            </View>
          );

          images.push(compo);
        });
      }

      return !this.state.isByLink
        ? this._formElement(images)
        : this._extractLinkElement();
    } else if (this.state.step == 2) {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={styles.fromgroup}>
            <Text
              style={{
                fontSize: 16,
                color: '#660165',
                fontFamily: 'OpenSans-semiBold',
                marginBottom: 5,
              }}>
              Where you will take the delivery of your item?
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: '#2d2d2d',
                fontFamily: 'OpenSans-Regular',
                lineHeight: 23,
              }}>
              Provide Us The Detail And Name Of The City Where You Want Ot Take
              The Delivery Of Your Order. You And The Traveller Will Decide The
              Address Or Teh Meeting Point Mutually. So We Need To Know The
              Details Of The Delivery City Now Itself.
            </Text>
          </View>

          <View style={styles.fromgroup}>
            <View style={styles.googlefromGp}>
              <GooglePlaces
                defaultText={this.state.delivery_from}
                listDisplayed={this.state.fromShow}
                onSelectAddress={this._handleFrom}
                placeHolder="Delivery From"
              />
            </View>

            <View style={styles.googlefromGp}>
              <GooglePlaces
                defaultText={this.state.delivery_to}
                listDisplayed={this.state.toShow}
                onSelectAddress={this._handleTo}
                placeHolder="Delivery To"
              />
            </View>
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                By What Date You Want The Delivery
              </Text>
            </View>
            <View style={styles.datepiker}>
              <DatePicker
                defaultDate={this.state.defaultDateData}
                minimumDate={new Date()}
                locale={'en'}
                timeZoneOffsetInMinutes={undefined}
                modalTransparent={false}
                animationType={'fade'}
                androidMode={'default'}
                placeholder="DD/MM/YYY"
                textStyle={{color: '#878787'}}
                placeHolderTextStyle={{color: '#878787'}}
                onDateChange={this._handleDatePicked}
                style={{borderWidth: 1}}
              />
            </View>
          </View>

          <View style={styles.fromgroup}>
            <View>
              <Text style={styles.inputlabel}>
                Additional Note To Traveller(Optional)
              </Text>
            </View>
            <TextInput
              style={styles.inputdescription}
              placeholder="Type your message here...."
              placeholderTextColor="#878787"
              underlineColorAndroid="rgba(0, 0, 0,0)"
              value={this.state.additional_note}
              returnKeyType="done"
              onChangeText={additional_note => this.setState({additional_note})}
              multiline={true}
            />
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity onPress={() => this._next(3)}>
              <Text style={styles.Searchbtn}>Next</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this._next(1)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return (
        <View style={[styles.searchordercard, styles.shadow]}>
          <View style={styles.fromgroup}>
            <Text style={styles.review_final}>
              Review before final submission.
            </Text>
          </View>

          <View
            style={{
              height: 300,
              width: '99%',
              alignItems: 'center',
              overflow: 'hidden',
              borderWidth: 2,
              borderColor: '#fff',
            }}>
            <Image
              source={{uri: this.state.item_image_uris[0].uri}}
              style={{width: 400, height: 300}}
              resizeMode="contain"
            />
          </View>

          <View style={styles.fromgroup}>
            <Text style={styles.productname}>{this.state.name_item}</Text>
            <View style={styles.adressbox}>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling From : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_from}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Travelling To : </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.delivery_to}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Delivery Date: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this._changeDateFor(this.state.delivery_date)}
                </Text>
              </View>
              <View style={styles.addresslistbox}>
                <Text style={styles.addresstitel}>Quantity: </Text>
                <Text style={[styles.addresstitel, styles.colorpurple]}>
                  {this.state.quantity}
                </Text>
              </View>
            </View>
          </View>

          <View style={[styles.fromgroup, styles.borderBottom]}>
            <Text style={styles.below_approximate}>
              Below Is The Approximate Price Summary For Your Order Delivery.
            </Text>
          </View>

          <View style={[styles.fromgroup, styles.borderBottom]}>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Item Price</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.price_item}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Traveller Fee</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency} {this.state.traveller_fee}
              </Text>
            </View>
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Quantity</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.state.quantity}
              </Text>
            </View>
            {this.state.isPaylater ? null : (
              <View style={styles.pricefinal}>
                <Text style={styles.priceall}>Service Fee</Text>
                <Text style={[styles.priceall, styles.colorpurple]}>
                  {this.props.currency} {this.state.showServiceFee}
                </Text>
              </View>
            )}
            <View style={styles.pricefinal}>
              <Text style={styles.priceall}>Total Amount</Text>
              <Text style={[styles.priceall, styles.colorpurple]}>
                {this.props.currency}{' '}
                {this.state.isPaylater
                  ? parseFloat(this.state.price_item) * this.state.quantity +
                    parseFloat(this.state.traveller_fee)
                  : this.state.showTotal}
              </Text>
            </View>
          </View>
          {/* pay later */}

          {/* <View style={styles.paylater}>
                    <CheckBox checked={this.state.isPaylater} onPress={() => this.setState({ isPaylater: !this.state.isPaylater })} />
                    <View style={{marginLeft:25,}}>
                        <Text style={{fontFamily:'OpenSans-Medium',fontSize:14 }}>Pay Later</Text>
                    </View>
               </View> */}
          {/* Terms Conditions */}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'flex-start',
              width: '100%',
            }}>
            <CheckBox
              checked={this.state.isAccepted}
              onPress={() =>
                this.setState({isAccepted: !this.state.isAccepted})
              }
            />
            <View
              style={{
                marginLeft: 25,
                flexDirection: 'column',
                justifyContent: 'center',
              }}>
              <Text style={{fontFamily: 'OpenSans-Medium', fontSize: 14}}>
                By Submitting The Order, I Agree To
              </Text>
              <TouchableOpacity onPress={() => this.handleClick()}>
                <Text
                  style={{
                    color: '#660165',
                    fontSize: 17,
                    fontFamily: 'OpenSans-Medium',
                  }}>
                  Terms And Conditions.
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.fromgroup}>
            <TouchableOpacity
              onPress={() =>
                this.state.isPaylater
                  ? this._submitpost_warning()
                  : this._submitpost(push)
              }>
              <Text style={styles.Searchbtn}>Submit My Order</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => this._next(2)}>
              <Text style={styles.Searchbtn}>Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      return (
        <View style={styles.containerbox}>
          {this.state.isWarning ? (
            <Warning onCloseDes={data => this._submitpost_paylater(data)} />
          ) : null}
          <ImageViewer
            isShowModal={this.state.isShowModal}
            imageUrl={this.state.imageViewUrl}
            onClose={() =>
              this.setState({isShowModal: false, imageViewUrl: null})
            }
          />
          <ScrollView
            ref={scroller => {
              this.scroller = scroller;
            }}>
            {this.elementOrder(this.props.screenProps.push)}

            <TripItem
              currency={this.props.currency}
              trips={this.state.trips}
              push={this.props.screenProps.push}
            />
          </ScrollView>
        </View>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(ShopGlobaly);
