import React from 'react'
import {Text, View, TouchableOpacity, ScrollView, Modal} from 'react-native'
import styles from '../../../assets/css/style'

export default class Warning extends React.Component {

    render() {

        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={true}
                onRequestClose={() => {
                    alert('Modal has been closed.')
                }}>
                <ScrollView contentContainerStyle={{flexGrow: 1}}>
                <View style={[styles.container,styles.invoicemodel]}>
                    <View style={{marginVertical:15}}>
                        <Text style={{fontSize:25,color:"#660165",  fontFamily:'Montserrat-bold',}}>Terms and conditions</Text>
                    </View>
                    <View style={styles.termstext}>
                        <View style={styles.borderpx}></View>
                        <Text>Enter details manually of the Item or Paste a link from the web of the item you want from any international website like Amazon, Apple, Walmart or any other online store. </Text>
                    </View>
                    <View style={styles.termstext}>
                        <View style={styles.borderpx}></View>
                        <Text>Enter details manually of the Item or Paste a link from the web of the item you want from any international website like Amazon, Apple, Walmart or any other online store. </Text>
                    </View>
                    <View style={styles.termstext}>
                        <View style={styles.borderpx}></View>
                        <Text>Enter details manually of the Item or Paste a link from the web of the item you want from any international website like Amazon, Apple, Walmart or any other online store. </Text>
                    </View>
                    <View style={styles.termstext}>
                        <View style={styles.borderpx}></View>
                        <Text>Enter details manually of the Item or Paste a link from the web of the item you want from any international website like Amazon, Apple, Walmart or any other online store. </Text>
                    </View>
                    <View style={styles.termstext}>
                        <View style={styles.borderpx}></View>
                        <Text>Enter details manually of the Item or Paste a link from the web of the item you want from any international website like Amazon, Apple, Walmart or any other online store. </Text>
                    </View>

                    <View style={{flexDirection:'row',justifyContent:'space-between',marginTop:20,width:'100%'}}>
                        <TouchableOpacity onPress={() => this.props.onCloseDes(true)} style={{backgroundColor:"#660165",width:150,paddingVertical:10,borderRadius:6,overflow:'hidden',marginBottom:10}}>
                            <Text style={{fontSize:14,color:'#fff',fontFamily:'Montserrat-semiBold',textAlign:'center'}}> Accept</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => this.props.onCloseDes(false)} style={{backgroundColor:"#660165",width:150,paddingVertical:10,borderRadius:6,overflow:'hidden',marginBottom:10}}>
                            <Text style={{fontSize:14,color:'#fff',fontFamily:'Montserrat-semiBold',textAlign:'center'}}>Cancel</Text>
                        </TouchableOpacity>
                    </View>

                    </View>

                </ScrollView>
            </Modal>
        )

    }
}
