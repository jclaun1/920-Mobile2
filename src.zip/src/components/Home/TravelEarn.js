import React from 'react'
import { Text, View, Dimensions } from 'react-native'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import styles from '../../../assets/css/style'
import Carousel, { Pagination } from 'react-native-snap-carousel'
let sliderData = [
    {
        icon: <FontAwesome name='shopping-cart' size={150} style={{ color: '#660165' }} />,
        text1: 'Travelling Internationally?',
        text2: 'Are you travelling internationally ? Wanna make some extra cash while you travel? Bring cultural or general items from your travel destination for the buyers globally.',

    },
    {
        icon: <MaterialCommunityIcons name='food-fork-drink' size={150} style={{ color: '#660165' }} />,
        text1: 'Travelling Domestically?',
        text2: 'Are you travelling domestically? Make some cash on the trip by buying and delivering items and food ( Domestic Only ) to the buyers from your origin city to your destination city.',

    },
    {
        icon: <FontAwesome name='train' size={150} style={{ color: '#660165' }} />,
        text1: 'Travelling Locally?',
        text2: 'Travelling locally from one point another within your city? Buy or transport items for senders and reciever and earn some cash!',

    }
];

export default class TravelEarn extends React.Component {

    constructor(props) {

        super(props)

        this.state = {

            datas: sliderData,
            activeSlide: 0,
            viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height
            }

        }

    }

    _renderItem({ item, index }) {
        return (

            // <View key={index} style ={styles.whyshopcard}>
            //     <View style={[styles.whymain, styles.shadow] }>
            //         <Text style={styles.mainshopingintro}>
            //         { item.icon }
            //         </Text>
            //         <Text style={styles.smheading}>
            //             { item.text1 }
            //         </Text>
            //         <Text style={styles.introtext}>
            //             { item.text2 }
            //         </Text>
            //     </View>
            // </View>
            <View style={[styles.whyshopcard, { flexDirection: 'row', alignItems: 'center' }]}>
                <Text style={[styles.mainshopingintro, { flex: .75, textAlign: 'center' }]}>
                    {item.icon}
                </Text>
                <View style={[{ flex: 1.25 }]}>

                    <Text style={styles.smheading}>
                        {item.text1}
                    </Text>
                    <Text numberOfLines={6} ellipsizeMode='tail' style={styles.introtext}>
                        {item.text2}
                    </Text>
                </View>

            </View>
        );
    }
    get pagination() {
        const { datas, activeSlide } = this.state;
        return (
            <Pagination
                dotsLength={datas.length}
                activeDotIndex={activeSlide}
                containerStyle={{ backgroundColor: '#f1f3f6' }}
                dotStyle={{
                    width: 10,
                    height: 10,
                    borderRadius: 5,
                    marginHorizontal: 0,
                    backgroundColor: '#660165'
                }}
                inactiveDotStyle={{
                    backgroundColor: '#000'
                }}
                inactiveDotOpacity={0.4}
                inactiveDotScale={0.6}
            />
        )
    }

    render() {
        return (
            <View style={styles.container}
                onLayout={() => {
                    this.setState({
                        viewport: {
                            width: Dimensions.get('window').width,
                            height: Dimensions.get('window').height
                        }
                    });
                }}>
                <Text style={styles.allheading}>Travel To Earn</Text>
                <View style={styles.slidercontainer}>
                    <Carousel
                        ref={(c) => { this._carousel = c; }}
                        data={this.state.datas}
                        renderItem={this._renderItem}
                        sliderWidth={this.state.viewport.width}
                        itemWidth={this.state.viewport.width}
                        onSnapToItem={(index) => this.setState({ activeSlide: index })}
                    />
                    {/* { this.pagination } */}
                </View>
            </View>
        )
    }
}
