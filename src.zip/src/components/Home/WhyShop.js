import React from 'react'
import { Text, View, Dimensions } from 'react-native'
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import styles from '../../../assets/css/style'
import Carousel, { Pagination } from 'react-native-snap-carousel'

// const sliderWidth = Dimensions.get('window').width;
// const itemWidth = sliderWidth ;
let sliderData = [
    {
        icon: <FontAwesome name='shopping-cart' size={150} style={{ color: '#660165' }} />,
        text1: 'Go on shopping spree',
        text2: 'Shop Anything From Anywhere: - Living in India is great but as it’s a developing economy not everything is available here, Do you fancy chocolates from uk or Belgium? Or electronics from Singapore? Or custom traditional items from different cities across the globe? We are here to fulfill your every dream.',

    },
    {
        icon: <MaterialCommunityIcons name='food-fork-drink' size={150} style={{ color: '#660165' }} />,
        text1: 'Order Food Which you cant reach',
        text2: 'Buy food from famous cities across India. For example, if you live in Delhi and fancy Hyderabadi biryani our platform will enable you to accomplish your wish. Famous foods: - Hyderabadi Biryani , Mumbai Vada pav , Agra Petha Etc Intercity Specialties too: Order from Any corner of the city to your location',

    },
    {
        icon: <FontAwesome name='train' size={150} style={{ color: '#660165' }} />,
        text1: 'Peer To Peer Transportation System',
        text2: 'Transport anything intercity from a corner to another or inter state or globally. Flypur got it all.',

    }
];

export default class WhyShop extends React.Component {
    constructor(props) {

        super(props)

        this.state = {

            datas: sliderData,
            activeSlide: 0,
            viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height
            }

        }

    }

    _renderItem({ item, index }) {
        return (
            <View style={[styles.whyshopcard,{flexDirection:'row',alignItems:'center'}]}>
                
                <View style={[{flex:1.25}]}>

                    <Text style={styles.smheading}>
                        {item.text1}
                    </Text>
                    <Text numberOfLines={6} ellipsizeMode='tail' style={styles.introtext}>
                        {item.text2}
                    </Text>
                </View>
                <Text  style={[styles.mainshopingintro,{flex:.75,textAlign:'center'}]}>
                    {item.icon}
                </Text>
            </View>
        );
    }
    get pagination() {
        const { datas, activeSlide } = this.state;
        return (
            <Pagination
                dotsLength={datas.length}
                activeDotIndex={activeSlide}
                containerStyle={{ backgroundColor: '#f1f3f6' }}
                dotStyle={{
                    width: 10,
                    height: 10,
                    borderRadius: 5,
                    marginHorizontal: 0,
                    backgroundColor: '#660165'
                }}
                inactiveDotStyle={{
                    backgroundColor: '#000'
                }}
                inactiveDotOpacity={0.4}
                inactiveDotScale={0.6}
            />
        )
    }

    render() {
        return (
            <View style={styles.container}
                onLayout={() => {
                    this.setState({
                        viewport: {
                            width: Dimensions.get('window').width,
                            height: Dimensions.get('window').height
                        }
                    });
                }}>
                <Text style={styles.allheading}>Why To Shop With Flypur</Text>

                <Carousel
                    ref={(c) => { this._carousel = c; }}
                    data={this.state.datas}
                    renderItem={this._renderItem}
                    sliderWidth={this.state.viewport.width}
                    itemWidth={this.state.viewport.width}
                    onSnapToItem={(index) => this.setState({ activeSlide: index })}
                />
                {/* { this.Pagination } */}

            </View>
        );
    }
}
