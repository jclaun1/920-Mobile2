import React from 'react';
import {View, ScrollView, RefreshControl, BackHandler} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../../../assets/css/style';
import WhyShop from './WhyShop';
import TravelEarn from './TravelEarn';
import OrderItem from '../Order/OrderItem';
import TripItem from '../Trip/TripItem';
import {connect} from 'react-redux';
import {
  onHomeRequest,
  homeSuccess,
  onHomeRequestFaild,
} from '../../redux/actions/authAction';
import NewHeader from '../Menu/NewHeader';
import axios from 'axios';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      refreshing: false,
      isLoading: false,
      homeDatas: [[], []],
    };

    this._componentWillLoad();
  }

  static navigationOptions = ({navigation}) => {
    return {
      title: 'Home',
      header: <NewHeader title="Home" navigate={navigation} />,
    };
  };

  async _homeData() {
    this.setState({refreshing: true});
    try {
      let response = await axios.get('index/home');
      await AsyncStorage.setItem('homeDatas', JSON.stringify(response.data));
      await this.props.homeSuccess(response.data);

      this.setState({refreshing: false});
    } catch (error) {
      this.setState({refreshing: false});
    }
  }

  async _componentWillLoad() {
    let homeData = await AsyncStorage.getItem('homeDatas');
    if (homeData) {
      let homeDatas = await JSON.parse(homeData);
      await this.props.homeSuccess(homeDatas);
    }
    this.props.onHomeRequest();
  }

  componentWillUnmount() {
    this.setState({isLoading: false, isOrderSubmitting: false});
    BackHandler.addEventListener('hardwareBackPress', () => {
      BackHandler.exitApp();
    });
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      BackHandler.exitApp();
    });
  }

  render() {
    return (
      <View style={styles.containerbox}>
        <View style={styles.body}>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={this.state.refreshing}
                onRefresh={() => this._homeData(1)}
                style={{backgroundColor: 'transparent'}}
                enabled={true}
              />
            }>
            {this.props.homeDatas[1].length > 0 ? (
              <OrderItem
                currency={this.props.currency}
                orders={this.props.homeDatas[1]}
                push={this.props.navigation.push}
              />
            ) : null}
            {this.props.homeDatas[0].length > 0 ? (
              <TripItem
                currency={this.props.currency}
                trips={this.props.homeDatas[0]}
                navigate={this.props.navigation.navigate}
                push={this.props.navigation.push}
                screenProps={this.props.navigation}
              />
            ) : null}
            <WhyShop />
            <TravelEarn />
          </ScrollView>
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    currency: state.auth.currency,
    user: state.auth.user,
    inboxes: state.auth.inboxes,
    inboxCount: state.auth.inbox_count,
    homeDatas: state.commonReducers.homeDatas,
    isLoading: state.commonReducers.isLoading,
  };
};

const mapDispatchToProps = dispatch => ({
  homeSuccess: data => {
    dispatch(homeSuccess(data));
  },
  onHomeRequestFaild: () => {
    dispatch(onHomeRequestFaild());
  },
  onHomeRequest: () => {
    dispatch(onHomeRequest());
  },
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Home);
