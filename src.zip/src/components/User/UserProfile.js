import React from 'react';
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  BackHandler,
} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';

import styles from '../../../assets/css/style';
import { STORAGE_URL } from '../../config/env';
import axios from 'axios';
import OrderSubmitting from '../Common/OrderSubmitting';
import { connect } from 'react-redux';
import NewHeader from '../Menu/NewHeader';
import { StackActions, NavigationActions } from 'react-navigation';

class UserProfile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: null,
      isLoading: true,
      userName: null,
      refreshing: false,
    };

    this.imageCdn = this.imageCdn.bind(this);
  }

  _handleReset() {
    const resetAction = StackActions.reset({
      index: 0,
      key: null,
      actions: [NavigationActions.navigate({ routeName: 'Home' })],
    });
    this.props.navigation.dispatch(resetAction);
  }

  static navigationOptions = ({ navigation }) => {
    return {
      header: <NewHeader navigate={navigation} routeName="UserProfile" />,
    };
  };

  async user(userName, type) {
    if (type) {
      this.setState({
        refreshing: true,
      });
    } else {
      this.setState({
        // isLoading: true,
        userName,
      });
    }
    try {
      let response = await axios.get('user/' + userName);
      this.setState({
        user: response.data.data,
        isLoading: false,
        refreshing: false,
      });
    } catch (error) {
      if (type) {
        this.setState({
          refreshing: false,
        });
      } else {
        await Alert.alert('Oops!', 'No user data found!');
        this.props.navigation.navigate('Home');
      }
    }
  }

  _componentWillLoad() {
    const userName = this.props.navigation.getParam('userName');
    if (userName) {
      this.user(userName, 0);
    } else {
      this.user(this.props.user.username, 0);
    }
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });

    this._componentWillLoad();
  }

  componentWillUnmount() {
    this.setState({
      isLoading: false,
    });
    BackHandler.addEventListener('hardwareBackPress', () => {
      this.props.navigation.goBack(null);
      return true;
    });
  }

  imageCdn(url) {
    return STORAGE_URL + url;
  }

  _navigate(navigate) {
    navigate('EditUserProfile');
  }

  buttonEdit(username, navigate) {
    if (this.props.user) {
      if (this.props.user.username == username) {
        return (
          <TouchableOpacity
            style={{
              backgroundColor: '#660165',
              paddingVertical: 12,
              width: '100%',
              borderRadius: 6,
              overflow: 'hidden',
            }}
            onPress={() => this._navigate(navigate)}>
            <Text
              style={{
                color: '#fff',
                textAlign: 'center',
                fontSize: 16,
                fontFamily: 'Montserrat-semiBold',
              }}>
              {' '}
              Edit{' '}
            </Text>
          </TouchableOpacity>
        );
      } else {
        return null;
      }
    }
    return null;
  }

  render() {
    if (this.state.isLoading) {
      return <OrderSubmitting />;
    } else {
      const { navigate } = this.props.navigation;
      const user = this.state.user;
      let useravatar = null;
      if (!user.avatar) {
        useravatar = this.imageCdn('static/assets/images/profile-up-img.png');
      } else {
        useravatar = user.avatar;
      }

      let emailicon = 'exclamation-circle';
      let phoneicon = 'exclamation-circle';
      let phoneText = 'Phone Not Verified';
      let emailText = 'Email Not Verified';
      let emailColor = 'red';
      let phoneColor = 'red';
      if (user.isEmailVerified) {
        emailicon = 'check';
        emailText = 'Email Verified';
        emailColor = '#1e821f';
      }
      if (user.isPhoneVerified) {
        phoneicon = 'check';
        phoneText = 'Phone Verified';
        phoneColor = '#1e821f';
      }

      let shoper_ratings = [];
      let traveller_ratings = [];
      for (let i = 1; i < 6; i++) {
        let classiconshop = user.shopper_ratting_int >= i ? 'star' : 'star-o';
        let classicontraveller =
          user.traveller_ratting_int >= i ? 'star' : 'star-o';

        shoper_ratings.push(
          <FontAwesome
            key={i}
            name={classiconshop}
            size={15}
            style={{ color: '#660165' }}
          />,
        );
        traveller_ratings.push(
          <FontAwesome
            key={i}
            name={classicontraveller}
            size={15}
            style={{ color: '#660165' }}
          />,
        );
      }

      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={() => this.user(this.state.userName, 1)}
              style={{ backgroundColor: 'transparent' }}
            />
          }>
          <View style={[styles.container, { width: '100%' }]}>
            <View style={{ justifyContent: 'center', alignItems: 'center' ,width:'100%',}}>
              <View style={[{ justifyContent: 'center', alignItems: 'center' }]}>
                <View style={styles.userprofile}>
                  <Image
                    style={styles.userprofile_dp}
                    source={{ uri: useravatar }}
                    resizeMode="cover"
                  />
                </View>
                <Text style={{ color: 'black', fontFamily: 'OpenSnas;bold', fontSize: 20 }}> {user.name}</Text>

              </View>

              <View style={{ width:'100%',justifyContent: 'center', alignItems: 'center' }}>

              <View style={[styles.shadowNew, { width: '95%',flex:1,padding:15,margin:15,borderRadius:15,backgroundColor:'#F8F8F8' }]}>
                <View style={[{ flexDirection: 'row', width: '100%', justifyContent: 'space-between', }]}>
                  <Text style={styles.ratingtitel}>Shopper</Text>
                  <View style={styles.ratingall}>{shoper_ratings}</View>
                </View>
                {/* {user.shopper_done ? (
                  null
                ) : null} */}
                <View style={[{ flexDirection: 'row', width: '100%', justifyContent: 'space-between', }]}>
                  <Text style={styles.ratingtitel}>Traveller</Text>
                  <View style={styles.ratingall}>{traveller_ratings}</View>
                </View>
                {/* {user.traveller_done ? (
                  null
                ) : null} */}

                <View style={{
                    flexDirection: 'row',
                 
                    justifyContent: 'space-between',
                    marginVertical: 5,
                  }}>
                  <FontAwesome
                    name={emailicon}
                    size={22}
                    style={{ color: emailColor }}
                  />
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-regular' }}>
                    {' '}
                    {emailText}
                  </Text>
                </View>

                <View style={{
                    flexDirection: 'row',
                 
                    justifyContent: 'space-between',
                    marginVertical: 5,
                  }}>
                  <FontAwesome
                    name={phoneicon}
                    size={22}
                    style={{ color: phoneColor }}
                  />
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-regular' }}>
                    {' '}
                    {phoneText}
                  </Text>
                </View>

                <View
                  style={{
                    flexDirection: 'row',
                 
                    justifyContent: 'space-between',
                    marginVertical: 5,
                  }}>
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-semiBold' }}>
                    Location
                  </Text>
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-regular' }}>
                    {' '}
                    {user.country}
                  </Text>
                </View>

                <View
                  style={{
                    flexDirection: 'row',
               
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-semiBold' }}>
                    Joined Date{' '}
                  </Text>
                  <Text
                    style={{ fontSize: 15, fontFamily: 'Montserrat-regular' }}>
                    {' '}
                    {user.joined_at}
                  </Text>
                </View>
             

              {/* <View style={[styles.card, styles.shadow]}>
                <Text style={styles.username}> {user.name}</Text>
                <View style={{ marginVertical: 10 }}>
                  {this.buttonEdit(user.username, navigate)}
                </View>
                <View style={styles.verefymoemail}>


                </View>
            
              </View>
               */}

               </View>
            </View>

            <Text style={styles.feedbacktitel}>
              {user.feedbacks.length > 0 ? 'Feedback' : ''}
            </Text>
            {user.feedbacks.map((feedback, index) => {
              var useravatar = null;
              if (feedback.avatar) {
                useravatar = feedback.avatar;
              } else {
                useravatar = this.imageCdn(
                  'static/assets/images/profile-up-img.png',
                );
              }

              return (
                <View style={[styles.card, styles.shadow]} key={index}>
                  <View style={styles.feedbackbox}>
                    <View>
                      <Image
                        style={styles.sm_user_fit}
                        source={{ uri: useravatar }}
                        resizeMode="cover"
                      />
                    </View>
                    <View style={styles.commenttext}>
                      <Text
                        style={{
                          fontSize: 16,
                          fontFamily: 'Montserrat-semiBold',
                          color: '#660165',
                        }}>
                        {' '}
                        {feedback.by_user}
                      </Text>
                      <Text
                        style={{
                          fontSize: 13,
                          fontFamily: 'Montserrat-regular',
                          color: '#000',
                          marginVertical: 2,
                        }}>
                        {' '}
                        {feedback.feedback}{' '}
                      </Text>
                      <Text
                        style={{
                          fontSize: 10,
                          fontFamily: 'Montserrat-medium',
                          color: '#aaa',
                        }}>
                        {feedback.given_at}
                      </Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
          </View>
          
        </ScrollView>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(UserProfile);
