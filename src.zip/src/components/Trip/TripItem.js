import React from 'react';
import { Text, View, Image, TouchableOpacity, Dimensions } from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import styles from '../../../assets/css/style';
import { STORAGE_URL } from '../../config/env';
import Share from 'react-native-share';
import Entypo from 'react-native-vector-icons/Entypo';
import FlyButton from '../Common/FlyButton';

export default class TripItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      navigation: this.props.navigation,
      trips: this.props.trips,
      currency: this.props.currency,
      activeSlide: 0,
      viewport: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
      },
    };

    this.imageCdn = this.imageCdn.bind(this);
  }

  get pagination() {
    const { trips, activeSlide } = this.state;
    return (
      <Pagination
        dotsLength={trips.length}
        activeDotIndex={activeSlide}
        containerStyle={{ backgroundColor: '#f1f3f6' }}
        dotStyle={{
          width: 10,
          height: 10,
          borderRadius: 5,
          marginHorizontal: 0,
          backgroundColor: '#660165',
        }}
        inactiveDotStyle={{
          backgroundColor: '#000',
        }}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    );
  }

  _pushItem(type, id) {
    if (type == 1) {
      this.props.push('ShopOption', { tripId: id, type: 1 });
    } else {
      this.props.push('ShopOption', { tripId: id, type: 2 });
    }
  }

  _handleShare(trip) {
    var url;
    if (trip.travel_type == 1) {
      url = 'https://flypur.com/shop-globally/' + trip.id;
    } else {
      url = 'https://flypur.com/shop-globally/' + trip.id;
    }

    let shareOptions = {
      title: 'Ask me bring anything from ' + trip.travel_from,
      message: 'Ask me bring anything from ' + trip.travel_from,
      url,
      subject: 'Ask me bring anything from ' + trip.travel_from,
    };
    Share.open(shareOptions);
  }

  imageCdn = url => {
    return STORAGE_URL + url;
  };

  _renderItem = (item, index) => {
    var trip = item.item;
    var useravatar = null;
    var askDeliver = null;

    if (!trip.isSameUser) {
      askDeliver = (
        // <TouchableOpacity
        //   style={[styles.deliverybtn]}
        //   onPress={() => this._pushItem(trip.travel_type, trip.id)}>
        //   <Text style={{paddingRight: 25, color: '#fff', alignItems: 'center'}}>
        //     <FontAwesome name="shopping-cart" size={26} />
        //   </Text>
        //   <Text
        //     style={{
        //       fontSize: 18,
        //       color: '#fff',
        //       alignItems: 'center',
        //       fontFamily: 'Montserrat-Regular',
        //     }}>
        //     Ask For Delivery
        //   </Text>
        // </TouchableOpacity>

        <FlyButton style={{marginBottom:10}} title='Ask For Delivery' color='#4A0B49' onPress={() => this._pushItem(trip.travel_type, trip.id)} />
      );
    } else {
      askDeliver = (
        // <TouchableOpacity
        //   style={[styles.deliverybtn, styles.deliverybtndisabel]}>
        //   <Text style={{paddingRight: 25, color: '#fff', alignItems: 'center'}}>
        //     <FontAwesome name="shopping-cart" size={26} />
        //   </Text>
        //   <Text
        //     style={{
        //       fontSize: 18,
        //       color: '#fff',
        //       alignItems: 'center',
        //       fontFamily: 'Montserrat-Regular',
        //     }}>
        //     Ask For Delivery{' '}
        //   </Text>
        // </TouchableOpacity>

        <FlyButton style={{marginBottom:10}} title='Ask For Delivery' color='#4A0B49' />

      );
    }

    if (!trip.avatar) {
      useravatar = this.imageCdn('static/assets/images/profile-up-img.png');
    } else {
      useravatar = trip.avatar;
    }

    return (
      <View style={[]} key={index}>
        <View style={[styles.orderitemcard, styles.shadow,{borderRadius:15,marginTop:5}]} key={index}>

          <View style={[styles.descrcontainer,{marginLeft:20}]}>
            <Image source={{ uri: useravatar }} style={styles.sm_user_fit} />

            {/* <View style={styles.share_order}>
            <TouchableOpacity onPress={() => this._handleShare(trip)}>
              <Entypo name="share" size={25} style={{color: '#660165'}} />
            </TouchableOpacity>
          </View> */}

            <View style={styles.itemtitel}>
              <TouchableOpacity
                style={styles.shoptab}
                onPress={() =>
                  this.props.push('UserProfile', { userName: trip.userName })
                }>
                <Text style={[styles.itemname, ]}>
                  {' '}
                  {trip.traveler}
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={[styles.adressboxTop,{alignItems:'center',marginHorizontal:20,borderTopLeftRadius:10} ]}>
            <View style={[styles.addresslistbox,{marginTop:10}]}>
              <Text style={styles.addresstitel}>Travelling From : </Text>
              <Text style={[styles.addressTitel, ]}>
                {' '}
                {trip.travel_from}{' '}
              </Text>
            </View>
            <View style={styles.addresslistbox}>
              <Text style={styles.addresstitel}>Travelling To : </Text>
              <Text style={[styles.addressTitel, ]}>
                {' '}
                {trip.travel_to}{' '}
              </Text>
            </View>
            <View style={styles.addresslistbox}>
              <Text style={styles.addresstitel}>Delivery Date: </Text>
              <Text style={[styles.addressTitel, ]}>
                {' '}
                {trip.traveldateF}
              </Text>
            </View>
          </View>
        </View>
        <View style={{width:250,alignItems:'center',alignSelf:'center',marginTop:30}}>
          {askDeliver}
        </View>

      </View>
    );
  };

  render() {
    if (this.state.trips.length > 0) {
      return (
        <View
          style={styles.container}
          onLayout={() => {
            this.setState({
              viewport: {
                width: Dimensions.get('window').width,
                height: Dimensions.get('window').height,
              },
            });
          }}>
          <Text style={[styles.allheading,{color:'#4A0B49'}]}>Recent Trips</Text>
          <Carousel
            ref={c => {
              this._carousel = c;
            }}
            data={this.state.trips}
            renderItem={this._renderItem}
            sliderWidth={this.state.viewport.width}
            itemWidth={this.state.viewport.width}
            onSnapToItem={index => this.setState({ activeSlide: index })}
          />
          {this.pagination}
        </View>
      );
    } else {
      return null;
    }
  }
}
