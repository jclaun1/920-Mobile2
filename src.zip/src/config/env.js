const OAUTH_CLIENT_ID = 2;
const OAUTH_CLIENT_SECRECT =
  process.env.NODE_ENV !== 'production'
    ? 'BteadSqqHLUvNYPYcnhGVUplU0thjeChDdMO1VZK'
    : 'Pgwac1RonLQg0haLwfmhBsjCWihl09PfPTyZ0lXp';
const apiDomain =
  process.env.NODE_ENV !== 'production'
    ? 'https://api.flypur.com/'
    : 'https://ef40be38.ngrok.io/';
const LOGIN_URL = `${apiDomain}oauth/token`;
const socialloginur = `${apiDomain}api/social/facebook`;
const STORAGE_URL = 'https://flypur.s3.ap-south-1.amazonaws.com/';
const PLACCE_API = 'AIzaSyA8YI55JVwclo_u6Aye_5JKYWwjm5UTFos';
const SOCKET_SERVER =
  process.env.NODE_ENV === 'production'
    ? 'https://api.flypur.com'
    : 'http://127.0.0.1:8000';

export { LOGIN_URL, apiDomain, socialloginur, 
  OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRECT, 
  STORAGE_URL, PLACCE_API, SOCKET_SERVER
}
