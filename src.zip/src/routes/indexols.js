import React from 'react';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Foundation from 'react-native-vector-icons/Foundation';

import {
  createBottomTabNavigator,
  createStackNavigator,
  createDrawerNavigator,
  createSwitchNavigator,
  StackActions,
  NavigationActions,
} from 'react-navigation';

import CustomDrawerComponent from './userImage';
import SignUp from '../components/Auth/SignUp';
import Login from '../components/Auth/Login';
import NewPassword from '../components/Auth/NewPassword';
import Home from '../components/Home/Home';
import AuthLoadingScreen from '../../AuthLoadingScreen';

import TravelOption from '../components/Travel/TravelOption';

import FindOrderDomestically from '../components/Order/FindOrder/FindOrderDomestically';
import FindOrderInternational from '../components/Order/FindOrder/FindOrderInternational';
import FindOrderLocally from '../components/Order/FindOrder/FindOrderLocally';

import ShopOption from '../components/Shop/ShopOption';

import MyOffers from '../components/Account/Offer/MyOffers';
import MyOrders from '../components/Account/Order/MyOrders';
import MyTrips from '../components/Account/Trips/MyTrips';
import DeliveryOrders from '../components/Account/Order/Delivery/DeliveryOrders';
import Payments from '../components/Account/Payments';
import MoreSetting from '../components/Account/MoreSetting';
import ChangePassword from '../components/Account/ChangePassword';
import BalanceAndWithdrwal from '../components/Account/BalanceAndWithdrwal';
import Withdrawal from '../components/Account/Payments/Withdrawal';

import AllOffers from '../components/Account/Offer/AllOffers';
import EmailPhone from '../components/Account/EmailPhone';

import MessageNotifications from '../components/Account/MessageNotifications';
import InboxIcon from '../components/Account/Partial/InboxIcon';

import Notifacations from '../components/Account/Notifacations';
import NotificationIcon from '../components/Account/Partial/NotificationIcon';

import EditGlobaly from '../components/Account/Order/Edit/EditGlobaly';
import EditLocally from '../components/Account/Order/Edit/EditLocally';
import EditDomestically from '../components/Account/Order/Edit/EditDomestically';
import EditFoodDomestically from '../components/Account/Order/Edit/EditFoodDomestically';
import EditFoodLocally from '../components/Account/Order/Edit/EditFoodLocally';

import AddTripList from '../components/Account/Trips/AddTrips/AddTripList';

import OrderPost from '../components/Order/OrderPost/OrderPost';
import MakeOffer from '../components/Order/Offer/MakeOffer';
import CheckOut from '../components/Account/Order/CheckOut';
import OrderConfirm from '../components/Account/Order/OrderAction/OrderConfirm';
import ConfirmOrderTraveller from '../components/Account/Order/OrderAction/ConfirmOrderTraveller';

import Chat from '../components/Account/Chat/Chat';
import ChatList from '../components/Account/Chat/ChatList';
import UserProfile from '../components/User/UserProfile';
import EditProfile from '../components/Account/Profile/EditProfile';
import LogOut from '../components/Account/LogOut';

import OrderSubmittingData from '../components/Common/OrderSubmittingData';

const tabBarOnPress = ({navigation, defaultHandler}) => {
  const {isFocused, state, goBack} = navigation;
  // if (indexRoute > -1 ) {
  var routeName = state.routeName;
  const resetAction = StackActions.reset({
    index: 0,
    key: state.key,
    actions: [NavigationActions.navigate({routeName})],
  });
  navigation.dispatch(resetAction);
  //   return
  // }

  if (isFocused()) {
    if (state.routes.length > 1) {
      for (let i = 0; i < state.routes.length - 1; i += 1) {
        goBack();
      }
    } else {
      defaultHandler();
      // @TODO SCROLL TO TOP OF EACH TAB IF SCROLLABLE, $CALLBACK().
    }
  } else {
    defaultHandler();
  }
};

export const HomeStack = createStackNavigator(
  {
    Home: {
      screen: Home,
    },

    OrderPost: {
      screen: OrderPost,
      navigationOptions: {
        title: 'Order',
      },
    },

    MakeOffer: {
      screen: MakeOffer,
      navigationOptions: {
        title: 'Make Offer',
      },
    },
  },

  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: '600',
      },
    },
  },
);

export const ShopStack = createStackNavigator(
  {
    ShopOption: {
      screen: ShopOption,
      navigationOptions: {
        title: 'Shop',
      },
    },
  },

  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const TravelStack = createStackNavigator(
  {
    TravelOption: {
      screen: TravelOption,
      navigationOptions: {
        title: 'Travel',
      },
    },

    FindOrderDomestically: {
      screen: FindOrderDomestically,
      navigationOptions: {
        title: 'Find Order Domestically',
      },
    },

    FindOrderInternational: {
      screen: FindOrderInternational,
      navigationOptions: {
        title: 'Find Order International',
        headerStyle: {
          backgroundColor: '#660165',
        },
      },
    },

    FindOrderLocally: {
      screen: FindOrderLocally,
      navigationOptions: {
        title: 'Find Order Locally',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const LoginStack = createStackNavigator(
  {
    Login: {
      screen: Login,
      navigationOptions: {
        title: 'Login',
      },
    },

    NewPassword: {
      screen: NewPassword,
      navigationOptions: {
        title: 'Create New Password',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const SignUpStack = createStackNavigator(
  {
    SignUp: {
      screen: SignUp,
      navigationOptions: {
        title: 'SignUp',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const Tabs = createBottomTabNavigator(
  {
    Home: {
      screen: HomeStack,
      navigationOptions: {
        tabBarLabel: 'Home',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="home" color={tintColor} size={26} />
        ),
      },
    },

    TravelOption: {
      screen: TravelStack,
      navigationOptions: {
        tabBarLabel: 'Travel',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="plane" color={tintColor} size={27} />
        ),
      },
    },

    ShopOption: {
      screen: ShopStack,
      navigationOptions: {
        tabBarLabel: 'Shop',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="shopping-bag" color={tintColor} size={25} />
        ),
      },
    },

    Login: {
      screen: LoginStack,
      navigationOptions: {
        tabBarLabel: 'Login',
        tabBarIcon: ({tintColor}) => (
          <Entypo name="login" color={tintColor} size={25} />
        ),
      },
    },

    SignUp: {
      screen: SignUpStack,
      navigationOptions: {
        tabBarLabel: 'SignUp',
        tabBarIcon: ({tintColor}) => (
          <Entypo name="add-user" color={tintColor} size={25} />
        ),
      },
    },
  },
  {
    tabBarOptions: {
      style: {
        background: require('../../assets/images/ic_logo.png'),
      },
      activeTintColor: 'orange',
      inactiveTintColor: '#660165',
    },

    navigationOptions: navigation => ({
      tabBarOnPress,
    }),
  },
);

export const MessageNotificationStack = createStackNavigator(
  {
    MessageNotification: {
      screen: MessageNotifications,
      navigationOptions: {
        title: 'Inbox',
      },
    },
    ChatList: {
      screen: ChatList,
      navigationOptions: {
        title: 'Chat List',
        tabBarVisible: false,
      },
    },

    Chat: {
      screen: Chat,
      navigationOptions: {
        title: 'Chat',
        tabBarVisible: false,
      },
    },

    UserProfile: {
      screen: UserProfile,
      navigationOptions: {
        title: 'User Profile',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const NotifacationStack = createStackNavigator(
  {
    Notifacation: {
      screen: Notifacations,
      navigationOptions: {
        title: 'Notifications',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const AuthTabs = createBottomTabNavigator(
  {
    Home: {
      screen: HomeStack,
      navigationOptions: {
        tabBarLabel: 'Home',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="home" color={tintColor} size={26} />
        ),
      },
    },

    TravelOption: {
      screen: TravelStack,
      navigationOptions: {
        tabBarLabel: 'Travel',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="plane" color={tintColor} size={27} />
        ),
      },
    },

    ShopOption: {
      screen: ShopStack,
      navigationOptions: {
        tabBarLabel: 'Shop',
        tabBarIcon: ({tintColor}) => (
          <FontAwesome name="shopping-bag" color={tintColor} size={25} />
        ),
      },
    },

    MessageNotification: {
      screen: MessageNotificationStack,
      navigationOptions: {
        tabBarLabel: 'Inbox',
        tabBarIcon: ({tintColor}) => <InboxIcon tintColor={tintColor} />,
      },
    },

    Notifacation: {
      screen: NotifacationStack,
      navigationOptions: {
        tabBarLabel: 'Notifications',
        tabBarIcon: ({tintColor}) => <NotificationIcon tintColor={tintColor} />,
      },
    },
  },
  {
    tabBarOptions: {
      style: {
        backgroundColor: '#fff',
      },
      activeTintColor: 'orange',
      inactiveTintColor: '#660165',
    },
    navigationOptions: navigation => ({
      tabBarOnPress,
    }),
  },
);

export const PaymentStack = createStackNavigator(
  {
    Payments: {
      screen: Payments,
      navigationOptions: {
        title: 'My Payments',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const MyOfferStack = createStackNavigator(
  {
    MyOffers: {
      screen: MyOffers,
      navigationOptions: {
        title: 'My Offers',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const EmailPhoneStack = createStackNavigator(
  {
    EmailPhone: {
      screen: EmailPhone,
      navigationOptions: {
        title: 'Email & Phone',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const NotificationsSettingsStack = createStackNavigator(
  {
    MoreSetting: {
      screen: MoreSetting,
      navigationOptions: {
        title: 'Notifications Settings',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const ChangePasswordStack = createStackNavigator(
  {
    ChangePassword: {
      screen: ChangePassword,
      navigationOptions: {
        title: 'Change Password',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const LogOutStack = createStackNavigator({
  LogOut: {
    screen: LogOut,
    navigationOptions: {
      title: 'LogOut',
    },
  },
});

export const BalanceAndWithdrwalStack = createStackNavigator(
  {
    BalanceAndWithdrwal: {
      screen: BalanceAndWithdrwal,
      navigationOptions: {
        title: 'Balance And Withdrawal',
      },
    },

    Withdrawal: {
      screen: Withdrawal,
      navigationOptions: {
        title: 'Withdrawal',
      },
    },
  },
  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const UserProfileStack = createStackNavigator(
  {
    UserProfile: {
      screen: UserProfile,
      navigationOptions: {
        title: 'User Profile',
      },
    },

    EditUserProfile: {
      screen: EditProfile,
      navigationOptions: {
        title: 'Edit Profile',
      },
    },
  },

  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const MyOrdersStack = createStackNavigator(
  {
    MyOrders: {
      screen: MyOrders,
    },

    OrderSubmittingData: {
      screen: OrderSubmittingData,
      navigationOptions: {
        title: 'Order Submitting Data',
      },
    },

    EditGlobaly: {
      screen: EditGlobaly,
      navigationOptions: {
        title: 'Edit Order',
      },
    },

    EditLocally: {
      screen: EditLocally,
      navigationOptions: {
        title: 'Edit Order',
      },
    },

    EditDomestically: {
      screen: EditDomestically,
      navigationOptions: {
        title: 'Edit Order',
      },
    },

    EditFoodDomestically: {
      screen: EditFoodDomestically,
      navigationOptions: {
        title: 'Edit Order',
      },
    },

    EditFoodLocally: {
      screen: EditFoodLocally,
      navigationOptions: {
        title: 'Edit Order',
      },
    },

    CheckOut: {
      screen: CheckOut,
      navigationOptions: {
        title: 'CheckOut',
      },
    },

    OrderConfirm: {
      screen: OrderConfirm,
      navigationOptions: {
        title: 'Order Confirm',
      },
    },

    ConfirmOrderTraveller: {
      screen: ConfirmOrderTraveller,
      navigationOptions: {
        title: 'Confirm Order Traveller',
      },
    },

    AllOffers: {
      screen: AllOffers,
      navigationOptions: {
        title: 'All Offers',
      },
    },
  },

  {
    navigationOptions: navigation => ({
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }),
    initialRouteName: 'MyOrders',
  },
);

export const MyTripsStack = createStackNavigator(
  {
    MyTrips: {
      screen: MyTrips,
      navigationOptions: {
        title: 'My Trips',
      },
    },

    DeliveryOrders: {
      screen: props => <DeliveryOrders {...props} />,
      navigationOptions: {
        title: 'Delivery Orders',
        headerTintColor: '#fff',
        headerStyle: {
          backgroundColor: '#660165',
        },
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      },
    },

    AddTripList: {
      screen: AddTripList,
      navigationOptions: {
        title: 'Add Trip List',
      },
    },
  },

  {
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#660165',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    },
  },
);

export const Drawer = createDrawerNavigator(
  {
    Tabs: {
      screen: AuthTabs,
      navigationOptions: {
        drawerLabel: 'Home',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="home" color={tintColor} size={26} />
        ),
      },
    },

    // OrderSubmittingData: {
    //   screen: OrderSubmittingData,
    //   navigationOptions: {
    //     title: 'Order Submitting Data'
    //   }
    // },

    MyOffer: {
      screen: MyOfferStack,
      navigationOptions: {
        drawerLabel: 'My Offers',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="shopping-bag" color={tintColor} size={25} />
        ),
      },
    },

    MyOrders: {
      screen: MyOrdersStack,
      navigationOptions: {
        drawerLabel: 'My Orders',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="archive" color={tintColor} size={25} />
        ),
      },
    },

    MyTrips: {
      screen: MyTripsStack,
      navigationOptions: {
        drawerLabel: 'My Trips',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="plane" color={tintColor} size={25} />
        ),
      },
    },

    Payment: {
      screen: PaymentStack,
      navigationOptions: {
        drawerLabel: 'My Payments',
        drawerIcon: ({tintColor}) => (
          <Foundation name="dollar-bill" color={tintColor} size={25} />
        ),
      },
    },

    UserProfileDraw: {
      screen: UserProfileStack,
      navigationOptions: {
        drawerLabel: 'My Profile',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="user" color={tintColor} size={25} />
        ),
      },
    },

    BalanceAndWithdrwal: {
      screen: BalanceAndWithdrwalStack,
      navigationOptions: {
        drawerLabel: 'Balance And Withdrawal',
        drawerIcon: ({tintColor}) => (
          <MaterialIcons name="account-balance" color={tintColor} size={25} />
        ),
      },
    },

    EmailPhone: {
      screen: EmailPhoneStack,
      navigationOptions: {
        drawerLabel: 'Email & Phone',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="envelope" color={tintColor} size={25} />
        ),
      },
    },

    NotificationsSettings: {
      screen: NotificationsSettingsStack,
      navigationOptions: {
        drawerLabel: 'Notifications Settings',
        drawerIcon: ({tintColor}) => (
          <MaterialIcons name="settings" color={tintColor} size={25} />
        ),
      },
    },

    ChangePassword: {
      screen: ChangePasswordStack,
      navigationOptions: {
        drawerLabel: 'Change Password',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="key" color={tintColor} size={25} />
        ),
      },
    },

    LogOut: {
      screen: LogOutStack,
      navigationOptions: {
        drawerLabel: 'Logout',
        drawerIcon: ({tintColor}) => (
          <FontAwesome name="power-off" color={tintColor} size={25} />
        ),
      },
    },
  },
  {
    contentOptions: {
      activeTintColor: '#660165',
      itemsContainerStyle: {
        marginVertical: 0,
      },
      iconContainerStyle: {
        opacity: 1,
      },
    },

    contentComponent: CustomDrawerComponent,
  },
);

export const Router = createSwitchNavigator(
  {
    AuthLoading: AuthLoadingScreen,
    Authenticated: Drawer,
    UnAuthenticated: Tabs,
  },
  {
    initialRouteName: 'AuthLoading',
  },
);
