import {NavigationActions} from 'react-navigation';

export default (pushUrlAction = (url, dispatch) => {
  var types = [
    'order-post',
    'make-offer',
    'find-order-domestic',
    'find-order-locally',
    'find-order-internationally',
    'travel-domestically',
    'travel-internationally',
    'travel-locally',
    ,
    '@',
    'create-new-password',
    'login',
    'sign-up',
  ];

  types.forEach((element, index) => {
    var indexpos = url.search(element);
    if (indexpos > -1) {
      var arraysData = url.split(element + '/');

      if (index == 0) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'OrderPost',
            params: {slug: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 1) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'MakeOffer',
            params: {slug: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 2) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'FindOrderDomestically',
            params: {id: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 3) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'FindOrderLocally',
            params: {id: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 4) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'FindOrderInternational',
            params: {id: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 5) {
        dispatch(NavigationActions.navigate({routeName: 'TravelDomestic'}));
        return;
      }

      if (index == 6) {
        dispatch(
          NavigationActions.navigate({routeName: 'TravelInternational'}),
        );
        return;
      }

      if (index == 7) {
        dispatch(NavigationActions.navigate({routeName: 'TravelLocal'}));
        return;
      }

      if (index == 8) {
        arraysData = url.split('/@');
        dispatch(
          NavigationActions.navigate({
            routeName: 'UserProfile',
            params: {userName: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 9) {
        dispatch(
          NavigationActions.navigate({
            routeName: 'NewPassword',
            params: {token: arraysData[arraysData.length - 1]},
          }),
        );
        return;
      }

      if (index == 10) {
        dispatch(NavigationActions.navigate({routeName: 'Login'}));
        return;
      }

      if (index == 11) {
        dispatch(NavigationActions.navigate({routeName: 'SignUp'}));
        return;
      }
    }
  });
  return;
});
