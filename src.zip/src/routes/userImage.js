import { SafeAreaView, View, Image, ScrollView, Text } from 'react-native';
import React from 'react';
import { STORAGE_URL } from '../config/env';
import styles from '../../assets/css/style';
import Entypo from 'react-native-vector-icons/Entypo';
import { DrawerItems, NavigationActions } from 'react-navigation';
import { connect } from 'react-redux';
import MenuItem from '../components/Common/MenuItem';

const navigateAction = NavigationActions.navigate({
  routeName: 'Tabs',
  params: {},
  action: NavigationActions.navigate({ routeName: 'Home' }),
});

class CustomDrawerComponent extends React.Component {
  render() {
    let { user } = this.props;
    return (
      <View style={{ flex: 1, backgroundColor: '#60085F', height: '100%', padding: 0, }}>
        <SafeAreaView
          style={{ flex: 1, backgroundColor: '#fff', borderBottomRightRadius: 30, justifyContent: 'center', alignItems: 'center', padding: 0, }}>

          <View style={{ flex: 1, backgroundColor: '#fff', borderBottomRightRadius: 30, justifyContent: 'center', alignItems: 'center' }}>
            <View
              style={{
                height: 150,
                width: 150,
                backgroundColor: 'white',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Image
                source={{
                  uri: user.avatar
                    ? user.avatar
                    : STORAGE_URL + 'static/assets/images/profile-up-img.png',
                }}
                style={styles.user_avatar}
              />
              {/* <Entypo name="dot-single" size={50} style={[styles.user_avatar_ver,styles.colorred]} /> */}
            </View>
            <Text style={{ fontSize: 16, color: 'black', }}>{user.username}</Text>
            <Text style={{ fontSize: 12, color: '#60085F', }}>{user.email}</Text>

            <View style={{ width: '80%', justifyContent: 'flex-start', flexDirection: 'row' }}>
              <Text style={{ width: '100%', fontSize: 16, color: 'black', textAlign: 'left', alignSelf: 'stretch',margin:10, }} >User</Text>

            </View>

            <View style={{ width: '80%', justifyContent: 'flex-start',  }}>
              <MenuItem onPress={() => this.props.navigation.navigate(
                'UserProfile',
                {},
              )} imagePath={require('../../assets/images/ic_profile.png')}
                title='Profile' />
              <MenuItem onPress={() => this.props.navigation.navigate(
                'ChangePassword',
                {},
              )} imagePath={require('../../assets/images/ic_password.png')}
                title='Change Password' />
              <MenuItem onPress={() => this.props.navigation.navigate(
                'MoreSetting',
                {},
              )} imagePath={require('../../assets/images/ic_settings.png')}
                title='Settings' />
              <MenuItem onPress={() => this.props.navigation.navigate(
                'MyOffer',
                {},
              )} imagePath={require('../../assets/images/ic_my_offers.png')}
                title='My Offers' />
              <MenuItem onPress={() => this.props.navigation.navigate(
                'MyOrders',
                {},
              )} imagePath={require('../../assets/images/ic_my_orders.png')}
                title='My Orders' />
              <MenuItem onPress={() => this.props.navigation.navigate(
                'MyTrips',
                {},
              )} imagePath={require('../../assets/images/ic_my_trips.png')}
                title='My Trips' />

            </View>


            <View style={{ width: '80%', justifyContent: 'flex-start', flexDirection: 'row' }}>
              <Text style={{ width: '100%', fontSize: 16, color: 'black', textAlign: 'left', alignSelf: 'stretch',margin:10, }} >Finance</Text>

            </View>
            <View style={{ width: '80%', justifyContent: 'flex-start',  }}>
              <MenuItem onPress={() => this.props.navigation.navigate(
                'Payment',
                {},
              )} imagePath={require('../../assets/images/ic_finance.png')}
                title='Transactions' />
        
            </View>



            <ScrollView>
              {/* <DrawerItems
                {...this.props}
                style={{ margin: 20 }}
                onItemPress={routeOptions => {
                  if (routeOptions.route.key == 'Tabs') {
                    this.props.navigation.dispatch(navigateAction);
                  } else {
                    this.props.navigation.navigate(
                      routeOptions.route.routes[routeOptions.route.index].routeName,
                      {},
                    );
                  }
                }}
              /> */}
            </ScrollView>

            <MenuItem style={{width:100}} onPress={() => this.props.navigation.navigate(
                'LogOut',
                {},
              )} imagePath={require('../../assets/images/ic_logout.png')}
                title='logout' />
          </View>
        </SafeAreaView>
      </View>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.auth.user,
  };
};

export default connect(
  mapStateToProps,
  null,
)(CustomDrawerComponent);
